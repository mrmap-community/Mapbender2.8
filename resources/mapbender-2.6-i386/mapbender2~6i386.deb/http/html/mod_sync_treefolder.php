<?php
require("../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta name="author-mail" content="info@ccgis.de">
<meta name="author" content="U. Rothstein">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Treefolder</title>

<script type="text/javascript">
<!--
function init(){
	parent.mb_registerInitFunctions("window.frames['treeGDE'].setTree()");	
}
function setTree(){
	document.location.href = "../html/mod_treefolder.php?<?php echo $urlParameters; ?>";
}
// -->
</script>
</head>
<body onload='init()'>

</body>
</html>
