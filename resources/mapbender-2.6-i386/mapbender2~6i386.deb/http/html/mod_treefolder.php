<?php
require("../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>
<HEAD>
<TITLE>Treefolder</TITLE>
<META NAME="Generator" CONTENT="Cosmo Create 1.0.3">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
include '../include/dyn_css.php';
?>

<script language='JavaScript'>
function pop_up(name, einstellungen) {
	window.open ('',name,einstellungen);
}
<?php
   $sql = "SELECT e_target FROM gui_element WHERE e_id = $1 AND fkey_gui_id = $2";
   $v = array($e_id,$gui_id);
   $t = array('s','s');
   $res = db_prep_query($sql,$v,$t);
   $e_target = db_result($res,0,"e_target");   
   echo "mod_treeGDE_map = '".$e_target."';";   
?>
</script>

  <SCRIPT language="JavaScript1.2">
  <!--  
  /*
   * sitemap.js 1.31 05/02/2000
   *  - Opera 5
   *
   * sitemap.js 1.3 27/11/2000
   *  - Netscape 6
   *
   * sitemap.js 1.2 20/05/2000
   *  - split array tree into arrays for each element old tree
   *  - no mory type flag, an folder is an entry which has sons
   *  - a folder can have an link
   *  - while initing an default layers is shown 
   *
   * sitemap.js 1.1 20/10/1999
   *  - showTree only updates and init layers new which have been really changed
   *  - add deep to knot entry
   *  - substitute knotDeep[ id ] w/ tree[ id2treeIndex[ id ] ].deep
   *  - add alignment to img and a &nbsp; at the beginning of eyery line
   *  - add a fake img for bookmarks on top panel
   *
   * sitemap.js 1.02 14/10/1999
   *  - fix bug in initStyles
   *
   * sitemap.js 1.01 06/10/1999
   *  - fix bug in knotDeep for Netscape 4.00-4.0.5
   *
   * sitemap.js 1.0 20/09/1999
   *
   * Javascript function for displaying hierarchic directory structures with
   * the ability to collapse and expand directories.
   *
   * Copyright (c) 1999 Polzin GmbH, Duesseldorf. All Rights Reserved.
   * Author: Lutz Eymers <ixtab@polzin.com>
   * Download: http://www.polzin.com/inet/fset_inet.phtml?w=goodies
   *
   * Permission to use, copy, modify, and distribute this software
   * and its documentation for any purposes and without fee
   * is hereby granted provided that this copyright notice
   * appears in all copies. 
   *
   * Of course, this software is provided "as is" without express or implied
   * warranty of any kind.
   *
   */

//var myCategories = {"Stadt":0, "Land":1, "Fluss":4};
var myCategories = {};


// some defaults
try{if (switchwms){}}catch(e){switchwms = 'false';}
try{if (ficheckbox){}}catch(e){ficheckbox = 'true';}
try{if (metadatalink){}}catch(e){metadatalink = 'false';}

  
  parent.mb_registerSubFunctions("window.frames['treeGDE'].mod_treeGDE();");
  parent.mb_registerloadWmsSubFunctions("window.frames['treeGDE'].deleteInputTags();");
  parent.mb_registerloadWmsSubFunctions("window.frames['treeGDE'].document.location.reload();");
  

function deleteInputTags() {
	var max = document.getElementsByTagName("input").length;
	for (var i=0; i<max; i++) {
		var aNode = document.getElementsByTagName("input")[0];
		var aNodeParent = aNode.parentNode;
		aNodeParent.removeChild(aNode);
	}
}
function handleSelectedLayer(mapObj,wms_id,layername,type,status){
	var mywms = new Array();
	mywms[0] = wms_id;
	var mylayername = new Array();
	mylayername[0] = layername;
	parent.handleSelectedLayer_array(mapObj, mywms, mylayername, type, status);
}
function switchWMS(w,s){
	for (var i=0; i < parent.mb_mapObj.length; i++) {
		if (parent.mb_mapObj[i].frameName == mod_treeGDE_map) {
			for (var ii=0; ii < parent.mb_mapObj[i].wms.length; ii++){
				if (parent.mb_mapObj[i].wms[ii].wms_id == w){
					for (var iii=1; iii < parent.mb_mapObj[i].wms[ii].objLayer.length; iii++) {
						if (parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_selectable == '1') {
							parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_visible = s;
						}
						if (parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_queryable == '1') {
							//parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_querylayer = s;
						}
					}
				}
			}
		}
	}
	parent.mb_restateLayers(mod_treeGDE_map,w);
	parent.setSingleMapRequest(mod_treeGDE_map,w);
}
function mod_treeGDE(){
  /**/
	var ind = parent.getMapObjIndexByName(mod_treeGDE_map);
	//if(ind == false){ alert("error, no mapobject specified");}
	for(var i=0; i<document.getElementsByTagName("input").length; i++){
		//layer_shortname,wms_id,{visible | querylayer}
		var myID = document.getElementsByTagName("input")[i].id;
		var arrayID = document.getElementsByTagName("input")[i].id.split("###");
		var wms_ind = parent.getWMSIndexById(mod_treeGDE_map,arrayID[1]);
		if(arrayID[2] == "visible" && typeof(wms_ind) != "undefined"){
			var arrayLayer = parent.mb_mapObj[ind].layers[wms_ind].split(",");
			var isOn = false;
			for(var ii=0; ii<arrayLayer.length; ii++){
				if(arrayID[0] == arrayLayer[ii]){
					isOn = true;
				}
			}
			if(isOn == true){ document.getElementById(myID).checked = true;}
			if(isOn == false){ document.getElementById(myID).checked = false;}
		}
		if(arrayID[2] == "querylayer" && typeof(wms_ind) != "undefined"){
			var arrayLayer = parent.mb_mapObj[ind].querylayers[wms_ind].split(",");
			var isOn = false;
			for(var ii=0; ii<arrayLayer.length; ii++){
				if(arrayID[0] == arrayLayer[ii]){
					isOn = true;
				}
			}
			if(isOn == true){ document.getElementById(myID).checked = true;}
			if(isOn == false){ document.getElementById(myID).checked = false;}
		}
	}
    /*consider scalhints*/
	for(var i=0; i<parent.mb_mapObj.length; i++){
		var scale = parseInt(parent.mb_getScale(mod_treeGDE_map));
		if(parent.mb_mapObj[i].frameName == mod_treeGDE_map){ 
			for(var ii=0; ii<parent.mb_mapObj[i].wms.length; ii++){
				for(var iii=1; iii<parent.mb_mapObj[i].wms[ii].objLayer.length; iii++){
					if(document.getElementById(parent.mb_mapObj[i].wms[ii].objLayer[iii].layer_name+"_"+parent.mb_mapObj[i].wms[ii].wms_id)){
						if(scale < parseInt(parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_minscale) && parseInt(parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_minscale) != 0){                    
							document.getElementById(parent.mb_mapObj[i].wms[ii].objLayer[iii].layer_name+"_"+parent.mb_mapObj[i].wms[ii].wms_id).style.color = '#999999';                
						}
						else if(scale > parseInt(parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_maxscale) && parseInt(parent.mb_mapObj[i].wms[ii].objLayer[iii].gui_layer_maxscale) != 0){
							document.getElementById(parent.mb_mapObj[i].wms[ii].objLayer[iii].layer_name+"_"+parent.mb_mapObj[i].wms[ii].wms_id).style.color = '#999999';
						}
						else{
							document.getElementById(parent.mb_mapObj[i].wms[ii].objLayer[iii].layer_name+"_"+parent.mb_mapObj[i].wms[ii].wms_id).style.color = '#000000';
						}
					}                   
				}
			}
		}
	}
} 
  window.onError=null;

  var idx=0
  var treeId = new Array();
  var treeP_id = new Array();
  var treeIsOn = new Array();
  var treeTyp = new Array();
  var treeName = new Array();
  var treeUrl = new Array();
  var treeWasOn = new Array();
  var treeDeep = new Array();
  var treeLastY = new Array();
  var treeIsShown = new Array();
  var treeSelectable = new Array();
  var treeVisible = new Array();
  var treeQueryable = new Array();
  var treeQuerylayer = new Array();
  var treeWMS = new Array();
  var treeShortname = new Array();


  function Note( id,p_id,name,url,selectable,visible,queryable,querylayer,wms,shortname) {
    treeId[ idx ] = id
    treeP_id[ idx ] = p_id
    treeIsOn[ idx ] = false
    treeTyp[ idx ] = 'f'
    treeName[ idx ] = name
    treeUrl[ idx ] = url 
    treeWasOn[ idx ] = false
    treeDeep[ idx ] = 0
    treeLastY[ idx ] = 0
    treeIsShown[ idx ] = false
    treeSelectable[ idx ] = selectable
    treeVisible[ idx ] = visible
    treeQueryable[ idx ] = queryable
    treeQuerylayer[ idx ] = querylayer
    treeWMS[ idx ] = wms
    treeShortname[ idx ] = shortname

    idx++
  }

  function openwindow(Adresse) {
    Fenster1 = window.open(Adresse, "Informationen", "width=500,height=500,left=100,top=100,scrollbars=yes,resizable=no");
    Fenster1.focus();
  }

  function initDiv ( )
  {
    if ( isDOM || isDomIE )
    {
      divPrefix='<DIV CLASS="sitemap" style="position:absolute; left:0; top:0; visibility:hidden;" ID="sitemap'
      divInfo='<DIV CLASS="sitemap" style="position:absolute; visibility:visible" ID="sitemap'
    }
    else
    {
      divPrefix='<DIV CLASS="sitemap" ID="sitemap'
      divInfo='<DIV CLASS="sitemap" ID="sitemap'
    }
    document.writeln( divInfo +  'info">Bitte haben Sie etwas Geduld.<BR>&nbsp;<BR>Es werden die Eintr&auml;ge aus<BR>&nbsp;<BR>der Datenbank initialisiert.</DIV> ' );
    for ( var i=1; i<idx; i++ )
    {
      // linked Name ? 
      if ( treeUrl[i] != null ) {

        linkedName = "<input id='"+treeShortname[i]+"###"+treeWMS[i]+"###visible###' type='checkbox' ";
         if(treeVisible[i] == '1'){ linkedName += "checked ";}
         
         if(treeSelectable[i] != '1'){ 
         	linkedName += "disabled ";
         }
        linkedName += "onClick = 'if(this.checked){handleSelectedLayer(\""+mod_treeGDE_map+"\",\""+treeWMS[i]+"\",\""+treeShortname[i]+"\",\"visible\",1);";
		if(ficheckbox == 'false'){
			linkedName += "handleSelectedLayer(\""+mod_treeGDE_map+"\",\""+treeWMS[i]+"\",\""+treeShortname[i]+"\",\"querylayer\",1);";
		}
        linkedName += "}";
        linkedName += "else{handleSelectedLayer(\""+mod_treeGDE_map+"\",\""+treeWMS[i]+"\",\""+treeShortname[i]+"\",\"visible\",0);";
        if(ficheckbox == 'false'){
			linkedName += "handleSelectedLayer(\""+mod_treeGDE_map+"\",\""+treeWMS[i]+"\",\""+treeShortname[i]+"\",\"querylayer\",0);";
		}
        linkedName += "}'";
        linkedName += '>';
        
        if (ficheckbox == 'true'){
            linkedName += "<input id='"+treeShortname[i]+"###"+treeWMS[i]+"###querylayer' type='checkbox' ";
            if(treeQuerylayer[i] == '1'){ linkedName += "checked ";}
            if(treeQueryable[i] != '1'){ linkedName += "disabled ";}
            linkedName += "onClick = 'if(this.checked){handleSelectedLayer(\""+mod_treeGDE_map+"\",\""+treeWMS[i]+"\",\""+treeShortname[i]+"\",\"querylayer\",1);}";
            linkedName += "else{handleSelectedLayer(\""+mod_treeGDE_map+"\",\""+treeWMS[i]+"\",\""+treeShortname[i]+"\",\"querylayer\",0);}'";
            linkedName += '>';
        }
      
        //linkedName += '<A id="'+treeWMS[i]+'_'+treeShortname[i]+'"  HREF="' + treeUrl[i] + '" TARGET="' + defaultTarget + '"><IMG SRC="'+imagedir+'/1w.gif" BORDER="0" WIDTH="3">' + treeName[i] + '</A>';
        
        linkedName += '<A id="'+treeShortname[i]+'_'+treeWMS[i];
        
        if (metadatalink == 'true'){
        	if (treeUrl[i] !== false) {
				linkedName += '"  HREF="' + treeUrl[i];
        	}
        }
//        linkedName += '"  HREF="../php/mod_layerMetadata.php?id=' + ;


        linkedName +='" TARGET="' + defaultTarget + '" onclick="openwindow(this.href); return false"><IMG SRC="'+imagedir+'/1w.gif" BORDER="0" WIDTH="3">' + treeName[i] + '</A>';
       
       
      }  
      else{
      	linkedName = "";
        linkedName =  '<IMG SRC="'+imagedir+'/1w.gif" BORDER="0" WIDTH="3">';
        if(switchwms == 'true'){
        	linkedName += '<input type="checkbox" onclick="if(this.checked){switchWMS(\''+treeWMS[i]+'\',1)}else{switchWMS(\''+treeWMS[i]+'\',0)}">';
        }
        linkedName += treeName[i];
      }
      // don't link folder icon if node has no sons
      if ( i == idx-1 || treeP_id[i+1] != treeId[i] ) {
        if ( treeDeep[ i ] == 0 )
          folderImg = '<IMG ALIGN="BOTTOM" SRC="'+imagedir+'/file_empty.gif" BORDER="0" HEIGHT="16" WIDTH="1" HSPACE="0">'
        else
          folderImg = ''
      } else {
        folderImg = '<A  HREF="javascript:sitemapClick(' + treeId[i] + ')"><IMG ALIGN="BOTTOM" SRC="'+imagedir+'/folder_off.gif" BORDER="0" NAME="folder' + treeId[i] + '" HEIGHT="16" WIDTH="30" HSPACE="0"></A>'
      }
      // which type of file icon should be displayed?
      if ( treeP_id[i] != 0 )
      {
        if ( lastEntryInFolder( treeId[i] ) )
          fileImg = '<IMG ALIGN="BOTTOM" SRC="'+imagedir+'/file_last.gif" BORDER="0" NAME="file'
            + treeId[i] + '" HEIGHT="16" WIDTH="30" HSPACE="0">'  
        else    
          fileImg = '<IMG ALIGN="BOTTOM" SRC="'+imagedir+'/file.gif" BORDER="0" NAME="file'
            + treeId[i] + '" HEIGHT="16" WIDTH="30" HSPACE="0">'  
      }
      else
        fileImg = ''
      // traverse parents up to root and show vertical lines if parent 
      // is not the last entry on this layer
      verticales = ''
      for( var act_id=treeId[i] ; treeDeep[ id2treeIndex[ act_id ] ] > 1;  )
      {  
        act_id = treeP_id[ id2treeIndex[ act_id ]]
        if ( lastEntryInFolder( act_id ) )
        {
          verticales = '<IMG ALIGN="BOTTOM" SRC="'+imagedir+'/file_empty.gif" BORDER="0" HEIGHT="16" WIDTH="30" HSPACE="0">' + verticales
        }
        else
        {
          verticales = '<IMG ALIGN="BOTTOM" SRC="'+imagedir+'/file_vert.gif" BORDER="0" HEIGHT="16" WIDTH="30" HSPACE="0">' + verticales
        }
      }

      
      document.writeln( divPrefix + treeId[i] + '"><NOBR>&nbsp;' + verticales + fileImg + folderImg + linkedName + '</NOBR></DIV>'
      )  
    }
  }

  function initStyles ( )
  {
    document.writeln( '<STYLE TYPE="text/css">' + "\n" + '<!--' )
    for ( var i=1,y=y0; i<idx; i++ )
    {  
      document.writeln( '#sitemap' + treeId[i] + ' {POSITION: absolute; VISIBILITY: hidden;}' )
      if ( treeIsOn[ id2treeIndex[ treeP_id[i] ] ] )
        y += deltaY
    }
    document.writeln( '#sitemapinfo {POSITION: absolute; VISIBILITY: visible;}' )
    document.writeln( '//-->' + "\n" + '</STYLE>' )
  }



  function sitemapClick( id )
  {
    var i = id2treeIndex[ id ]

    if ( treeIsOn[ i ] )
    // close directory
    {
      // mark node as invisible
      treeIsOn[ i ]=false
      // mark all sons as invisible
      actDeep = treeDeep[ i ]
      for( var j=i+1; j<idx && treeDeep[j] > actDeep; j++ )
      {
        treeWasOn[ j ] = treeIsOn[ j ]
        treeIsOn[ j ]=false
      }
      gif_off( id )
    }
    else
    // open directory
    { 
      treeIsOn[ i ]=true
      // remember and restore old status
      actDeep = treeDeep[ i ]
      for( var j=i+1; j<idx && treeDeep[j] > actDeep; j++ )
      {
        treeIsOn[ j ] = treeWasOn[ j ]
      }
      gif_on( id )
    }
    showTree()
  }

  function knotDeep( id )
  {
    var deep=0
    while ( true )
      if ( treeP_id[ id2treeIndex[id] ] == 0 )
        return deep
      else
      {
        ++deep
        id = treeP_id[ id2treeIndex[id] ]
      }
    return deep  
  }

  function initTree( id )
  {
    treeIsOn[ id2treeIndex[id] ] = true
    if ( treeTyp[ id2treeIndex[id] ] != 'b' )
      gif_on( id ) 
    while ( treeP_id[ id2treeIndex[id] ] != 0 )
    {
      id = treeP_id[ id2treeIndex[id] ]
      treeIsOn[ id2treeIndex[id] ] = true
      if ( treeTyp[ id2treeIndex[id] ] != 'b' )
        gif_on( id ) 
    }
  }

  function lastEntryInFolder( id )
  {
    var i = id2treeIndex[id]
    if ( i == idx-1 )
      return true
    if ( treeTyp[i] == 'b' )
    {
      if ( treeP_id[i+1] != treeP_id[i] )
        return true
      else 
        return false
    }
    else
    {
      var actDeep = treeDeep[i]
      for( var j=i+1; j<idx && treeDeep[j] > actDeep ; j++ )
      ;
      if ( j<idx && treeDeep[j] == actDeep )
        return false
      else
        return true
    }
  }

  function showTree()
  {
    for( var i=1, y=y0, x=x0; i<idx; i++ )
    {
      if ( treeIsOn[ id2treeIndex[ treeP_id[i] ] ] )
      {
        // show current node
        if ( !(y == treeLastY[i] && treeIsShown[i] ) )
        {
          showLayer( "sitemap"+ treeId[i] ) 
          setyLayer( "sitemap"+ treeId[i], y )
          treeIsShown[i] = true
        } 
        treeLastY[i] = y
        y += deltaY
      }
      else
      {
        // hide current node and all sons
        if ( treeIsShown[ i ] )
        {
          hideLayer( "sitemap"+ treeId[i] ) 
          treeIsShown[i] = false
        }
      }
    }
  }

  function initIndex() {
    for( var i=0; i<idx; i++ )
      id2treeIndex[ treeId[i] ] = i
  }

  function gif_name (name, width, height) {
    this.on = new Image (width, height);
    this.on.src = imagedir+ "/" +name + "_on.gif"
    this.off = new Image (width, height);
    this.off.src = imagedir+ "/"+name + "_off.gif"
  }

  function load_gif (name, width, height) {
    gif_name [name] = new gif_name (name,width,height);
  }

  function load_all () {
    load_gif ('folder',30,16)
    file_last = new Image( 30,16 )
    file_last.src = imagedir+ "/file_last.gif"
    file_middle = new Image( 30,16 )
    file_middle.src = imagedir+ "/file.gif"
    file_vert = new Image( 30,16 )
    file_vert.src = imagedir+ "/file_vert.gif"
    file_empty = new Image( 30,16 )
    file_empty = imagedir+ "/file_empty.gif"
  }

  function gif_on ( id ) {
    eval("document['folder" + id + "'].src = gif_name['folder'].on.src")
  }

  function gif_off ( id ) {
    eval("document['folder" + id + "'].src = gif_name['folder'].off.src")
  }
 
  // global configuration
  var deltaX = 30
  var deltaY = 16
  var x0 = 5
  var y0 = 5
  var defaultTarget = '_blank'

  var browserName = navigator.appName;
  var browserVersion = parseInt(navigator.appVersion);
  var isIE = false;
  var isNN = false;
  var isDOM = false;
  var isDomIE = false;
  var isDomNN = false;
  var layerok = false;

  var isIE = browserName.indexOf("Microsoft Internet Explorer" )==-1?false:true;
  var isNN = browserName.indexOf("Netscape")==-1?false:true;
  var isOpera = browserName.indexOf("Opera")==-1?false:true;
  var isDOM = document.getElementById?true:false;
  var isDomNN = document.layers?true:false;
  var isDomIE = document.all?true:false;

  if ( isNN && browserVersion>=4 ) layerok=true;
  if ( isIE && browserVersion>=4 ) layerok=true;
  if ( isOpera && browserVersion>=5 ) layerok=true;

    
  function hideLayer(layerName) {
    if (isDOM)
      document.getElementById(layerName).style.visibility="hidden"
    else if (isDomIE)
      document.all[layerName].style.visibility="hidden";
    else if (isDomNN) 
      document.layers[layerName].visibility="hidden";
  }

  function showLayer(layerName) {
    if (isDOM)
      document.getElementById(layerName).style.visibility="visible"
    else if (isDomIE)
      document.all[layerName].style.visibility="visible";
    else if (isDomNN)
      document.layers[layerName].visibility="visible";
  }

  function setyLayer(layerName, y) {
    if (isDOM)
      document.getElementById(layerName).style.top=y
    else if (isDomIE)
      document.all[layerName].style.top=y;
    else if (isDomNN)
      document.layers[layerName].top=y;
  }

  var id2treeIndex = new Array()

  // the structure is easy to understand with a simple example
  // p_id is the id of the parent
  // E0                                      ( id=0,p_id=-1 )
  //          E11                            ( id=1,p_id=0)
  //                     E111                ( id=2,p_id=1 )
  //                     E112                ( id=3,p_id=1 )
  //          E12                            ( id=4,p_id=0 )
  //                     E121                ( id=5,p_id=4 ) 
  //          E13                            ( id=6,p_id=0 ) 
  //                     E131                ( id=7,p_id=6 ) 
  //                                 E1311   ( id=8,p_id=7 ) 
  //                     E132                ( id=9,p_id=6 ) 
  // this is a multinary tree structure which is easy to
  // populate with database data :)
function initArray(){
	var parentObj = 0;
	if(parent.mb_mapObj.length == 0){ window.setTimeout("initArray()",100); }    
	else if(parent.mb_mapObj.length > 0){
		Note(0,-1,'','');
		for(var i=0; i<parent.mb_mapObj.length; i++){
			if(parent.mb_mapObj[i].frameName == mod_treeGDE_map){ 
				for(var ii=0; ii<parent.mb_mapObj[i].wms.length; ii++){
					for (var attr in myCategories) {
						if (typeof(myCategories[attr]) != 'function') {
							if (myCategories[attr] == ii) {
								Note(parseInt(Math.random()*10000),0,"<b>"+attr+"</b>",'','','','','','','');
							}
						}
					}
				
					if(parent.mb_mapObj[i].wms[ii].gui_wms_visible == '1' || parent.mb_mapObj[i].wms[ii].gui_wms_visible == 1){
						for(var iii=0; iii<parent.mb_mapObj[i].wms[ii].objLayer.length; iii++){          
							var temp = parent.mb_mapObj[i].wms[ii].objLayer[iii];     
							if(parent.mb_mapObj[i].wms[ii].objLayer[iii].layer_parent == ""){ 
								//alert((parseInt(temp.layer_id)+1) + " , " +0 + " , " +temp.layer_title + " , " +" , "+temp.layer_metadataurl);
								Note((parseInt(temp.layer_id)+1),0,temp.layer_title,null,'','','','',parent.mb_mapObj[i].wms[ii].wms_id,'');
								parentObj = temp.layer_id+1;                  
							}
							if(parent.mb_mapObj[i].wms[ii].objLayer[iii].layer_parent == "0"){
								//alert((parseInt(temp.layer_id)+1) + " , " +parentObj + " , " +temp.layer_title + " , " +temp.layer_metadataurl);
								if(temp.gui_layer_selectable == '1' || temp.gui_layer_queryable == '1'){
									//alert((parseInt(temp.layer_id)+1) + " , " +parentObj + " , " +temp.layer_title + " , " +temp.layer_metadataurl + " , " +temp.gui_layer_selectable + " , " +temp.gui_layer_visible + " , " +temp.gui_layer_queryable + " , " +temp.gui_layer_querylayer);
									if (temp.layer_uid) {
										Note((parseInt(temp.layer_id)+1),parentObj,temp.layer_title,'../php/mod_layerMetadata.php?id='+temp.layer_uid,temp.gui_layer_selectable,temp.gui_layer_visible,temp.gui_layer_queryable,temp.gui_layer_querylayer,parent.mb_mapObj[i].wms[ii].wms_id,temp.layer_name);
									}
									else {
										Note((parseInt(temp.layer_id)+1),parentObj,temp.layer_title,false,temp.gui_layer_selectable,temp.gui_layer_visible,temp.gui_layer_queryable,temp.gui_layer_querylayer,parent.mb_mapObj[i].wms[ii].wms_id,temp.layer_name);
									}
								}
							}
						}
					}
				}
			}
		}
		treeTyp[0] = 'f'
		treeIsOn[0] = true
		treeWasOn[0] = true
	}       
} 

  var idx=0
  initArray()
  initIndex()
  load_all()
  for( i=1; i<idx; i++ )
  {
    treeDeep[i] = knotDeep( treeId[i] )
    if ( treeDeep[i] == 0 )
      treeIsShown[i] = true
  }
  if ( isDomNN )
    initStyles();
  //-->  
  </SCRIPT>
</HEAD>
<BODY VLINK="#000000" ALINK="#000000" LINK="#000000" BGCOLOR="#ffffff" TEXT="#000000"
 onLoad="if (layerok) showTree();mod_treeGDE();"
 MARGINHEIGHT="0" MARGINWIDTH="0" LEFTMARGIN="0" TOPMARGIN="0">
<SCRIPT language="JavaScript1.2">
<!--
  initDiv()
  hideLayer("sitemapinfo")
//-->
</SCRIPT>
</BODY>
</HTML>
