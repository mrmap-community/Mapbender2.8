<?php
echo "<img src='../img/indicator_wheel.gif'>&nbsp;" . 
	"<b>Ma<font color='#0000CE'>p</font><font color='#C00000'>b</font>ender " . 
	MB_VERSION_NUMBER . " " . strtolower(MB_VERSION_APPENDIX) . "</b>..." .
	"loading application '" . $gui_id . "'";
?>
