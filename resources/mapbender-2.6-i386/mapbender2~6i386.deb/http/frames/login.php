<?php
# $Id: login.php 2746 2008-08-06 14:40:25Z astrid_emde $
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

ob_start(); 
require_once(dirname(__FILE__)."/../../core/globalSettings.php");

function auth_user($name,$pw){
	$setEncPw = false;
	$sql = "SELECT * FROM mb_user WHERE mb_user_name = $1 AND mb_user_password = $2";
	$v = array($name,md5($pw));
	$t = array('s','s');
	$res = db_prep_query($sql,$v,$t);
	if($row = db_fetch_array($res)){
		return $row;
	}
	else if(SYS_DBTYPE == 'pgsql' && $setEncPw == true){
		// 	unencrypted pw in postgres without md5-support?
		$sql = "SELECT * FROM mb_user WHERE mb_user_name = $1 AND mb_user_password = $2";
		$v = array($name,$pw);
		$t = array('s','s');
		$resn = db_prep_query($sql,$v,$t);
		if($rown = db_fetch_array($resn)){
			$sqlu = "UPDATE mb_user SET mb_user_password = $1 WHERE mb_user_id = $2";
			$vu = array(md5($pw),$rown["mb_user_id"]);
			$tu = array('s','i');
			$rowu = db_prep_query($sqlu,$vu,$tu);
			return $rown;
		}
	}
	else if(SYS_DBTYPE == 'mysql' && $setEncPw == true){
		$sql = "SELECT * FROM mb_user WHERE mb_user_name = $1 AND mb_user_password = password($2)";
		$v = array($name,$pw);
		$resn = db_prep_query($sql,$v,$t);
		if($rown = db_fetch_array($resn)){
			$sqlu = "UPDATE mb_user SET mb_user_password = $1 WHERE mb_user_id = $2";
			$vu = array(md5($pw),$rown["mb_user_id"]);
			$tu = array('s','i');
			$rowu = db_prep_query($sqlu,$vu,$tu);
			return $rown;
		}
	}
}
function setSession(){
	session_start();
}
function killSession(){
	if (isset($_COOKIE[session_name()])) {
    	setcookie(session_name(), '', time()-42000, '/');
	}
	if(session_id()){
		session_destroy();
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<!-- 
Licensing: See the GNU General Public License for more details.
http://www.gnu.org/copyleft/gpl.html
or:
mapbender/licence/ 
-->
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Login</title>
<?php
$css_folder = "";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/" . $css_folder . "login.css\">";
$name = $_REQUEST["name"];
$password = $_REQUEST["password"];


if(!isset($name) || $name == ''){
  echo "<script type='text/javascript'>";
  echo "<!--". chr(13).chr(10);
  echo "function setFocus(){";
     echo "if(document.loginForm){";
        echo "document.loginForm.name.focus();";
     echo "}";
  echo "}";
  echo "// -->". chr(13).chr(10);
  echo "</script>";
}
else{
  echo "<script type='text/javascript'>";
  echo "<!--". chr(13).chr(10);
  echo "function setFocus(){";
     echo "if(document.loginForm){";
        echo "document.loginForm.password.focus();";
     echo "}";
  echo "}";
  echo "// -->". chr(13).chr(10);
  echo "</script>";
}

echo "</head>";
echo "<body onload='setFocus()'>";

if(!isset($name) || $name == '' || !isset($password) || $password == ''){
	killSession();
	echo "<form name='loginForm' action ='" . $PHP_SELF . "' method='POST'>";
	echo "<table>";
	echo "<tr><td>Name: </td><td><input type='text' name='name' class='login_text' value=''></td></tr>";
	echo "<tr><td>Password: </td><td><input type='password' name='password' class='login_text'></td></tr>";
	echo "<tr><td></td><td><input type='submit' class='myButton' value='login' title='anmelden'>";
	echo "&nbsp;&nbsp;<a href='../php/mod_forgottenPassword.php' title='Passwort vergessen?' target='_blank'>Forgot your password?</a>";
	echo "</td></tr></table>";
	echo "</form>";
}
if(isset($name) && $name != '' && isset($password) && $password != ''){
	$sql_count = "SELECT mb_user_login_count FROM mb_user WHERE mb_user_name = $1";
	$params = array($name);
	$types = array('s');
	$res_count = db_prep_query($sql_count,$params,$types);
	if($row = db_fetch_array($res_count)){
		if($row["mb_user_login_count"] > MAXLOGIN){
			echo "Permission denied. Login failed ".MAXLOGIN." times. Your account has been deactivated. Please contact your administrator!";
			die();
		}
	}
	
	$row = auth_user($name, $password);
	
	// if given user data is found in database, set session data (db_fetch_array returns false if no row is found)
	if($row){
		setSession();
		include(dirname(__FILE__)."/../../conf/session.conf");
	}	
	if($_SESSION["mb_user_id"]){
		if($row["mb_user_login_count"] <= MAXLOGIN){
			$sql_del_cnt =  "UPDATE mb_user SET mb_user_login_count = 0 WHERE mb_user_id = $1";
			$v = array($_SESSION['mb_user_id']);
			$t = array("i");
			db_prep_query($sql_del_cnt, $v, $t);
			require_once(dirname(__FILE__)."/../php/mb_getGUIs.php");
			$arrayGUIs = mb_getGUIs($row["mb_user_id"]);
			$_SESSION["mb_user_guis"] = $arrayGUIs;
			$_SESSION["mb_login"] = $login;
			# a gui is explicitly ordered
			if((isset($_REQUEST["mb_user_myGui"]) || isset($_SESSION["mb_user_myGui"])) && in_array($_REQUEST["mb_user_myGui"], $arrayGUIs)){
				unset($arrayGUIs);
				if(isset($_REQUEST["mb_user_myGui"])){ $arrayGUIs[0] = $_REQUEST["mb_user_myGui"];}
				else{ $arrayGUIs[0] = $_SESSION["mb_user_myGui"];}
			}
			#only one gui is provided
			if(count($arrayGUIs) == 1){
				if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
					$myURL = "Location: https://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php?".strip_tags (SID)."&gui_id=".$arrayGUIs[0];
				}
				else {
					$myURL = "Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php?".strip_tags (SID)."&gui_id=".$arrayGUIs[0];
				}
				# params for the initial call
				if(isset($_REQUEST["mb_myBBOX"])){
					$myURL .= "&mb_myBBOX=".$_REQUEST["mb_myBBOX"];
				}
				session_write_close();
				header ($myURL);
				exit;
			}
			# list all guis of this user and his groups
			else{	   
				require_once(dirname(__FILE__)."/../php/mb_listGUIs.php");
				mb_listGUIs($arrayGUIs);
			}
		}
	}
	else{
		$sql_set_cnt = "UPDATE mb_user SET mb_user_login_count = (mb_user_login_count + 1) WHERE mb_user_name = $1";
		$v = array($name);
		$t = array('s');
		db_prep_query($sql_set_cnt,$v,$t);				
		if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
			header ("Location: https://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/login.php?name=".$name);
		}
		else {
			header ("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/login.php?name=".$name);
		}
		exit();
	}
}
ob_end_flush();
?>
</body>
</html>
