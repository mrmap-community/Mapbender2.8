<?php
# $Id: nestedSets.php 2811 2008-08-15 08:54:51Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>nestedSets</title>
<?php
include '../include/dyn_css.php';
?>

<style type="text/css">
	<!--
	input{
		width: 164px;
	}
	body{
		font-family : Arial, Helvetica, sans-serif;
		font-size: 12px;
	}
	-->
</style>
</head>
<!-- <link rel='stylesheet' type='text/css' href='administration.css'> -->
<script type="text/javascript">
<!--
function validate(value){
	var permission = true;
	if(value == 'insert'){
		/*
		if(document.forms[0].title.value == ''){alert("Bitte geben Sie einen Titel an."); permission = false; return;}
		if(document.forms[0].left.value == ''){alert("Wählen Sie eine Position."); permission = false; return;}
      	*/
      	if(document.forms[0].title.value == ''){alert("<?php echo _mb("Please insert a title.") ?>"); permission = false; return;}
		if(document.forms[0].left.value == ''){alert("Please choose a position."); permission = false; return;}
      
      if(document.forms[0].wmsList.selectedIndex > 0 && document.forms[0].layer.selectedIndex == 0){alert("Wählen Sie einen Layer."); permission = false; return;}
		if(permission == true){document.forms[0].action.value = "insert"; document.forms[0].submit();}
	}
	if(value == 'delete'){
		//permission = confirm("Soll das Objekt mit Inhalten gelöscht werden?");
		permission = confirm("Do you want to delete the object and the content of the object?");
		if(permission == true){
		document.forms[0].action.value = "delete"; 
		document.forms[0].submit();
		} 
	}
	if(value == 'update'){
		/*
		if(document.forms[0].title.value == ''){alert("Bitte geben Sie einen Titel an."); permission = false; return;}
		if(document.forms[0].left.value == ''){alert("Bitte wählen Sie eine Position."); permission = false; return;}
		*/
		
		if(document.forms[0].title.value == ''){alert("Please fill in a labeling."); permission = false; return;}
		if(document.forms[0].left.value == ''){alert("Please choose a position."); permission = false; return;}

		if(permission == true){document.forms[0].action.value = "update"; document.forms[0].submit();}
	}
	if(value == 'add'){
		/*
		if(document.forms[0].left.value == ''){alert("Bitte wählen Sie eine Position."); permission = false; return;}
		if(document.forms[0].guiList.selectedIndex == 0){alert("Bitte wählen Sie eine GUI."); permission = false; return;}
		if(document.forms[0].wmsList.selectedIndex == 0){alert("Bitte wählen Sie einen WMS."); permission = false; return;}
		if(document.forms[0].layer.selectedIndex == 0){alert("Bitte wählen Sie eine Ebene."); permission = false; return;}
		*/
		
		if(document.forms[0].left.value == ''){alert("Please fill in a position."); permission = false; return;}
		if(document.forms[0].guiList.selectedIndex == 0){alert("Please choose a GUI."); permission = false; return;}
		if(document.forms[0].wmsList.selectedIndex == 0){alert("Please choose a WMS."); permission = false; return;}
		if(document.forms[0].layer.selectedIndex == 0){alert("Please choose a layer."); permission = false; return;}
		
		if(permission == true){document.forms[0].action.value = "add"; document.forms[0].submit();}
	}
}
function rmWMS(obj){
	if(obj.value == ''){
		document.forms[0].wmsList.selectedIndex = 0;
	}
}
// -->
</script>
<body >
<?php

if(isset($action)){	
   if($layer == 'Ordner'){$layer = "";}
}
if(isset($action) && $action == "insert"){
	$temp = explode("###", $layer);
	$sql = "SELECT rgt FROM gui_treegde WHERE lft = $1 AND fkey_gui_id = $2";
	$v = array($left, $guiList);
	$t = array("i", "s");
	$res = db_prep_query($sql, $v, $t);
	if($pos == 'in'){$left = $left + 1;}
	else if($pos == 'hinter'){$left = db_result($res,0,"rgt") + 1;}
	else{ $left = $left + 2;}
	
	$sql = "UPDATE gui_treegde SET rgt=rgt+2 WHERE rgt >= $1 AND fkey_gui_id = $2";
	$v = array($left, $guiList);
	$t = array("i", "s");
	db_prep_query($sql, $v, $t);
#echo $sql . " 1: ".$left." 2:".$guiList."<br>";
	$sql = "UPDATE gui_treegde SET lft=lft+2 WHERE lft >= $1 AND fkey_gui_id = $2";
	$v = array($left, $guiList);
	$t = array("i", "s");
	db_prep_query($sql, $v, $t);
#echo $sql . " 1: ".$left." 2:".$guiList."<br>";

	$sql = "INSERT INTO gui_treegde(fkey_gui_id, fkey_layer_id, lft,rgt, ";
	$sql .= "my_layer_title, layer, wms_id) VALUES($1, $2, $3, $4, $5, $6, $7)";
#echo $sql . "<br>";
	$v = array($guiList, $temp[0], $left, ($left+1), $name, $temp[1], $wmsList);
	$t = array("s", "s", "i", "i", "s", "s", "s");		
	db_prep_query($sql, $v, $t);

	/*
	if($layer == ""){
		$left = $left + 1;
		$sql = "UPDATE gui_treegde SET rgt=rgt+2 WHERE rgt >=". $left." AND fkey_gui_id = '".$guiList."'";
		db_query($sql);
		$sql = "UPDATE gui_treegde SET lft=lft+2 WHERE lft >=".$left." AND fkey_gui_id = '".$guiList."'";
		db_query($sql);
		#hier ist noch was falsch
		$sql = "INSERT INTO gui_treegde(fkey_gui_id,my_layer_title,lft,rgt,layer) VALUES('".$guiList."','new',".$left.",".($left+1).",'new')";
		#echo $sql . "<br />";
		db_query($sql);      
	}
	*/
}
if(isset($action) && $action == "delete"){	
	if($left){
		$sql = "SELECT rgt FROM gui_treegde WHERE lft = $1 AND fkey_gui_id = $2";
		$v = array($left, $guiList);
		$t = array("i", "s");
		$res = db_prep_query($sql, $v, $t);
		$right = db_result($res,0,"rgt");
		
		$sql = "DELETE FROM gui_treegde WHERE lft BETWEEN $1 and $2 AND fkey_gui_id = $3";
		$v = array($left, $right, $guiList);
		$t = array("i", "i", "s");
		db_prep_query($sql, $v, $t);

		$sql = "UPDATE gui_treegde SET lft=lft-$1 WHERE lft > $2 AND fkey_gui_id = $3";
		$v = array($right-$left+1, $right, $guiList);
		$t = array("i", "i", "s");
		db_prep_query($sql, $v, $t);
#echo $sql . " r:".$right." l:".$left." 2:".$guiList."<br>";
		$sql = "UPDATE gui_treegde SET rgt=rgt-$1 WHERE rgt > $2 AND fkey_gui_id = $3";
		$v = array($right-$left+1, $right, $guiList);
		$t = array("i", "i", "s");
#echo $sql . " r:".$right." l:".$left." 2:".$guiList."<br>";
		db_prep_query($sql, $v, $t);
	}
}
if(isset($action) && $action == "update"){
	$temp = explode("###", $layer);
	$sql = "UPDATE gui_treegde SET ";
	$sql .= "my_layer_title = $1, ";
	$sql .= "fkey_layer_id = $2, ";
	$sql .= "layer = $3, ";
	$sql .= "wms_id = $4";
	$sql .= " WHERE lft = $5 AND fkey_gui_id = $6";
	$v = array($name, $temp[0], $temp[1], $wmsList, $left, $guiList);
	$t = array("s", "s", "s", "s", "i", "s");
	db_prep_query($sql, $v, $t);
}
if(isset($action) && $action == "add"){
	$temp = explode("###", $layer);
	
	$sql_val = "SELECT * FROM gui_treegde WHERE lft = $1 AND fkey_gui_id = $2";
	$v = array($left, $guiList);
	$t = array("i", "s");
	$res_val = db_prep_query($sql_val, $v, $t);
	
	$sql = "UPDATE gui_treegde SET ";
	$sql .= "fkey_layer_id = $1, layer = $2, wms_id =  $3 ";
	$sql .= "WHERE lft = $4 AND fkey_gui_id = $5";

	$v = array();
	$t = array("s", "s", "s", "i", "s");	

	if (db_result($res_val, 0, "fkey_layer_id") != '') {
		array_push($v, db_result($res_val, 0, "fkey_layer_id") . "," . $temp[0]);
	}
	else {
		array_push($v, $temp[0]);
	}
	
	if (db_result($res_val, 0, "layer") != '') {
		array_push($v, db_result($res_val, 0, "layer") . "," . $temp[1]);
	}
	else {
		array_push($v, $temp[1]);
	}
	
	if (db_result($res_val, 0, "wms_id") != '') {
		array_push($v, db_result($res_val, 0, "wms_id") . "," . $wmsList);
	}
	else {
		array_push($v, $wmsList);
	}
	array_push($v, $left);	
	array_push($v, $guiList);	
	db_prep_query($sql, $v, $t);
}
?>
<br />
<b>Create your own tree for your GUI. Include the element treeconfGDE to see this tree</b><br />
Find detailed infos in the (<a href='http://www.mapbender.org/index.php/ConfTreeGde' target='_blank'>Mapbender Wiki</a>)<br />
1. Select the GUI you want to create the new tree for <br />
2. Select an element in the folder view<br />
<br />
<br />
<!-- -->
<?php
if(isset($guiList) && $guiList != ""){
	echo "<iframe ID='foldertree' name='foldertree' height='400' width='300' src='mod_treefolderAdmin.php?guiList=".$guiList."' scrolling='auto' frameborder='1'></iframe>";
}
else{
	echo "<iframe ID='foldertree' name='foldertree' height='400' width='300' src='../html/mod_blank.html' scrolling='auto' frameborder='1'></iframe>";
}
?>

<div style='position:absolute;top:50px;left:350px'>
<form action='<?php $self; ?>' method='POST'>
<br><br>
<table >
<tr><td></td><td></td></tr>
<?php
require_once(dirname(__FILE__)."/../classes/class_administration.php");
$admin = new administration();
$ownguis = $admin->getGuisByOwner($_SESSION["mb_user_id"],true);

$sql = "SELECT * FROM gui WHERE gui_id IN ("; 
$v = $ownguis;
$t = array();
for ($i = 1; $i <= count($ownguis); $i++){
	if ($i > 1) { 
		$sql .= ",";
	}
	$sql .= "$" . $i;
	array_push($t, "s");
}
$sql .= ") ORDER BY gui_name";

$res = db_prep_query($sql, $v, $t);
$cnt = 0;
echo "<select class='guiList' size='10' name='guiList' class='guiList'  onchange='document.forms[0].submit()'>";
echo "<option value=''>GUI ...</option>";
while($row = db_fetch_array($res)){
	echo "<option value='".$row["gui_id"]."' ";
	if(isset($guiList) && $guiList == $row["gui_id"]){
		echo "selected";
	}
	echo ">".$row["gui_name"]."</option>";
	$cnt++;
}
echo "</select><br>";
echo "<tr>";
   #echo "<td>Beschriftung:</td>";
   echo "<td>Labeling:</td>";
   echo "<td><input type='text' size='16' name='name' value='";
   echo $name;
   echo "'></td>";
echo "</tr>";
?>
<tr>
<td>WMS: </td>
<td>
	<select name='wmsList' onchange='document.forms[0].submit()'>
	<option value=''>WMS ...</option>
	<?php
	if(isset($guiList) && $guiList != ""){
		$sql = "SELECT gui_wms.fkey_wms_id, wms.wms_title FROM gui_wms ";
		$sql .= "INNER JOIN wms ON gui_wms.fkey_wms_id = wms.wms_id  ";
		$sql .= "WHERE gui_wms.fkey_gui_id = $1 ";
		$sql .= "ORDER BY wms.wms_title";
		$v = array($guiList);
		$t = array("s");
		$res = db_prep_query($sql, $v, $t);
		$cnt = 0;
		while($row = db_fetch_array($res)){
			echo "<option value='".$row["fkey_wms_id"]."' ";
			if($wmsList == $row["fkey_wms_id"]){
				echo "selected";
			}
			echo ">";
			echo $row["wms_title"];
			echo "</option>";
			$cnt++;
		}
	}
	
	else{echo "<option value=''>no gui selected</option>";}
	echo"</select>";
	echo"</td>   </tr><tr>";
	#echo"<td>Ordner oder Ebene: </td>";
	echo"<td>Folder or Layer: </td>";
	echo"<td>";
	echo"<select name='layer' onchange='rmWMS(this)'>";
	#echo"<option value=''>Ordner</option>";
	echo"<option value=''>Folder</option>";
	if(isset($wmsList) && $wmsList != ""){
		$sql_l = "SELECT gui_layer.fkey_layer_id, layer.layer_name, layer.layer_title FROM gui_layer ";
		$sql_l .= "LEFT JOIN layer ON gui_layer.fkey_layer_id = layer.layer_id ";
		$sql_l .= "WHERE gui_layer.gui_layer_wms_id = $1 AND layer.layer_parent = '0' AND gui_layer.fkey_gui_id = $2";
		$sql_l .= " ORDER BY layer.layer_title";
		$v = array($wmsList, $guiList);
		$t = array("i", "s");
		$res_l = db_prep_query($sql_l, $v, $t);
		$cnt = 0;
		while($row = db_fetch_array($res_l)){
			echo "<option value='".$row["fkey_layer_id"]."###".$row["layer_name"]."'>";
			echo $row["layer_title"];
			echo "</option>";
			$cnt++;
		}
	}
	?>
	</select>
</td>   
</tr>
<tr>
   <td>Position: </td>
   <td>
   <select name='pos'>
<?php
	#echo "<option value='hinter'>hinter</option>";
	echo "<option value='hinter'>behind</option>";
	echo "<option value='in' ";
	if($pos == 'in'){
		echo "selected";
	}
	echo ">in</option>";
	echo"</select>      </td>   </tr><tr>";
	#echo"<td>Hinter bzw. in Element Nr.:</td>";
	echo"<td>Insert behind or <br>in element with number:</td>";
	echo "<td><input type='text' size='1' name='left' ";
	if($left)
	{ 
		echo "value='".$left."'"; 
	}
	echo "></td>";
?>
</tr>
<tr>
	<td>
	<!--<input class='abutton' type='button' name="insert" value='einf&uuml;gen' onclick="validate('insert')"></td>
	-->
	<input class='abutton' type='button' name="insert" value='create new element' onclick="validate('insert')"></td>
	<td></td>
</tr>
<tr>
	<td>
	<!--
	<input class='abutton' type='button' name="delete" value='l&ouml;schen' onclick="validate('delete')"></td>
	-->
	<input class='abutton' type='button' name="delete" value='delete element' onclick="validate('delete')"></td>
   <td></td>
</tr>
<tr>
	<td>
	<!--
	<input class='abutton' type='button' name="update" value='&amlndern' onclick="validate('update')"></td>
	-->
	<input class='abutton' type='button' name="update" value='change element' onclick="validate('update')"></td>
	<td></td>
</tr>
<tr>
	<td>
	<!--
	<input class='abutton' type='button' name="update" value='Ebene verbinden' onclick="validate('add')"></td>
	-->
	<input class='abutton' type='button' name="update" value='join layer' onclick="validate('add')"></td>
	<td></td>
</tr>
<input type='hidden' name="action">
</table>
</form>
</div>
</body>
</html>
