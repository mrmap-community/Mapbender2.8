<?php
# $Id: mod_editSelf.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_editSelf.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Edit User Settings</title>
<style type="text/css">
  	<!--
  	body{
  		font-family: Arial, Helvetica, sans-serif;
  		font-size : 12px;
  		color: #808080
  	}
  	.list_guis{
  		font-family: Arial, Helvetica, sans-serif;
  		font-size : 12px;
  		color: #808080;
  	}
  	a:link{
  		font-family: Arial, Helvetica, sans-serif;
  		font-size : 12px;
  		text-decoration : none;
  		color: #808080;
  	}
  	a:visited {
  		font-family: Arial, Helvetica, sans-serif;
  		text-decoration : none;
  		color: #808080;
  		font-size : 12px;
  	}
  	a:active {
  		font-family: Arial, Helvetica, sans-serif;
  		text-decoration : none;
  		color: #808080;
  		font-size : 12px;
  	}
  	-->
</style>
<?php
$myPW = "**********";
echo "<script language='JavaScript'>var myPW = '".$myPW."';</script>";
?>
<script language="JavaScript">

function validate(val){
   var ok = validateInput();
   if(ok == 'true'){
     var permission = false;
     if(val == 'save'){
        permission = confirm("Save changes?");
     }
     if(val == 'update'){
        permission = confirm("Save changes?");
     }
     if(val == 'delete'){
        permission = confirm("Delete User?");
     }
     if(permission == true){
        if(document.forms[0].passw.value == myPW){
            document.forms[0].passw.value = '';
        }
        document.forms[0].action.value = val;
        document.forms[0].submit();
     }
   }
}
function validateInput(){
  var str_alert = "Input incorrect !";
  if(document.forms[0].name.value == ''){
      alert(str_alert);
      document.forms[0].name.focus();
      return 'false';
  }
  if(document.forms[0].passw.value == ''){
      alert(str_alert);
      document.forms[0].passw.focus();
      return 'false';
  }
  if((document.forms[0].passw.value != myPW || document.forms[0].v_password.value != '' )&& document.forms[0].passw.value != document.forms[0].v_password.value){
      alert("Password verification failed. You have to enter the same password twice!");
      document.forms[0].passw.value = myPW;
      document.forms[0].passw.focus();
      return 'false';
  }
  if(document.forms[0].resolution.value == ''){
      document.forms[0].resolution.value = 72;
      return 'true';
  }
  if(document.forms[0].login_count.value == ''){
      document.forms[0].login_count.value = 0;
      return 'true';
  }
  return 'true';
}

</script>

</head>
<body>
<?php
#delete
if($action == 'delete'){
   $sql = "DELETE FROM mb_user WHERE mb_user_id = $1 ";
   $v = array($selected_user);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   session_destroy();
   echo "You have deleted your account.<br><br>";
   die();

}

#save
if($action == 'save'){
	$sql = "SELECT mb_user_id FROM mb_user WHERE mb_user_name = $1 ";
	$v = array($name);
	$t = array('s');
	$res = db_prep_query($sql,$v,$t);
   if(db_fetch_row($res)){
      echo "<script language='JavaScript'>alert('Username must be unique!');</script>";
   }
   else{
		$sql = "Insert INTO mb_user (mb_user_name, mb_user_password,mb_user_owner, mb_user_description,";
		$sql .= " mb_user_email, mb_user_phone, mb_user_department, mb_user_resolution) VALUES ";
		$sql.= "($1, $2, $3, $4, $5, $6, $7, $8)";
		$v = array($name,md5($passw),$owner_id,$description,$email,$phone,$department,$resolution);
		$t = array('s','s','i','s','s','s','s','i');
		$res = db_prep_query($sql,$t,$v);
		$selected_user = db_insert_id();
   }
}

#update
if($action == 'update'){
	$sql = "SELECT mb_user_id FROM mb_user WHERE mb_user_name = $1 AND mb_user_id <> $2";
	$v = array($name,$selected_user);
	$t = array('s','i');
	$res = db_prep_query($sql,$v,$t);
	if(db_fetch_row($res)){
		echo "<script language='JavaScript'>alert('Username must be unique!');</script>";
	}
	else{
		if($passw == ""){
			$sql = "SELECT mb_user_password FROM mb_user WHERE mb_user_name = $1 AND mb_user_id = $2";
			$v = array($name,$selected_user);
			$t = array('s','i');
			$res = db_prep_query($sql,$v,$t);
			if($row = db_fetch_row($res)){
				$p = $row["mb_user_password"];	
			}
		}
		else{
			$p = md5($passw);
			$password = true;
		}
		$sql = "UPDATE mb_user SET mb_user_name = $1";
		$sql .= ", mb_user_password = $2";
		$sql .=", mb_user_description = $3";
		$sql .=", mb_user_login_count = $4";
		$sql .=", mb_user_email = $5";
		$sql .=", mb_user_phone = $6";
		$sql .=", mb_user_department = $7";
		$sql .=", mb_user_resolution = $8";
		$sql .=" where mb_user_id = $9";
		$v = array($name,$p,$description,$login_count,$email,$phone,$department,$resolution,$selected_user);
		$t = array('s','s','s','i','s','s','s','i','i');
		$res = db_prep_query($sql,$v,$t);
		if($password && $res){
			echo "<script language='JavaScript'>alert('Password has been updated successfully!');</script>";
		}
	}
}
if (!isset($name) || $selected_user == 'new'){
  $name = "";
  $password = "";
  $owner_id = $_SESSION["mb_user_id"];
  $owner_name = $_SESSION["mb_user_name"];
  $description = "";
  $login_count = 0;
  $email = "";
  $phone = "";
  $department = "";
  $resolution = 72;
}

$selected_user = $_SESSION["mb_user_id"];

/*HTML*****************************************************************************************************/

echo "<form name='form1' action='" . $self ."' method='post'>";
echo "<input type='hidden' name='selected_user' value='" . $_SESSION["mb_user_id"] . "'>";
echo "<table border='0'>";

if(isset($selected_user) && $selected_user != 0){
   $sql = "SELECT * FROM mb_user WHERE mb_user_id = $1";
   $v = array($_SESSION["mb_user_id"]);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   if($row = db_fetch_array($res)){
      $name = $row["mb_user_name"];
      $password = $row["mb_user_password"];
      $owner_id = $row["mb_user_owner"];
      $description = $row["mb_user_description"];
      $login_count = $row["mb_user_login_count"];
      $email = $row["mb_user_email"];
      $phone = $row["mb_user_phone"];
      $department = $row["mb_user_department"];
      $resolution = $row["mb_user_resolution"];
	  $owner_id = $_SESSION["mb_user_id"];
   	$edit = true;
   }
   else {
   	$edit = false;
	echo "You're not allowed to change the settings!";
   }
}

if ($edit) {
#name
echo "<tr>";
	echo "<td>Name:</td>";
	echo "<td>";
      echo "<input type='text' size='30' name='name' value='".$name."'>";
   echo "</td>";
echo "</tr>";

#password
echo "<tr>";
   echo "<td>Password: </td>";
   echo "<td>";
      echo "<input type='password' size='30' name='passw' value='";
      if(isset($selected_user) && $selected_user != 'new'){
         echo $myPW;
      }
      echo "'>";
   echo "</td>";
echo "</tr>";

#confirm password
echo "<tr>";
   echo "<td>Confirm password: </td>";
   echo "<td>";
      echo "<input type='password' size='30' name='v_password' value='";
      echo "'>";
   echo "</td>";
echo "</tr>";

#owner
echo "<tr>";
   echo "<td>Owner: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='owner_name' value='".$owner_name."' readonly>";
      echo "<input type='hidden' size='30' name='owner_id' value='".$owner_id."' readonly>";
   echo "</td>";
echo "</tr>";

#description
echo "<tr>";
   echo "<td>Description: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='description' value='".$description."'>";
   echo "</td>";
echo "</tr>";


#login_count
echo "<tr>";
   echo "<td>Login_count: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='login_count' value='".$login_count."'>";
   echo "</td>";
echo "</tr>";

#email
echo "<tr>";
   echo "<td>Email: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='email' value='".$email."'>";
   echo "</td>";
echo "</tr>";

#phone
echo "<tr>";
   echo "<td>Phone: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='phone' value='".$phone."'>";
   echo "</td>";
echo "</tr>";

#department
echo "<tr>";
   echo "<td>Department: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='department' value='".$department."'>";
   echo "</td>";
echo "</tr>";

#resolution
echo "<tr>";
   echo "<td>Resolution: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='resolution' value='".$resolution."'>";
   echo "</td>";
echo "</tr>";
echo"</table>";
if($selected_user == 'new' || !isset($selected_user)){
   echo "<input type='button' value='save'  onclick='validate(\"save\")'>";
}
if($_SESSION["mb_user_id"] == $owner_id && $selected_user != '' ){
   echo "<input type='button' value='save'  onclick='validate(\"update\")'>";
   echo "<input type='button' value='delete'  onclick='validate(\"delete\")'>";
}
}
?>
<input type='hidden' name='action' value=''>
</form>
</body>
</html>