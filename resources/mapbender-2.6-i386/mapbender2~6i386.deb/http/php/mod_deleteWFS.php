<?php
# $Id: mod_deleteWFS.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/DeleteWFS
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
require_once(dirname(__FILE__)."/../classes/class_administration.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Delete WFS - All Users</title>
<?php
include '../include/dyn_css.php';
?>
<script type="text/javascript">
function validate(){
	var ind = document.form1.wfsList.selectedIndex;
	if(ind > -1){
		var permission =  confirm("delete: "  + document.form1.wfsList.options[ind].text + " ?");
		if(permission === true){
			document.form1.del.value = 1;
			document.form1.submit();
		}
	}
}
</script>

<style type="text/css">
  	<!--
  	body{
      background-color: #ffffff;
  		font-family: Arial, Helvetica, sans-serif;
  		font-size : 12px;
  		color: #808080
  	}
  	
  	-->
</style>
</head>
<body>

<?php
$logged_user_name=$_SESSION["mb_user_name"];
$logged_user_id=$_SESSION["mb_user_id"];

###delete
if($wfsList){
	 $sql = "DELETE FROM wfs WHERE wfs_id = $1";
	 $v = array($wfsList);
	 $t = array("i");
	 $res = db_prep_query($sql, $v, $t);
}

$sql_wfs = "SELECT * FROM wfs ORDER BY wfs_id";
$res_wfs = db_query($sql_wfs);
$cnt_wfs = 0;

echo "<form name='form1' action='" . $self ."' method='post'>"; 
echo "<br><b>WFS List: <b><br><br>";
echo "<select class='wfsList' size='20' name='wfsList' >";

while($row = db_fetch_array($res_wfs)){
	echo "<option value='".$row["wfs_id"]."'>".$row["wfs_id"]." ".$row["wfs_name"]." - ".$row["wfs_title"]."</option>";
	$cnt_wfs++;
}
echo "</select><br><br>";
echo "<input class='button_del' type='button' value='delete' onclick='validate()'>";
?>
<input type='hidden' name='del'>
</form>
</body>
</html>
