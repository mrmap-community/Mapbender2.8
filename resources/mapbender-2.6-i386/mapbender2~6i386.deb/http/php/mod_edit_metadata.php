<?php
# $Id: mod_edit_metadata.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_edit_metadata.php
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
include(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Edit Metadata</title>
<?php
include '../include/dyn_css.php';
?>
<style type="text/css">
   <!--
   body{
      background-color: #ffffff;
  		font-family: Arial, Helvetica, sans-serif;
  		font-size : 12px;
  		color: #808080
  	}
   .guiList1{
   	position:absolute;
   	top:30px;
   	left:10px;
   	width:200px
   }
   .buttonbar{
   	position:absolute;
   	top:40px;
   	left:10px;
   }
   .guiList1_text{
   	position:absolute;
   	top:10px;
   	left:10px;
      font-size:16px;
      color: #0066cc;
   }
   .guiList2{
   	position:absolute;
   	top:40px;
   	left:400px;
   	width:200px
   }
   .all{
   	position:absolute;
   	top:38px;
   	left:610px;
   }
   .guiList2_header{
   	position:absolute;
   	top:10px;
   	left:400px;
      font-size:16px;
      color: #0066cc;
   }
   .myElements{
   	position:absolute;
   	top:70px;
   	left:400px;
   }
   .myTable{
   	border: 1px solid;
      font-size: 11px;
   }
   .myForm{
   	position:absolute;
   	top:70px;
   	left:10px;
   }
   .textfield{
      width:277px
   }
   .textfield_small{
      width:150px
   }
   .on{
      color: #0066cc;
   }
   -->
</style>
<?php
# handle database updates etc.....
if(isset($mySave) && ($mySave == '1' || $mySave == '2')) {
   if ($mySave == '1'){
   	$sql_vars = "SELECT * FROM gui_element_vars WHERE fkey_e_id = $1 AND fkey_gui_id = $2";
   	$v = array($e_id, $guiList1);
   	$t = array("s", "s");
   	$res_vars = db_prep_query($sql_vars, $v, $t);
   	 //$rows = db_fetch_array($res_vars);
	$sql = array();
	$v = array();
	$t = array();
	if ($SYS_DBTYPE == "pgsql") {
		$sql[0] = "SET AUTOCOMMIT=1";
		$v[0] = array();
		$t[0] = array();
	}
	else {
		$sql[0] = "SET AUTOCOMMIT=0";
		$v[0] = array();
		$t[0] = array();
	}
	$sql[1] = "BEGIN";
	$v[1] = array();
	$t[1] = array();
	
	$sql[2] = "DELETE FROM gui_element WHERE e_id = $1 AND fkey_gui_id = $2";
	$v[2] = array($e_id, $guiList1);
	$t[2] = array("s", "s");

	if($e_left < 1){$e_left = "NULL";}
	if($e_top < 1){$e_top = "NULL";}
	if($e_width < 1){$e_width = "NULL";}
	if($e_height < 1){$e_height = "NULL";}
	if($e_z_index < 1){$e_z_index = "NULL";}

	$sql[3] = "INSERT INTO gui_element (fkey_gui_id, e_id, e_pos, e_public, ";
	$sql[3] .= "e_comment, e_element, e_src, e_attributes, e_left, e_top, ";
	$sql[3] .= "e_width, e_height, e_z_index, e_more_styles, e_content, ";
	$sql[3] .= "e_closetag, e_js_file, e_mb_mod, e_target, e_requires) ";
	$sql[3] .= "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, ";
	$sql[3] .= "$13, $14, $15, $16, $17, $18, $19, $20)";
	$v[3] = array($guiList1, $e_id, $e_pos, $e_public, db_escape_string($e_comment), $e_element, $e_src, db_escape_string($e_attributes), $e_left, $e_top, $e_width, $e_height, $e_z_index, $e_more_styles, db_escape_string($e_content), $e_closetag, $e_js_file, $e_mb_mod, $e_target, $e_requires);
	$t[3] = array("s", "s", "s", "s", "s", "s", "s", "s", "i", "i", "i", "i", "i", "s", "s", "s", "s", "s", "s", "s");
   }
   # mySave == 2 <=> just save GUI description
   elseif ($mySave == '2') {
		$sql = array();
		$v = array();
		$t = array();
		if ($SYS_DBTYPE == "pgsql") {
			$sql[0] = "SET AUTOCOMMIT=1";
			$v[0] = array();
			$t[0] = array();
		}
		else {
			$sql[0] = "SET AUTOCOMMIT=0";
			$v[0] = array();
			$t[0] = array();
		}
		$sql[1] = "BEGIN";
		$v[1] = array();
		$t[1] = array();

		$sql[2] = "UPDATE gui SET gui_description = $1 WHERE gui_id = $2";
		$v[2] = array($guiDesc, $guiId);
		$t[2] = array("s", "s");
	}
	for ($i = 0; $i < count($sql); $i++) {
      $res = db_prep_query($sql[$i], $v[$i], $t[$i]);
      if(!$res){break;}
   }
   if($res){
		$res = db_query( "COMMIT");
      $res = db_query( "SET AUTOCOMMIT=1");
   }
   else{
      $res = db_query( "ROLLBACK");
      $res = db_query( "SET AUTOCOMMIT=1");
   }
   if(isset($sql_vars)){//sicherstellen das keine Element_Vars gel�scht wurden
   	 while($row =  db_fetch_array($res_vars)){
			$securesql = "INSERT INTO gui_element_vars (fkey_gui_id, ";
			$securesql .= "fkey_e_id, var_name, var_value, context,type) ";
			$securesql .= "VALUES ($1, $2, $3, $4, $5, $6)";
			$v = array($guiList1, $e_id, $row["var_name"], $row["var_value"], $row["context"], $row["type"]);
			$t = array("s", "s", "s", "s", "s", "s");
			//echo $securesql."<BR>";
			$secureinsert = db_prep_query($securesql, $v, $t);
		}
	}
      if(!$res){break;}

}
if(isset($myDelete) && $myDelete == '1'){
   $sql = "DELETE FROM gui_element WHERE e_id = $1 AND fkey_gui_id = $2";
   $v = array($e_id, $guiList1);
   $t = array("s", "s");
   $res = db_prep_query($sql, $v, $t);
   $e_id = ""; $e_pos = ""; $e_public = ""; $e_comment = ""; $e_element = "";
   $e_src = ""; $e_attributes = ""; $e_left = ""; $e_top = ""; $e_width = ""; $e_height = ""; $e_z_index = "";
   $e_more_styles = ""; $e_content = ""; $e_closetag = ""; $e_js_file = ""; $e_mb_mod = ""; $e_target = ""; $e_requires = "";
}
if(isset($myShow) && $myShow == '1'){
   $_SESSION["mb_user_myGui"] = $guiList1;
   echo "<script language='javascript'>";
   echo "window.open('../frames/login.php?".strip_tags (SID)."&mb_user_myGui=".$guiList1."','','');";
   echo "</script>";
}
if(isset($all) && $all == '1'){
   $sql = "SELECT * FROM gui_element WHERE fkey_gui_id = $1";
   $v = array($guiList2);
   $t = array("s");
   $res = db_prep_query($sql, $v, $t);
   $cnt = 0;
   while(db_fetch_row($res)){
      $sql_del = "DELETE FROM gui_element WHERE fkey_gui_id = $1 AND e_id = $2";
      $v = array($guiList1, db_result($res,$cnt,"e_id"));
      $t = array("s", "s");
      $res_del = db_prep_query($sql_del, $v, $t);
      if(db_result($res,$cnt,"e_left") == ""){$myleft = 'NULL';} else{$myleft = db_result($res,$cnt,"e_left");}
      if(db_result($res,$cnt,"e_top") == ""){$mytop = 'NULL';} else{$mytop = db_result($res,$cnt,"e_top");}
      if(db_result($res,$cnt,"e_width") == ""){$mywidth = 'NULL';} else{$mywidth = db_result($res,$cnt,"e_width");}
      if(db_result($res,$cnt,"e_height") == ""){$myheight = 'NULL';} else{$myheight = db_result($res,$cnt,"e_height");}
      if(db_result($res,$cnt,"e_z_index") == ""){$my_z_index = 'NULL';} else{$my_z_index = db_result($res,$cnt,"e_z_index");}

      $sql_ins = "INSERT INTO gui_element (fkey_gui_id, e_id, e_pos, e_public, ";
      $sql_ins .= "e_comment, e_element, e_src, e_attributes, e_left, e_top, ";
      $sql_ins .= "e_width, e_height, e_z_index, e_more_styles, e_content, ";
      $sql_ins .= "e_closetag, e_js_file, e_mb_mod, e_target, e_requires) ";
      $sql_ins .= "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, ";
      $sql_ins .= "$10, $11, $12, $13, $14, $15, $16, $17, $18, $19);";
      $v = array($guiList1, db_result($res,$cnt,"e_id"), db_result($res,$cnt,"e_pos"), db_result($res,$cnt,"e_public"), db_escape_string(db_result($res,$cnt,"e_comment")), db_result($res,$cnt,"e_element"), db_result($res,$cnt,"e_src"), db_escape_string(db_result($res,$cnt,"e_attributes")), $myleft, $mytop, $mywidth, $myheight, $my_z_index, db_result($res,$cnt,"e_more_styles"), db_escape_string(db_result($res,$cnt,"e_content")), db_result($res,$cnt,"e_closetag"), db_result($res,$cnt,"e_js_file"), db_result($res,$cnt,"e_mb_mod"), db_result($res,$cnt,"e_target"), db_result($res,$cnt,"e_requires"));
      $t = array("s", "s", "s", "s", "s", "s", "s", "s", "i", "i", "i", "i", "i", "s", "s", "s", "s", "s", "s", "s");
		
      $res_ins = db_prep_query($sql_ins, $v, $t);
      if(!$res_ins){echo db_error($con); }
      $cnt++;
   }
   $sql = "SELECT * FROM gui_element_vars WHERE fkey_gui_id = $1";
   $v = array($guiList2);
   $t = array("s");
      $res = db_prep_query($sql, $v, $t);
   	$cnt = 0;
       while(db_fetch_row($res)){
      $sql_ins2 = "INSERT INTO gui_element_vars (fkey_gui_id, fkey_e_id, ";
      $sql_ins2 .= "var_name, var_value, context, type) VALUES (";
      $sql_ins2 .= "$1, $2, $3, $4, $5, $6);";
      $v = array($guiList1, db_result($res,$cnt,"fkey_e_id"), db_result($res,$cnt,"var_name"), db_escape_string(db_result($res,$cnt,"var_value")), db_escape_string(db_result($res,$cnt,"context")), db_result($res,$cnt,"type"));
      $t = array("s", "s", "s", "s", "s", "s");
      $res_ins2 = db_prep_query($sql_ins2, $v, $t);
      if(!$res_ins2){echo db_error($connect); }

      $cnt++;
      }


}
# end
echo "<script language='javascript'>";
echo "var guiIDs = new Array();";
if(isset($guiList1)){
   $sql = "SELECT e_id FROM gui_element WHERE  fkey_gui_id = $1";
   $v = array($guiList1);
   $t = array("s");
   $res = db_prep_query($sql, $v, $t);
   $cnt = 0;
   while(db_fetch_row($res)){
      echo  "guiIDs[".$cnt."] = '".db_result($res,$cnt,"e_id")."'; ";
      $cnt++;
   }
}
echo "</script>";
?>
<script type="text/javascript">
<!--
function setGui(val){
   document.form1.guiList2.value = val;
   document.form1.submit();
}
function clearRadio(){
   for(var i=0; i< document.form1.elements.length; i++){
      if(document.form1.elements[i].type == "radio"){
         document.form1.elements[i].checked = false;
      }
   }
}
function thisSave(){
   if(document.form1.e_id.value == ""){
      alert("ID ? ");
      document.form1.e_id.focus();
      return;
   }
   var permission = false;
   var isElement = false;
   for(var i=0; i<guiIDs.length; i++){
      clearRadio();
      if(document.form1.e_id.value == guiIDs[i]){
         permission = confirm("update: " + document.form1.e_id.value + " ?");
         isElement = true;
         break;
      }
   }
   if(permission == true || isElement == false){
      document.form1.mySave.value = 1;
      document.form1.submit();
   }
}

function thisDelete(){
   clearRadio();
   var permission =  confirm("delete: " + document.form1.e_id.value + " ?");
   if(permission == true){
      document.form1.myDelete.value = 1;
      document.form1.submit();
   }
}
function thisShow(){
   document.form1.myShow.value = 1;
   document.form1.submit();
}
function addAll(){
   var permission =  confirm("add all elements ?");
   if(permission == true){
      clearRadio();
      document.form1.all.value = 1;
      document.form1.submit();
   }
}
function thisExport(){

   window.open("mod_exportElement.php?element=" + document.forms[0].e_id.value+ "&gui=" +document.forms[0].guiList1.value ,"","");
}
function editDesc(){
	var newDesc = prompt("Enter new GUI description", document.form1.guiDesc.value);
	if (newDesc != null) {
		document.form1.guiDesc.value = newDesc;
		document.form1.mySave.value = 2;
		document.form1.submit();
	}
}

// -->
</script>
</head>
<body>

<?php
require_once(dirname(__FILE__)."/../classes/class_administration.php");
$admin = new administration();
$ownguis = $admin->getGuisByOwner($_SESSION["mb_user_id"],true);
$permguis = $admin->getGuisByPermission($_SESSION["mb_user_id"],true);
echo "<form name='form1' action='" . $self ."' method='post'>\n";

$sql = "SELECT * from gui WHERE gui.gui_id IN (";
$v = $ownguis;
$t = array();

for ($i = 1; $i <= count($ownguis); $i++) {
	if ($i > 1) {
		$sql .= ",";
	}
	$sql .= "$" . $i;
	array_push($t, "s");
}
$sql .= ")";
//echo $sql;
$res = db_prep_query($sql, $v, $t);
$count=0;
while(db_fetch_row($res)){
	$gui_id_own[$count]=db_result($res,$count,"gui_id");
	$gui_name_own[$count]=db_result($res,$count,"gui_name");
	$gui_description_own[$count]=db_result($res,$count,"gui_description");
	$count++;
}


$sql = "SELECT * from gui WHERE gui.gui_id IN (";
$v = $permguis;
$t = array();

for ($i = 1; $i <= count($permguis); $i++){
	if ($i > 1) { 
		$sql .= ",";
	}
	$sql .= "$" . $i;
	array_push($t, "s");
}
$sql .= ")";
$res = db_prep_query($sql, $v, $t);
$count=0;
while($row = db_fetch_array($res)){
	$gui_id_perm[$count]= $row["gui_id"];
	$gui_name_perm[$count]=$row["gui_name"];
	$gui_description_perm[$count]=$row["gui_description"];
	$count++;
}

#Gui to edit
if(!isset($guiList1)){
	echo "<div class= 'guiList1_text'>GUI:</div>\n";
	echo "<select class='guiList1' size='20' name='guiList1' onchange='setGui(this.value)'>\n";
	for ($i=0; $i<count($gui_id_own);$i++){
		echo "<option value='".$gui_id_own[$i]."' ";
		if($guiList1 && $guiList1 == $gui_id_own[$i]){
			echo "selected";
		}
		echo ">".$gui_name_own[$i]."</option>\n";
	}
	echo "</select>\n";

	for ($i=0; $i<count($gui_id_own);$i++){
		echo "<input type='hidden'  name='guiDesc_" . $gui_name_own[$i] . "' value='" . $gui_description_own[$i] . "' >\n";
	    echo "<input type='hidden'  name='guiId_" . $gui_name_own[$i] . "' value='" . $gui_id_own[$i] . "' >\n";
	}
	echo "<input type='hidden'  name='guiList2' value='' >\n";
}
else{
   echo "<div class= 'guiList1_text'>";
   echo 	"Edit Elements: ".$guiList1;

   // set guiDesc and guiId if guiList1 has just been selected
   if (!$guiDesc) {
	  $Desc = "guiDesc_" . $guiList1;
	  $guiDesc = $$Desc;
   }
   if (!$guiId) {
	  $Id = "guiId_" . $guiList1;
	  $guiId = $$Id;
   }

   echo 	"&nbsp;&nbsp;(" . $guiDesc;
   echo		" <input type='button' class='' name='' value='edit' onclick='editDesc()'> ) \n";
   echo "</div>\n";
   echo "<div class='buttonbar'>\n";
   echo "<input type='button' class='' name='' value='save' onclick='thisSave()'> \n";
   echo "<input type='button' class='' name='' value='delete' onclick='thisDelete()'> \n";
   echo "<input type='button' class='' name='' value='show' onclick='thisShow()'> \n";
   echo "<input type='button' class='' name='' value='sql' onclick='thisExport()'> \n";
   echo "</div>\n";
   echo "<input type='hidden'  name='guiList1' value='".$guiList1."' >\n";
   echo "<input type='hidden'  name='guiId' value='".$guiId."' >\n";
   echo "<input type='hidden'  name='guiDesc' value='".$guiDesc."' >\n";
}
#Depot
if(isset($guiList1)){
	echo "<select name='guiList2' class='guiList2' onchange='clearRadio();submit()'>\n";
	echo "<option>GUI...</option>\n";
	for ($i=0; $i<count($gui_id_perm);$i++){
		echo "<option value='".$gui_id_perm[$i]."' ";
		if($guiList2 && $guiList2 == $gui_id_perm[$i]){
			echo "selected";
		}
		echo ">".$gui_name_perm[$i]."</option>\n";
	}
	echo "</select>\n";
	if($guiList1 != $guiList2){echo "<input class='all' type='button' value='add all elements' onclick='addAll()'>\n";}
}
#Elements
if(isset($guiList2)){
	if($guiList1 == $guiList2){
		echo "<div class='guiList2_header'>Edit Element: </div>\n";
	}
	else{
		echo "<div class='guiList2_header'>Templates</div>\n";
	}
	$sql = "SELECT * FROM gui_element WHERE fkey_gui_id = $1 ORDER BY e_id";
	$v = array($guiList2);
	$t = array("s");
	$res = db_prep_query($sql, $v, $t);
	$cnt = 0;

	echo "<div class='myElements'>\n<table>\n";

	while(db_fetch_row($res)){
		echo "<tr>\n";
		echo "<td class='myTable'><input type='radio' name='myElement' value='".db_result($res,$cnt,"e_id")."' onclick='submit()' ";
		if(db_result($res,$cnt,"e_id") == $myElement){echo "checked";}
		echo "></td>\n";
		echo "<td class='myTable'>";
		if(db_result($res,$cnt,"e_public") == 1){echo "<div class='on'>on</div>";}
		echo "</td>\n";
		echo "<td class='myTable'>";
 		echo "<a href=\"mod_EditElementVars.php?fkey_gui_id=".$guiList2."&fkey_e_id=".db_result($res,$cnt,"e_id")."\">";
 		echo db_result($res,$cnt,"e_id");
		echo "</a>\n</td>\n";
		echo "<td class='myTable'>".db_result($res,$cnt,"e_comment")."</td>";
		echo "</tr>\n";
		$cnt++;
	}
	echo "</table>\n</div>\n";
}
#Formular:
echo "<table class='myForm'>\n";
if(isset($myElement)){
   $sql = "SELECT * FROM gui_element WHERE fkey_gui_id = $1 AND e_id = $2";
   $v = array($guiList2, $myElement);
   $t = array("s", "s");
   $res = db_prep_query($sql, $v, $t);
   if(db_fetch_row($res)){
      echo "<tr><td>ID: </td><td><input type='text' class='textfield' name='e_id' value='".db_result($res,0,"e_id")."'></td></tr>\n";
      echo "<tr><td>Position: </td><td><input type='text' class='textfield' name='e_pos' value='".db_result($res,0,"e_pos")."'></td></tr>\n";
      echo "<tr><td>ON/OFF: </td><td><input type='text' class='textfield' name='e_public' value='".db_result($res,0,"e_public")."'></td></tr>\n";
      echo "<tr><td>Comment: </td><td><textarea cols='32' rows='5'  name='e_comment' >".stripslashes(db_result($res,0,"e_comment"))."</textarea></td></tr>\n";
      echo "<tr><td>HTML-TAG: </td><td><input type='text' class='textfield' name='e_element' value='".db_result($res,0,"e_element")."'></td></tr>\n";
      echo "<tr><td>SRC: </td><td><input type='text' class='textfield' name='e_src' value='".db_result($res,0,"e_src")."'></td></tr>\n";
      echo "<tr><td>Attributes: </td><td><textarea cols='32' rows='5'  name='e_attributes' >".stripslashes(db_result($res,0,"e_attributes"))."</textarea></td></tr>\n";
      echo "<tr><td>Left: </td><td><input type='text' class='textfield' name='e_left' value='".db_result($res,0,"e_left")."'></td></tr>\n";
      echo "<tr><td>Top: </td><td><input type='text' class='textfield' name='e_top' value='".db_result($res,0,"e_top")."'></td></tr>\n";
      echo "<tr><td>Width: </td><td><input type='text' class='textfield' name='e_width' value='".db_result($res,0,"e_width")."'></td></tr>\n";
      echo "<tr><td>Height: </td><td><input type='text' class='textfield' name='e_height' value='".db_result($res,0,"e_height")."'></td></tr>\n";
      echo "<tr><td>Z-INDEX: </td><td><input type='text' class='textfield' name='e_z_index' value='".db_result($res,0,"e_z_index")."'></td></tr>\n";
      echo "<tr><td>Styles: </td><td><input type='text' class='textfield' name='e_more_styles' value='".db_result($res,0,"e_more_styles")."'></td></tr>\n";
      echo "<tr><td>Content: </td><td><textarea cols='32' rows='4'  name='e_content' >".stripslashes(db_result($res,0,"e_content"))."</textarea></td></tr>\n";
      echo "<tr><td>Close-TAG: </td><td><input type='text' class='textfield' name='e_closetag' value='".db_result($res,0,"e_closetag")."'></td></tr>\n";
      echo "<tr><td>JavaScript: </td><td><input type='text' class='textfield' name='e_js_file' value='".db_result($res,0,"e_js_file")."'></td></tr>\n";
      echo "<tr><td>Modul: </td><td><input type='text' class='textfield' name='e_mb_mod' value='".db_result($res,0,"e_mb_mod")."'></td></tr>\n";
      echo "<tr><td>Target: </td><td><input type='text' class='textfield' name='e_target' value='".db_result($res,0,"e_target")."'></td></tr>\n";
      echo "<tr><td>Requires: </td><td><input type='text' class='textfield' name='e_requires' value='".db_result($res,0,"e_requires")."'></td></tr>\n";
   }
   echo "</table>";
}
else if(isset($guiList1)){
      echo "<tr><td>ID: </td><td><input type='text' class='textfield' name='e_id' value='".$e_id."'></td></tr>\n";
      echo "<tr><td>Position: </td><td><input type='text' class='textfield' name='e_pos' value='".$e_pos."'></td></tr>\n";
      echo "<tr><td>Public: </td><td><input type='text' class='textfield' name='e_public' value='".$e_public."'></td></tr>\n";
      echo "<tr><td>Comment: </td><td><textarea cols='32' rows='5'  name='e_comment' >".stripslashes($e_comment)."</textarea></td></tr>\n";
      echo "<tr><td>HTML-TAG: </td><td><input type='text' class='textfield' name='e_element' value='".$e_element."'></td></tr>\n";
      echo "<tr><td>SRC: </td><td><input type='text' class='textfield' name='e_src' value='".$e_src."'></td></tr>\n";
      echo "<tr><td>Attributes: </td><td><textarea cols='32' rows='5'  name='e_attributes' >".stripslashes($e_attributes)."</textarea></td></tr>\n";
      echo "<tr><td>Left: </td><td><input type='text' class='textfield' name='e_left' value='".$e_left."'></td></tr>\n";
      echo "<tr><td>Top: </td><td><input type='text' class='textfield' name='e_top' value='".$e_top."'></td></tr>\n";
      echo "<tr><td>Width: </td><td><input type='text' class='textfield' name='e_width' value='".$e_width."'></td></tr>\n";
      echo "<tr><td>Height: </td><td><input type='text' class='textfield' name='e_height' value='".$e_height."'></td></tr>\n";
      echo "<tr><td>Z-INDEX: </td><td><input type='text' class='textfield' name='e_z_index' value='".$e_z_index."'></td></tr>\n";
      echo "<tr><td>Styles: </td><td><input type='text' class='textfield' name='e_more_styles' value='".$e_more_styles."'></td></tr>\n";
      echo "<tr><td>Content: </td><td><textarea cols='32' rows='4'  name='e_content' >".stripslashes($e_content)."</textarea></td></tr>\n";
      echo "<tr><td>Close-TAG: </td><td><input type='text' class='textfield' name='e_closetag' value='".$e_closetag."'></td></tr>\n";
      echo "<tr><td>JavaScript: </td><td><input type='text' class='textfield' name='e_js_file' value='".$e_js_file."'></td></tr>\n";
      echo "<tr><td>Modul: </td><td><input type='text' class='textfield' name='e_mb_mod' value='".$e_mb_mod."'></td></tr>\n";
      echo "<tr><td>Target: </td><td><input type='text' class='textfield' name='e_target' value='".$e_target."'></td></tr>\n";
      echo "<tr><td>Requires: </td><td><input type='text' class='textfield' name='e_requires' value='".$e_requires."'></td></tr>\n";
}
echo "</table>\n";
?>
<input type='hidden' name='myDelete'>
<input type='hidden' name='mySave'>
<input type='hidden' name='myShow'>
<input type='hidden' name='all'>
</form>
</body>
</html>