<?php
#$Id: mod_zoomCoords.php 3399 2009-01-02 15:27:22Z nimix $
# http://www.mapbender.org/Mapbender_without_iframes
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include(dirname(__FILE__)."/../include/dyn_js.php");
?>
try{
	if (zoomCoords_permanentHighlight){}
}
catch(e){
	zoomCoords_permanentHighlight = 'false';
}

var mod_zoomCoords_target = '<?php echo $e_target[0];?>';
mod_zoomCoords_target = mod_zoomCoords_target.split(',');

function zoomCoordinate(x,y){
   x=x.replace(",",".");
   y=y.replace(",",".");
   
   document.zoomCoordsForm.X.value=x;
   document.zoomCoordsForm.Y.value=y;
	  
   if (isNaN(x)==true || isNaN(y)==true){
       alert ("<?php echo _mb("Please type a number.");?>");
   }else{
   
	   if(zoomCoords_permanentHighlight =='true'){
		   setPermanentMarker(x,y);
	   }
  		hideHighlight()
      	zoom(mod_zoomCoords_target[0],true, 1.0,x,y);
   }
}

function highlight(x, y){
	if(x!='' && y!=''){   
	   x=x.replace(",",".");
	   y=y.replace(",",".");
	   
	   document.zoomCoordsForm.X.value=x;
	   document.zoomCoordsForm.Y.value=y;
	  
	   
	   if (isNaN(x)==true || isNaN(y)==true){
	     
	   }
	   else{
			for(var i=0;i<mod_zoomCoords_target.length;i++){
				mb_showHighlight(mod_zoomCoords_target[i],x,y);
			}
	   }
	}
}


function hideHighlight(){
	for(var i=0;i<mod_zoomCoords_target.length;i++){
		mb_hideHighlight(mod_zoomCoords_target[i]);
	}
}

function setPermanentMarker(x,y){
 	mod_permanentHighlight_x = parseFloat(x);
   	mod_permanentHighlight_y = parseFloat(y);
   	mod_permanentHighlight_text = x + ' / '+ y;
  
   	mod_permanentHighlight_init();
}

parent.eventInitMap.register(function zoomCoorsInit(){
	var el = document.getElementById("zoomCoords");
	if(el){
		el.innerHTML="<?php
echo "<form style='font-family : Arial, Helvetica, sans-serif;font-size: 11px;' name='zoomCoordsForm' action='" . $PHP_SELF . "?".SID."' method='post'>";
#coordinates
   
   # Deutsche Version

   # English Version
      echo "<span style='position: absolute;left: 5px;top:5px;color: Gray;'>"._mb("Longitude").":</span>";
      echo "<span style='position: absolute;left: 80px;top:5px;color: Gray;'>"._mb("Latitude").":</span>";
      echo "<input style='position: absolute;left:5px;top:20px;color: Gray;width:65px;border: solid thin;height:20px;' type='text' name='X'>";
      echo "<input style='position: absolute;left:80px;top:20px;color: Gray;width:65px;border: solid thin;height:20px;'class='texty' type='text' name='Y'>";
      echo "<input style='position: absolute;left:150px;top:20px;color: Gray;border: solid thin;height:20px;' type='button' value='"._mb("ok")."' onclick='zoomCoordinate(document.zoomCoordsForm.X.value, document.zoomCoordsForm.Y.value); highlight(document.zoomCoordsForm.X.value, document.zoomCoordsForm.Y.value)' onmouseover='highlight(document.zoomCoordsForm.X.value, document.zoomCoordsForm.Y.value)' onmouseout='hideHighlight(document.zoomCoordsForm.X.value, document.zoomCoordsForm.Y.value)' >";

echo "</form>";
?>";
	}
});

