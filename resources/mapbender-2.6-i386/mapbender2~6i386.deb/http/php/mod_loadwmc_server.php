<?php
require_once(dirname(__FILE__) . "/../php/mb_validateSession.php");
require_once(dirname(__FILE__) . "/../classes/class_user.php");
require_once(dirname(__FILE__) . "/../classes/class_wmc.php");
require_once(dirname(__FILE__) . "/../classes/class_json.php");
require_once(dirname(__FILE__) . "/../classes/class_administration.php");

/**
 * encodes and delivers the data
 * 
 * @param object the un-encoded object 
 */
function sendOutput($out){
	global $json;
	$output = $json->encode($out);
	if (CHARSET == "ISO-8859-1") {
		$output = utf8_decode($output);
	}
	header("Content-Type: text/x-json");
	echo $output;
}

/**
 * Get all available WMC documents from the database
 * 
 * @return mixed[] an array of wmcs 
 * 					(wmc = assoc. array of "id", "title", "timestamp")
 */
function getWmc(){
	global $con;
	global $userId;
	
	$wmcArray = array();
	
	// get WMC ids 
	$currentUser = new User($userId);
	$wmcIdArray = $currentUser->getWmcByOwner();
	
	// get WMC data
	$v = array();
	$t = array();
	$wmcIdList = "";

	for ($i = 0; $i < count($wmcIdArray); $i++) {
		if ($i > 0) { 
			$wmcIdList .= ",";
		}
		$wmcIdList .= "$".($i+1);
		array_push($v, $wmcIdArray[$i]);
		array_push($t, 's');
	}

	if ($wmcIdList !== "") {
		$sql = "SELECT DISTINCT wmc_id, wmc_title, wmc_timestamp FROM mb_user_wmc ";
		$sql .= "WHERE wmc_id IN (" . $wmcIdList . ") ";
		$sql .=	"ORDER BY wmc_timestamp DESC";
	
		$res = db_prep_query($sql, $v, $t);
		while($row = db_fetch_array($res)){
			$currentResult = array();
			$currentResult["id"] = $row["wmc_id"];
			$currentResult["title"] = administration::convertIncomingString($row["wmc_title"]);
			$currentResult["timestamp"] = date("M d Y H:i:s", $row["wmc_timestamp"]); 
			array_push($wmcArray, $currentResult);
		}
	}
	return $wmcArray;
}

$json = new Mapbender_JSON();
$queryObj = $json->decode(stripslashes($_REQUEST['queryObj']));
$resultObj = array();

$e = new mb_exception("command: " . $queryObj->command);

$wmc = new wmc();
$userId = $_SESSION[mb_user_id];

switch($queryObj->command){

	// gets available WMCs
	case 'getWmc':
		$resultObj["wmc"] = getWmc();
	break;

	// gets XML document of a WMC
	case 'getWmcDocument':
		$wmcId = $queryObj->parameters->id;
		$doc = $wmc->getDocument($wmcId);
		if (!$doc) {
			$resultObj["error"] = "The WMC document could not be found.";
		}
		else {
			$resultObj["wmc"] = array("document" => $doc);
		}
	break;

	// deletes a WMC
	case 'deleteWmc':
		$wmcId = $queryObj->parameters->id;
		if ($wmc->delete($wmcId)) {
			$resultObj["success"] = "WMC has been deleted from the database.";
		}
		else {
			$resultObj["error"] = "WMC could not be deleted.";
		}
	break;
	
	// loads a WMC (returns array of JS code)
	case 'loadWmc':
		$wmcId = $queryObj->parameters->id;
		$wmc->createFromDb($wmcId);
		$jsArray = $wmc->toJavaScript();
		if ($jsArray) {
			$resultObj["javascript"] = $jsArray;
		}
		else {
			$resultObj["error"] = "WMC could not be loaded.";
		}
	break;

	// merges data with WMC and loads it (returns array of JS code)
	case 'mergeWmc':
		$params = $queryObj->parameters;
		
		// generate a WMC for the current client state
		$currentWmc = new wmc();
		$currentWmc->createFromJs($params->mapObject, $params->generalTitle, $params->extensionData);

		// get the desired WMC from the database
		$wmcId = $queryObj->parameters->id;
		$wmcXml = wmc::getDocument($wmcId);

		// merge the two WMCs
		$currentWmc->merge($wmcXml);
		
		// load the merged WMC
		$jsArray = $currentWmc->toJavaScript();

		if (is_array($jsArray) && count($jsArray) > 0) {
			$resultObj["javascript"] = $jsArray;
		}
		else {
			$resultObj["error"] = "WMC could not be loaded.";
		}
	break;
	
	// appends a WMC (returns JS code)
	case 'appendWmc':
		$params = $queryObj->parameters;
		// generate a WMC for the current client state
		$currentWmc = new wmc();
		$currentWmc->createFromJs($params->mapObject, $params->generalTitle, $params->extensionData);

		// get the desired WMC from the database
		$wmcId = $queryObj->parameters->id;
		$wmcXml = wmc::getDocument($wmcId);

		// merge the two WMCs
		$currentWmc->append($wmcXml);
		
		// load the merged WMC
		$jsArray = $currentWmc->toJavaScript();

		if (is_array($jsArray) && count($jsArray) > 0) {
			$resultObj["javascript"] = $jsArray;
		}
		else {
			$resultObj["error"] = "WMC could not be appended.";
		}
	break;
	

	// Invalid command
	default:
		$resultObj["error"] = "no action specified...";
}

sendOutput($resultObj);
?>
