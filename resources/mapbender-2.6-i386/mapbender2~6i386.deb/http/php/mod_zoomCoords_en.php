<?php
# $Id: mod_zoomCoords_en.php 2436 2008-05-07 13:11:02Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Zoom to Coordinate</title>
<style type="text/css">
	    <!--

	    body{
	    	font-family : Arial, Helvetica, sans-serif;
	    	font-size: 11px;
	    }
	    .labelx{
	    	position: absolute;
	    	left: 5px;
	    	top:5px;
	    	color: Gray;
	    }
	    .labely{
	    	position: absolute;
	    	left: 90px;
	    	top:5px;
	    	color: Gray;
	    }
	    .textx{
	    	position: absolute;
	    	left:5px;
	    	top:20px;
	    	color: Gray;
	    	width:70px;
         border: solid thin;
         height:20px;
	    }
	    .texty{
	    	position: absolute;
	    	left:90px;
	    	top:20px;
         color: Gray;
	    	width:70px;
         border: solid thin;
         height:20px;
	    }
       .send{
  	    	position: absolute;
	    	left:177px;
	    	top:20px;
         color: Gray;
         border: solid thin;
         height:20px;
         width:30px;
       }
	    -->
</style>
<?php
echo '<script type="text/javascript">';

echo "var mod_zoomCoords_target = '".$e_target."';";
echo "var target = mod_zoomCoords_target.split(',');";


include(dirname(__FILE__)."/../include/dyn_js.php");

?>
try{
	if (zoomCoords_permanentHighlight){}
}
catch(e){
	zoomCoords_permanentHighlight = 'false';
}


function zoomCoordinate(){
   var coordx = document.form1.X.value; 
   var coordy = document.form1.Y.value;
   coordx = coordx.replace(",",".");
   coordy = coordy.replace(",",".");
   var valid = true;
    
 /*  if(parseFloat(coordx) < 5.88 ||  parseFloat(coordx) > 15){
      alert("Eingabe unzulässig!");
      document.form1.X.select();
      document.form1.X.focus();
      valid = false; 
      return false;
   }
   if(parseFloat(coordy) < 46.62 ||  parseFloat(coordy) > 55.71){
      alert("Eingabe unzulässig!");
      document.form1.Y.select();
      document.form1.Y.focus();
      valid = false;
      return false;
   }   */
   
   if(zoomCoords_permanentHighlight =='true'){
	   setPermanentMarker(coordx,coordy);
   }
   parent.mb_hideHighlight(target[0]);
   parent.mb_hideHighlight(target[1]);
   parent.zoom(target[0],true, 1.0,coordx,coordy);
  
}

function highlight(x, y){
	if(x!='' && y!=''){
       x=x.replace(",",".");
	   y=y.replace(",",".");
	   
	   document.form1.X.value=x;
	   document.form1.Y.value=y;
	   
	   if (isNaN(x)==true || isNaN(y)==true){
	     
	   }
	   else{
	      parent.mb_showHighlight(target[0],x,y);
	      parent.mb_showHighlight(target[1],x,y);
	   }
	}   
}

function hideHighlight(){
   parent.mb_hideHighlight(target[0]);
   parent.mb_hideHighlight(target[1]);
}

function setPermanentMarker(x,y){
   parent.mod_permanentHighlight_x = parseFloat(x);
   parent.mod_permanentHighlight_y = parseFloat(y);
   parent.mod_permanentHighlight_text = x + ' / '+ y;
   //alert('setPermanentMarker'+ parseFloat(x) + parseFloat(y));
   
   parent.mod_permanentHighlight_init();
}
// -->
</script>
</head>
<body bgcolor='#ffffff' onload=''>

<?php
echo "<form name='form1' action='" . $self ."' method='post'>";
#coordinates
   
   #deutsche Version
      echo "<span class='labelx'>X-Coordinate:</span>";
      echo "<span class='labely'>Y-Coordinate:</span>";
      echo "<input class='textx' type='text' name='X'>";
      echo "<input class='texty' type='text' name='Y'>";
      echo "<input class='send' type='button' value='ok' onclick='zoomCoordinate();' onmouseover='highlight(document.form1.X.value, document.form1.Y.value)' onmouseout='if(document.form1.X.value !=\"\" && document.form1.Y.value !=\"\"){hideHighlight(document.form1.X.value, document.form1.Y.value);}' >";

?>
</form>
</body>
</html>
