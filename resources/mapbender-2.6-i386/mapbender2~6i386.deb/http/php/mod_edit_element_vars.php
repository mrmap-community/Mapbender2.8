<?php
# $Id: mod_edit_element_vars.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_edit_element_vars.php
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
include(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta name="author-mail" content="info@ccgis.de">
<meta name="author" content="U. Rothstein">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Edit Element Vars</title>
<?php
include '../include/dyn_css.php';
?>
<style type="text/css">
   <!--
   body{
      background-color: #ffffff;
  		font-family: Arial, Helvetica, sans-serif;
  		font-size : 12px;
  		color: #808080
  	}
   .guiList1{
   	position:absolute;
   	top:30px;
   	left:10px;
   	width:200px
   }
   .buttonbar{
   	position:absolute;
   	top:40px;
   	left:10px;
   }
   .guiList1_text{
   	position:absolute;
   	top:10px;
   	left:10px;
      font-size:16px;
      color: #0066cc;
   }
   .guiList2{
   	position:absolute;
   	top:40px;
   	left:400px;
   	width:200px
   }
   .all{
   	position:absolute;
   	top:38px;
   	left:610px;
   }
   .guiList2_header{
   	position:absolute;
   	top:10px;
   	left:400px;
      font-size:16px;
      color: #0066cc;
   }
   .myElements{
   	position:absolute;
   	top:70px;
   	left:400px;
   }
   .myTable{
   	border: 1px solid;
      font-size: 11px;
   }
   .myForm{
   	position:absolute;
   	top:70px;
   	left:10px;
   }
   .textfield{
      width:277px
   }
   .on{
      color: #0066cc;
   }
   -->
</style>
<?php
# handle database updates etc.....
if(isset($mySave) && $mySave == '1'){
	if ($SYS_DBTYPE=='pgsql') { 
		$sql[0] = "SET AUTOCOMMIT=1;";
	}
	else {
		$sql[0] = "SET AUTOCOMMIT=0;shit happens";
	}
	$v[0] = array();
	$t[0] = array();
	$sql[1] = "BEGIN;";
	$v[1] = array();
	$t[1] = array();
	$sql[2] = "DELETE FROM gui_element_vars WHERE fkey_e_id = $1 AND fkey_gui_id = $2";
	$v[2] = array($e_id, $guiList1);
	$t[2] = array("s", "s");


   if($e_left < 1){$e_left = "NULL";}
   if($e_top < 1){$e_top = "NULL";}
   if($e_width < 1){$e_width = "NULL";}
   if($e_height < 1){$e_height = "NULL";}
   if($e_z_index < 1){$e_z_index = "NULL";}
	$sql[3] = "INSERT INTO gui_element_vars ";
	$sql[3] .= "(fkey_gui_id, e_id, e_pos, e_public, e_comment, e_element, e_src, ";
	$sql[3] .= "e_attributes, e_left, e_top, e_width, e_height, e_z_index, ";
	$sql[3] .= "e_more_styles, e_content, e_closetag, e_js_file, e_mb_mod, e_target, ";
	$sql[3] .= "e_requires) ";
	$sql[3] .= "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)";
	$v[3] = array($guiList1, $e_id, $e_pos, $e_public, db_escape_string($e_comment), $e_element, $e_src, db_escape_string($e_attributes), $e_left, $e_top, $e_width, $e_height, $e_z_index, $e_more_styles, $e_content, $e_closetag, $e_js_file, $e_mb_mod, $e_target, $e_requires);
	$t[3] = array("s", "s", "i", "s", "s", "s", "s", "s", "i", "i", "i", "i", "i", "s", "s", "s", "s", "s", "s", "s");
   #echo $sql[3];
   for ($i = 0; $i < count($sql); $i++) {
      $res = db_prep_query($sql[$i], $v[$i], $t[$i]);
   }
   if($res){
      $res = db_query( "COMMIT");
      $res = db_query( "SET AUTOCOMMIT=1");
   }
   else{
      $res = db_query( "ROLLBACK");
      $res = db_query( "SET AUTOCOMMIT=1");
   }
}
if(isset($myDelete) && $myDelete == '1'){
   $sql = "DELETE FROM gui_element_vars WHERE fkey_e_id = $1 AND fkey_gui_id = $2 AND var_name= $3";
   $v = array($e_id, $guiList1, $var_name);
   $t = array("s", "s", "s");
   $res = db_prep_query($sql, $v, $t);
   $e_id = ""; $e_pos = ""; $e_public = ""; $e_comment = ""; $e_element = "";
   $e_src = ""; $e_attributes = ""; $e_left = ""; $e_top = ""; $e_width = ""; $e_height = ""; $e_z_index = "";
   $e_more_styles = ""; $e_content = ""; $e_closetag = ""; $e_js_file = ""; $e_mb_mod = ""; $e_target = ""; $e_requires = "";
}
if(isset($myShow) && $myShow == '1'){
   $_SESSION["mb_user_myGui"] = $guiList1;
   echo "<script language='javascript'>";
   echo "window.open('../frames/login.php?".strip_tags (SID)."&mb_user_myGui=".$guiList1."','','');";
   echo "</script>";
}
if(isset($all) && $all == '1'){
   $sql = "SELECT * FROM gui_element_vars WHERE fkey_gui_id = $1 AND fkey_e_id = $2 and var_name= $3;";
   $v = array($guiList2, $e_id, $var_name);
   $t = array("s", "s", "s");
   $res = db_prep_query($sql, $v, $t);
   $cnt = 0;
   while(db_fetch_row($res)){
      $sql_del = "DELETE FROM gui_element_vars WHERE fkey_gui_id = $1 AND fkey_e_id = $2 and var_name= $3";
      $v = array($guiList1, db_result($res,$cnt,"fkey_e_id"), $var_name);
      $t = array("s", "s", "s");
      $res_del = db_prep_query($sql_del, $v, $t);
      if(db_result($res,$cnt,"e_left") == ""){$myleft = 'NULL';} else{$myleft = db_result($res,$cnt,"e_left");}
      if(db_result($res,$cnt,"e_top") == ""){$mytop = 'NULL';} else{$mytop = db_result($res,$cnt,"e_top");}
      if(db_result($res,$cnt,"e_width") == ""){$mywidth = 'NULL';} else{$mywidth = db_result($res,$cnt,"e_width");}
      if(db_result($res,$cnt,"e_height") == ""){$myheight = 'NULL';} else{$myheight = db_result($res,$cnt,"e_height");}
      if(db_result($res,$cnt,"e_z_index") == ""){$my_z_index = 'NULL';} else{$my_z_index = db_result($res,$cnt,"e_z_index");}

      $sql_ins = "INSERT INTO gui_element_vars ";
      $sql_ins .= "(fkey_gui_id, e_id, e_pos,e_public, e_comment, e_element, ";
      $sql_ins .= "e_src, e_attributes, e_left, e_top, e_width, e_height, ";
      $sql_ins .= "e_z_index, e_more_styles, e_content, e_closetag, e_js_file, ";
      $sql_ins .= "e_mb_mod, e_target, e_requires) ";
      $sql_ins .= "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, ";
      $sql_ins .= "$10, $11, $12, $13, $14, $15, $16, $17, $18, ";
      $sql_ins .= "$19, $20)";
      $v = array($guiList1, db_result($res,$cnt,"e_id"), db_result($res,$cnt,"e_pos"), db_result($res,$cnt,"e_public"), db_escape_string(db_result($res,$cnt,"e_comment")), db_result($res,$cnt,"e_element"), db_result($res,$cnt,"e_src"), db_escape_string(db_result($res,$cnt,"e_attributes")), $myleft, $mytop, $mywidth, $myheight, $my_z_index, db_result($res,$cnt,"e_more_styles"), db_escape_string(db_result($res,$cnt,"e_content")), db_result($res,$cnt,"e_closetag"), db_result($res,$cnt,"e_js_file"), db_result($res,$cnt,"e_mb_mod"), db_result($res,$cnt,"e_target"), db_result($res,$cnt,"e_requires"));
      $t = array("s", "s", "s", "s", "s", "s", "s", "s", "i", "i", "i", "i", "i", "s", "s", "s", "s", "s", "s", "s");

      $res_ins = db_prep_query($sql_ins, $v, $t);
      if (!$res_ins) {
      	echo db_error($connect); 
      }
      $cnt++;
   }
}
# end
echo "<script language='javascript'>";
echo "var varIDs = new Array();";
if(isset($guiList1)){
   $sql = "SELECT var_name FROM gui_element_vars WHERE fkey_gui_id = $1 AND fkey_e_id = $2";
   $v = array($guiList1, $e_id);
   $t = array("s", "s");
   $res = db_prep_query($sql, $v, $t);
   $cnt = 0;
   while(db_fetch_row($res)){
      echo  "varIDs[".$cnt."] = '".db_result($res,$cnt,"var_name")."'; ";
      $cnt++;
   }
}
echo "</script>";
?>
<script type="text/javascript">
<!--
function setGui(val){
   document.form1.guiList1.value = val;
   document.form1.submit();
}
function clearRadio(){
   for(var i=0; i< document.form1.elements.length; i++){
      if(document.form1.elements[i].type == "radio"){
         document.form1.elements[i].checked = false;
      }
   }
}
function thisSave(){
   if(document.form1.e_id.value == ""){
      alert("ID ? ");
      document.form1.e_id.focus();
      return;
   }
   var permission = false;
   var isElement = false;
   for(var i=0; i<varIDs.length; i++){
      clearRadio();
      if(document.form1.var_name.value == varIDs[i]){
         permission = confirm("update: " + document.form1.var_name.value + " ?");
         isElement = true;
         break;
      }
   }
   if(permission == true || isElement == false){
      document.form1.mySave.value = 1;
      document.form1.submit();
   }
}
function thisDelete(){
   clearRadio();
   var permission =  confirm("delete: " + document.form1.e_id.value + " ?");
   if(permission == true){
      document.form1.myDelete.value = 1;
      document.form1.submit();
   }
}
function thisShow(){
   document.form1.myShow.value = 1;
   document.form1.submit();
}
function addAll(){
   var permission =  confirm("add all elements ?");
   if(permission == true){
      clearRadio();
      document.form1.all.value = 1;
      document.form1.submit();
   }
}
function thisExport(){

   window.open("mod_exportElement.php?element=" + document.forms[0].e_id.value+ "&gui=" +document.forms[0].guiList1.value ,"","");
}
// -->
</script>
</head>
<body>

<?php
echo "<form name='form1' action='" . $self ."' method='get'>";

#Gui to edit
if(!isset($guiList1)){
  echo "<div class= 'guiList1_text'>GUI:</div>";
  echo "<select class='guiList1' size='20' name='guiList1' onchange='setGui(this.value)'>";
  for ($i=0; $i<$count;$i++){
     echo "<option value='".$gui_id[$i]."' ";
     if($guiList1 && $guiList1 == $gui_id[$i]){
        echo "selected";
     }
     echo ">".$gui_name[$i]."</option>";
  }
  echo "</select>";
 // echo "<input type='hidden'  name='guiList2' value='' >";
}
else{
   echo "<div class= 'guiList1_text'>Edit Elements: ".$guiList1."</div>";
   echo "<div class='buttonbar'>";
   echo "<input type='button' class='' name='' value='save' onclick='thisSave()'> ";
   echo "<input type='button' class='' name='' value='delete' onclick='thisDelete()'> ";
   echo "<input type='button' class='' name='' value='show' onclick='thisShow()'> ";
   echo "<input type='button' class='' name='' value='sql' onclick='thisExport()'> ";
   echo "</div>";
   echo "<input type='hidden'  name='guiList1' value='".$guiList1."' >";
   echo "<input type='hidden'  name='e_id' value='".$e_id."' >";
}
#Elements
if(isset($guiList1)){
   echo "<div class='guiList2_header'>Templates</div>";

   $sql = "SELECT * FROM gui_element_vars WHERE fkey_gui_id = $1 AND fkey_e_id = $2";
   $v = array($guiList1, $e_id);
   $t = array("s", "s");
   $res = db_prep_query($sql, $v, $t);
   $cnt = 0;
   echo "<div class='myElements'><table>";
   while($row = db_fetch_array($res)){
      echo "<tr>";
      echo "<td class='myTable'><input type='radio' name='var_name' value='".$row["var_name"]."' onclick='submit()' ";
      if($row["var_name"] == $var_name){echo "checked";}
      echo "></td><td class='myTable'>";
      //if(db_result($res,$cnt,"e_public") == 1){echo "<div class='on'>on</div>";}
      echo "</td><td class='myTable'>". $row["var_name"]. "</td><td class='myTable'>" .$row["context"]."</td>";
      echo "</tr>";
      $cnt++;
   }
   echo "</table></div>";
}
#Formular:
echo "<table class='myForm'>";
if(isset($guiList1) && isset($var_name)){
   $sql = "SELECT * FROM gui_element_vars WHERE fkey_gui_id = $1 AND fkey_e_id = '".$e_id."' AND var_name = $2";
   $v = array($guiList1, $var_name);
   $t = array("s", "s");
   //echo $sql;
   $res = db_prep_query($sql, $v, $t);
   if($row = db_fetch_array($res)){
      echo "<tr><td>ID: </td><td><input type='text' class='textfield' readonly name='e_id' value='".$e_id."'></td></tr>";
      echo "<tr><td>Var Type: </td><td><input type='text' class='textfield' name='type' value='".$row["type"]."'></td></tr>";
      echo "<tr><td>Var Name: </td><td><input type='text' class='textfield' name='var_name_edit' value='".$row["var_name"]."'></td></tr>";
      echo "<tr><td>Content: </td><td><textarea cols='32' rows='4'  name='e_content' >".stripslashes($row["var_value"])."</textarea></td></tr>";

   }
   echo "</table>";
}

?>
<input type='hidden' name='myDelete'>
<input type='hidden' name='mySave'>
<input type='hidden' name='myShow'>
<input type='hidden' name='all'>

</form>
</body>
</html>