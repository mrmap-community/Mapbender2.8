<?php
# $Id: mod_owsproxy_conf.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_owsproxy_conf.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
require_once(dirname(__FILE__)."/../classes/class_administration.php");
$admin = new administration();
$ownwms = $admin->getWmsByOwner($_SESSION["mb_user_id"]);
if(isset($_REQUEST["wms_id"]) && isset($_REQUEST["status"])){
	$admin->setWMSOWSstring(intval($_REQUEST["wms_id"]),$_REQUEST["status"]);	
}
?>
<html>
<head>
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>OWS Security Proxy</title>
<style type="text/css">

body{
	font-family: Arial, Helvetica, sans-serif;	
}
</style>
<script language="JavaScript" type="text/javascript">
function set(wms_id, status){
	document.location.href = "<?php echo $self; ?>&wms_id="+wms_id+"&status="+status; 
}
</script>
  
</head>
<body>
<form>
<table>
<?php
for($i=0; $i<count($ownwms); $i++){
	echo "<tr>";
	echo "<td>";
	echo "<input type='checkbox' onclick='if(this.checked){set(\"".$ownwms[$i]."\",\"on\")}else{set(\"".$ownwms[$i]."\",\"off\")}' ";
	if($admin->getWMSOWSstring($ownwms[$i]) != false){ echo "checked";  }
	echo ">";
	echo "</td>";
	echo "<td>".$ownwms[$i]."</td>";
	echo "<td>".$admin->getWmsTitleByWmsId($ownwms[$i])."</td>";
	echo "</tr>";	
}
?>
</table>
</form>
</body>
</html>