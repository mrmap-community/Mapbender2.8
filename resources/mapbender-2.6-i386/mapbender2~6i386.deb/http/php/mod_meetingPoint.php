<?PHP
# $Id$
# http://www.mapbender.org/index.php/MeetingPoint
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__) . "/../php/mb_validateSession.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>meetingPoint</title>
<?php
include '../include/dyn_css.php';
?>
<script language='JavaScript'>
<!--
<?php
include('../include/dyn_js.php');
echo "var mod_meetingPoint_target = '" . $_REQUEST["e_target"] . "';";
echo "var meetingPoint_write_to = 'meetingPoint';";
?>
try{
	if (meetingPoint_export_subject){}
}
catch(e){
	meetingPoint_export_subject = 'Your meeting point. Follow the link!';
}

try{
	if (meetingPoint_export_format){}
}
catch(e){
	meetingPoint_export_format = 'prompt';
}

try{
	if (meetingPoint_max_characters){}
}
catch(e){
	meetingPoint_max_characters = 100;
}

try{
	if (meetingPoint_image){}
}
catch(e){
	meetingPoint_image = "../img/button_digitize/point_off.png";
}

try{
	if (meetingPoint_icon){}
}
catch(e){
	meetingPoint_icon = '../img/redball.gif';
}

try{
	if (meetingPoint_width){}
}
catch(e){
	meetingPoint_width = 14;
}

try{
	if (meetingPoint_height){}
}
catch(e){
	meetingPoint_height = 14;
}

try{
	if (meetingPoint_style){}
}
catch(e){
	meetingPoint_style = 'background-color:white;font-weight: bold;color:black;font-family:Arial;';
}

try{
	if (meetingPoint_please_click){}
}
catch(e){
	meetingPoint_please_click = 'Please click for the meeting point position!';
}

var mod_meetingPointRealPoint = null;
//parent.mb_registerSubFunctions("window.frames['meetingPoint'].mod_meetingPoint_draw()");

parent.eventAfterMapRequest.register(function () {
	mod_meetingPoint_draw();
});

var ie = document.all?1:0;
var mod_meetingPoint_win = null;
var mod_meetingPoint_elName = "meetingPoint";
var mod_meetingPoint_frameName = "meetingPoint";
var mod_meetingPoint_button = "my_getCoords";
var mod_meetingPoint_img_on = new Image(); mod_meetingPoint_img_on.src = meetingPoint_image.replace(/_off/,"_on") ;
var mod_meetingPoint_img_off = new Image(); mod_meetingPoint_img_off.src = meetingPoint_image;
var mod_meetingPoint_img_over = new Image(); mod_meetingPoint_img_over.src = meetingPoint_image.replace(/_off/,"_over") ;
var mod_meetingPoint_fix = "";


function init_mod_meetingPoint(ind){
	parent.mb_button[ind] = window.document.getElementById(mod_meetingPoint_button);
	parent.mb_button[ind].img_over = mod_meetingPoint_img_over.src;
	parent.mb_button[ind].img_on = mod_meetingPoint_img_on.src;
	parent.mb_button[ind].img_off = mod_meetingPoint_img_off.src;
	parent.mb_button[ind].status = 0;
	parent.mb_button[ind].elName = mod_meetingPoint_button;
	parent.mb_button[ind].go = new Function ("mod_meetingPoint_run()");
	parent.mb_button[ind].stop = new Function ("mod_meetingPoint_disable()");
}

function mod_meetingPoint_run(){   
	var mapObject = parent.getMapObjByName(mod_meetingPoint_target);
	if (mapObject) {
		mapObject.getDomElement().ownerDocument.onclick = function (e) {
			var clickPos = mapObject.getMousePosition(e);
			mod_meetingPointRealPoint = mapObject.convertPixelToReal(clickPos);
			mod_meetingPoint_write(mod_meetingPointRealPoint.x, mod_meetingPointRealPoint.y);
			mod_meetingPoint_draw();	
			parent.mb_disableThisButton(mod_meetingPoint_button);
		};
	}
}

function mod_meetingPoint_disable(){
	var mapObject = parent.getMapObjByName(mod_meetingPoint_target);
	if (mapObject) {
		mapObject.getDomElement().ownerDocument.onclick = null;
	}
}
/*
function mod_meetingPoint_click(e){
	

	if(ie){
		clickX = parent.frames[mod_meetingPoint_target].event.clientX;
		clickY = parent.frames[mod_meetingPoint_target].event.clientY;
	}
	else{
		clickX = e.pageX;
		clickY = e.pageY;
	}
	
	var pos = parent.makeClickPos2RealWorldPos(mod_meetingPoint_target, clickX, clickY);
    
	mod_meetingPoint_write(pos[0],pos[1]);
	mod_meetingPoint_draw();	
}
*/
function mod_meetingPoint_write(x,y){	
   document.forms[0].x.value =x;
   document.forms[0].y.value =y;	   
}

function mod_meetingPoint_hide(){
	//var ind = parent.getMapObjIndexByName(mod_meetingPoint_target);
	//parent.frames[mod_meetingPoint_target].document.getElementById('permanent').style.visibility = 'hidden';
	var mapObject = parent.getMapObjByName(mod_meetingPoint_target);
	parent.$("#" + mapObject.elementName + "_permanent").css({
		visibility:"hidden"
	});
}


function mod_meetingPoint_draw(){
	var mapObject = parent.getMapObjByName(mod_meetingPoint_target);
	if (mapObject) {
		if (mod_meetingPointRealPoint !== null) {
			//alert(document.forms[0].x.value +" -- "+ document.forms[0].y.value + " - " );
	
			var meetingPointClickPos = mapObject.convertRealToPixel(mod_meetingPointRealPoint);
			var tagSource = "";
			tagSource += "<div style='z-index:13;position:absolute;left:"+(meetingPointClickPos.x- Math.round(0.5*meetingPoint_width))+"px;top:"+(meetingPointClickPos.y-Math.round(0.5*meetingPoint_height))+"px'>";
			tagSource += "<img src='"+meetingPoint_icon+"'>";
			tagSource += "<span style='"+meetingPoint_style+"'>"+document.forms[0].mytext.value+"<span>";
			tagSource += "</div>";

			var map_el = mapObject.getDomElement();
			if (!map_el.ownerDocument.getElementById(mapObject.elementName + "_permanent")) {
				//create Box Elements

				var $div = parent.$("<div id='" + mapObject.elementName + "_permanent'><img src='../img/redball.gif'/></div>");
				$div.css({
					position: "absolute",
					top: "0px",
					left: "0px",
					zIndex: 13
				});
				map_el.appendChild($div.get(0));
			}
			parent.$("#" + mapObject.elementName + "_permanent").html(tagSource);
			
		}
	}
}

/*
function mod_meetingPoint_draw(){
	var ind = parent.getMapObjIndexByName(mod_meetingPoint_target);
	if (document.forms[0].x.value!='' && document.forms[0].y.value != ''){
		//alert(document.forms[0].x.value +" -- "+ document.forms[0].y.value + " - " + parent.mb_mapObj[ind].width +" iii: "+ ind);
		parent.frames[mod_meetingPoint_target].document.getElementById('permanent').style.width = parent.mb_mapObj[ind].width;
		parent.frames[mod_meetingPoint_target].document.getElementById('permanent').style.height = parent.mb_mapObj[ind].height;
		parent.frames[mod_meetingPoint_target].document.getElementById('permanent').style.top = 0;
		parent.frames[mod_meetingPoint_target].document.getElementById('permanent').style.left = 0;
		parent.frames[mod_meetingPoint_target].document.getElementById('permanent').style.visibility = 'visible';
		var tagSource = "";
		var pos = parent.makeRealWorld2mapPos(mod_meetingPoint_target,document.forms[0].x.value, document.forms[0].y.value);
		tagSource += "<div style='z-index:13;position:absolute;left:"+(pos[0]- Math.round(0.5*meetingPoint_width))+"px;top:"+(pos[1]-Math.round(0.5*meetingPoint_height))+"px'>";
		tagSource += "<img src='"+meetingPoint_icon+"'>";
		tagSource += "<span style='"+meetingPoint_style+"'>"+document.forms[0].mytext.value+"<span>";
		tagSource += "</div>";
		//prompt("meetingPoint",tagSource);
	    parent.writeTag(mod_meetingPoint_target, "permanent", tagSource);
	}	 
}

*/
-->
</script>

<script language='JavaScript'>
<!--
<?php
echo "var used_charset = '".CHARSET ."';";
?>

function validate(){
	var mycheck = true;
	var checkObj= document.forms[0].mytext.value;
	if(checkObj == '') {
    	alert ("Bitte geben Sie einen Text an!");
    	checkObj.focus();
        mycheck=false;
    }
    
    var checkObj= document.forms[0].x.value;
    if(checkObj == '') {
    	alert (meetingPoint_please_click);
        mycheck = false;
    }

    if(mycheck == true){
    	my_meetingPoint = document.forms[0].myurl.value + "?";
    	my_meetingPoint += "name=" + encodeURIComponent(document.forms[0].myuser.value);
    	my_meetingPoint += "&password=" + encodeURIComponent(document.forms[0].mypw.value);
    	my_meetingPoint += "&mb_user_myGui=" + encodeURIComponent(document.forms[0].mygui.value);
    	
    	var ind = parent.getMapObjIndexByName('mapframe1');
    	var coord = parent.mb_mapObj[ind].extent.split(",");
    	
    	my_meetingPoint += "&mb_myBBOX=" + parseFloat(coord[0]) + ",";
		my_meetingPoint +=  parseFloat(coord[1]) + ",";
		my_meetingPoint +=  parseFloat(coord[2]) + ",";
		my_meetingPoint +=  parseFloat(coord[3]) ;

    	my_meetingPoint += "&mb_myPOI=";
    	
    	var splitext  = document.forms[0].mytext.value;
    	document.forms[0].mytext.value = splitext.substring(0, meetingPoint_max_characters);
    	

    	my_meetingPoint += encodeURIComponent(document.forms[0].mytext.value);

    	
    	my_meetingPoint += "|" + document.forms[0].x.value + "|";
    	my_meetingPoint += document.forms[0].y.value;

    	if(meetingPoint_export_format == 'email'){
    		createEmail(my_meetingPoint,meetingPoint_export_subject);
		}else{			
			prompt(meetingPoint_export_subject,my_meetingPoint);			
		}
    }
}

function emptyfields(){
	document.forms[0].mytext.value ='';
	document.forms[0].x.value ='';
	document.forms[0].y.value =  '';
	 mod_meetingPoint_hide();
}

function createEmail (url,subject) {
  var email = "mailto:"
  email  += "";
  email  += "?subject=";
  email  += subject;
  email  += "&body=";
  email  += escape(url);

  var win = window.open(email, 'email', 'top=120,left=120');
  win.close();
}

function goBack(where){
    document.location.href=where;
}

function init(){
	parent.mb_regButton_frame("init_mod_meetingPoint","meetingPoint",null);
}

-->
</script>

</head>
<body>

<form action="" >

<img  id='my_getCoords' name='my_getCoords' onclick="mod_meetingPoint_run()" onmouseover ="parent.mb_regButton_frame('init_mod_meetingPoint','meetingPoint',null)"  title="Treffpunkt setzen"  src = '../img/button_digitize/point_off.png'>
<br>
<input class='strinput' type="hidden" name='myurl' value='<?php  echo LOGIN;  ?>'>

<input class='strinput' type="hidden" name='mygui' value='<?php  echo $_SESSION["mb_user_gui"];  ?>'>

<input class='strinput' type="hidden" name='myuser' value='<?php  echo $_SESSION["mb_user_name"];  ?>'>

<input class='strinput' type="hidden" name='mypw' value='<?php  echo $_SESSION["mb_user_password"];  ?>'>
<br>
<!--<input class='strinput' type="textarea" size=2 name='mytext' value='' "maxlength=70" title="max. 70 Zeichen">-->
<textarea class='strinput' rows="3" name='mytext' title='maximal 70 Zeichen'></textarea>
<br>
<input class="okbutton" name="Send"   type="button" value="ok" onclick="validate();">
<input class="ibutton" type="button" value="cancel" onClick="emptyfields();">
<br>
<input class="coord" type="hidden" name='x' value='' readonly>
<input class="coord" type="hidden" name='y' value='' readonly>
<br>
</form>
</body>
</html>