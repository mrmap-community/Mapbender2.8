<?php
# $Id: mod_editGroup.php
# http://www.mapbender.org/index.php/mod_editGroup.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<head>
<title>Edit Group</title>
<?php
include '../include/dyn_css.php';
?>
<script language="JavaScript">

function validate(val){
   var ok = validateInput();
   if(ok == 'true'){
     var permission = false;
     if(val == 'save'){
        permission = confirm("Save changes?");
     }
     if(val == 'update'){
        permission = confirm("Save changes?");
     }
     if(val == 'delete'){
        permission = confirm("Delete Group?");
     }
     if(permission == true){
        document.forms[0].action.value = val;
        document.forms[0].submit();
     }
   }
}
function validateInput(){
  var str_alert = "Input incorrect !";
  if(document.forms[0].name.value == ''){
      alert(str_alert);
      document.forms[0].name.focus();
      return 'false';
  }
  return 'true';
}
</script>

</head>
<body>
<?php
#delete
if($action == 'delete'){
   $sql = "DELETE FROM mb_group WHERE mb_group_id = $1";
   $v = array( $selected_group);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   $selected_group = 'new';
}

#save
if($action == 'save'){
   $sql = "SELECT mb_group_id FROM mb_group WHERE mb_group_name = $1 ";
   $v = array($name);
   $t = array('s');
   $res = db_prep_query($sql,$v,$t);
   if(db_fetch_row($res)){
      echo "<script language='JavaScript'>alert('groupname must be unique!');</script>";
   }
   else{
     $sql = "Insert INTO mb_group (mb_group_name, mb_group_owner, mb_group_description) VALUES ";
     $sql.= "($1, $2,$3);";
     $v = array($name,$owner_id,$description);
     $t = array('s','i','s');
     $res = db_prep_query($sql,$v,$t);
     $selected_group = db_insert_id($res,"mb_group","mb_group_id");
   }
}

#update
if($action == 'update'){
   $sql = "SELECT mb_group_id FROM mb_group WHERE mb_group_name = $1 AND mb_group_id <> $2";
   $v = array($name,$selected_group);
   $t = array('s','i');
   $res = db_prep_query($sql,$v,$t);
   if(db_fetch_row($res)){
      echo "<script language='JavaScript'>alert('Groupname must be unique!');</script>";
   }
   else{
     $sql = "UPDATE mb_group SET mb_group_name = $1";
     $sql.=", mb_group_description = $2";
     $sql.=" where mb_group_id = $3";
     $v = array($name,$description,$selected_group);
     $t = array('s','s','i');
     $res = db_prep_query($sql,$v,$t);
   }
}
if (!isset($name) || $selected_group == 'new'){
  $name = "";
  $owner_id = $_SESSION["mb_user_id"];
  $owner_name = $_SESSION["mb_user_name"];
  $description = "";
}

/*HTML*****************************************************************************************************/

echo "<form name='form1' action='" . $self ."' method='post'>";
echo "<table border='0'>";
#User
echo "<tr>";
   echo "<td>";
      echo "Group: ";
   echo "</td>";
echo "<td>";
   echo "<select name='selected_group' onchange='submit()'>";
   echo "<option value='new'>NEW...</option>";
   $sql = "SELECT mb_group_name,mb_group_id FROM mb_group ";
   $v = array();
   $t = array();
   if (isset($myGroup)) { 
		$sql .= "WHERE mb_group_owner = $1";
		array_push($v, $_SESSION["mb_user_id"]);
		array_push($t, "i");
   }
   $sql .= " ORDER BY mb_group_name ";
   $res = db_prep_query($sql, $v, $t);
   $count=0;
   while($row = db_fetch_array($res)){
	 	echo "<option value='".$row["mb_group_id"]."' ";
		if($selected_group && $selected_group == $row["mb_group_id"]){
         echo "selected";
      }
      echo ">".$row["mb_group_name"]."</option>";
		$count++;
   }
   echo "</select>";
   echo "</td>";
echo "</tr>";


if(isset($selected_group) && $selected_group != 0){
   $sql = "SELECT * FROM mb_group WHERE mb_group_id = $1 ORDER BY mb_group_name ";
   $v = array($selected_group);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   if($row = db_fetch_array($res)){
      $name = $row["mb_group_name"];
      $owner_id = $row["mb_group_owner"];
      $description = $row["mb_group_description"];
   }
   $sql = "SELECT mb_user_name FROM mb_user WHERE mb_user_id = $1";
   $v = array($owner_id);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   if($row = db_fetch_array($res)){
      $owner_name = $row["mb_user_name"];
   }
}
#name
echo "<tr>";
   echo "<td>Name:</td>";
   echo "<td>";
      echo "<input type='text' size='30' name='name' value='".$name."'>";
   echo "</td>";
echo "</tr>";

#owner
echo "<tr>";
   echo "<td>Owner: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='owner_name' value='".$owner_name."' readonly>";
      echo "<input type='hidden' size='30' name='owner_id' value='".$owner_id."' readonly>";
   echo "</td>";
echo "</tr>";

#description
echo "<tr>";
   echo "<td>Description: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='description' value='".$description."'>";
   echo "</td>";
echo "</tr>";

echo"</table>";
if($selected_group == 'new' || !isset($selected_group)){
   echo "<input type='button' value='save'  onclick='validate(\"save\")'>";
}
if($_SESSION["mb_user_id"] == $owner_id && $selected_group != 'new' && $selected_group != '' ){
   echo "<input type='button' value='save'  onclick='validate(\"update\")'>";
   echo "<input type='button' value='delete'  onclick='validate(\"delete\")'>";
}
?>
<input type='hidden' name='action' value=''>
</form>
</body>
</html>