<?php
#$Id: mod_insertWmcIntoDb.php 1198 2007-10-18 14:37:52Z baudson $
#$Header: /cvsroot/mapbender/mapbender/http/javascripts/mod_insertWmcIntoDb.php,v 1.19 2006/03/09 14:02:42 uli_rothstein Exp $
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
require_once(dirname(__FILE__)."/../classes/class_administration.php");
require_once(dirname(__FILE__)."/../classes/class_wmc.php");
require_once(dirname(__FILE__)."/../classes/class_json.php");

$json = new Mapbender_JSON();

// get data from POST and SESSION
$mapObject = $json->decode(stripslashes($_POST["mapObject"]));
$userId = $_SESSION["mb_user_id"];
$saveInSession = intval($_POST["saveInSession"]);
$generalTitle = $_POST["generalTitle"];
$extensionData = $json->decode(stripslashes($_POST["extensionData"]));

// create WMC object
$wmc = new wmc();
$wmc->createFromJs($mapObject, $generalTitle, $extensionData);

header("Content-Type: text/x-json");

if ($saveInSession === 1) {
	// store XML in session
	$_SESSION["mb_wmc"] = $wmc->xml;
	$_SESSION["epsg"] = $mapObject->epsg;
	$_SESSION["previous_gui"] = $_SESSION["mb_user_gui"];
	$e = new mb_notice("mod_insertWMCIntoDB: save WMC in session succeeded.");
}
else {
	// insert WMC into database
	$result = $wmc->insert();
	echo $result["message"];
}
?>
