<?php
# $Id$
# http://www.mapbender.org/index.php/gazetteerMetadata
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
require_once(dirname(__FILE__)."/../classes/class_administration.php");

$user_id = $_SESSION["mb_user_id"]; 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="author" content="V. Diewald">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="DC.Rights" content="WhereGroup GmbH & Co.KG, Bonn">
<title>Metadata search</title>
<?
include_once(dirname(__FILE__) . "/../include/dyn_css.php");
?>
<style type="text/css">
<!--
	body{
		font-family : Arial, Helvetica, sans-serif;
		font-size : 12px;
		font-weight : bold;
		color: #808080;
	}

	a:link{
		font-family : Arial, Helvetica, sans-serif;
		text-decoration : none;
		color: #808080;
		font-size : 12px;
		font-weight : normal;
	}
	a:visited{
		font-family : Arial, Helvetica, sans-serif;
		text-decoration : none;
		color: #808080;
		font-size : 12px;
		font-weight : normal;
	}
	a:hover{
		font-family : Arial, Helvetica, sans-serif;
		color: #808080;
		text-decoration : none;
		font-weight : normal;
	}
	a:active{
		font-family : Arial, Helvetica, sans-serif;
		color: #808080;
		text-decoration : none;
		font-weight : normal;
	}

	.textfield{
		border : 2 solid #D3D3D3;
		font-family : Arial, Helvetica, sans-serif;
		font-size : 12px;
		font-weight : normal;
		color: #000000;
		width: 120px;
	}
	
	.result{
		position: absolute;
		top: 40px;
		left: 0px;
	}
-->
</style>
<script type="text/javascript">
<!--

function validate(){

   if(document.form1.search.value.length < 1){
      alert("Please insert a keyword!");
      document.form1.search.focus();
      return false;
   }
   else{   
		document.getElementById("resultDivTag").innerHTML = "<table><tr><td><img src='../img/indicator_wheel.gif'></td><td>Searching...</td></tr></table>";
		var ind = parent.getMapObjIndexByName('mapframe1');
		
		parent.mb_ajax_json(
			"../php/mod_gazetteerMetadata_search.php", 
			{
				"search" : document.form1.search.value,
				"srs" : parent.mb_mapObj[ind].epsg
			}, 
			function(jsonObj, status){
				document.getElementById("resultDivTag").innerHTML = displayTable(jsonObj);
			}
		);
		return false;
   }
}

function displayTable(obj) {
	var text = "<table>";
	for (var attr in obj) {
		var resultObj = obj[attr];
		if (typeof(resultObj) != 'function') {
			text += "<tr><td valign='top'>";
			var imgUrl = "";
			var onclickFunction = "";
			if (typeof(resultObj.layer_name) !== "undefined") {
				imgUrl = "../img/button_gray/metadata_layer.gif";
				onclickFunction = "mod_addWMSLayerfromfilteredList(\"" + 
					resultObj.wms_getcapabilities + "\",\"" + 
					resultObj.wms_version + "\", \"" + 
					resultObj.layer_name+"\");";
			}
			else {
				imgUrl = "../img/button_gray/metadata_wms.gif";
				onclickFunction = "mod_addWMSfromfilteredList(\"" + 
					resultObj.wms_getcapabilities + "\",\"" + 
					resultObj.wms_version+"\");";
			}
			text += "<img name='add_wms' src='" + imgUrl + "' ";
			text += "border='0' title='Load' ";
			text += "onclick='" + onclickFunction + "'>";
			if (resultObj.extent && resultObj.extent[0] !== null) {
				text += "<img src='../img/tree_new/zoom.png' " + 
					"onclick='" + 
					"parent.mb_calculateExtent(\"mapframe1\", " + 
					resultObj.extent[0] + "," + 
					resultObj.extent[1] + "," + 
					resultObj.extent[2] + "," + 
					resultObj.extent[3] + ");" + 
					"parent.zoom(\"mapframe1\", \"true\", 1.0);" + 
					"'>";
			}
			text += "</td><td>";
			text += "<a href='#' ";
			text += "onclick='javascript:window.open(\"mod_layerMetadata.php?id=" + 
				resultObj.layer_id + 
				"\", \"metadata\", \"width=450, height=600\");' title='Info'>"; 
			text += resultObj.title+"</a>";	
			text += "</td></tr>";
		}
	}
	text += "</table>";
	return text;
}


function handleLayer(sel_lay, wms_title){
    
	//var wms_title = document.forms[0].wmsTitle.value

	var x = new Array();

    x[0] = sel_lay;

    var y = new Array();
    
    if (backlink =='parent'){
		var wms_ID = parent.parent.getWMSIDByTitle('mapframe1',wms_title);
	}
	else{
		var wms_ID = parent.getWMSIDByTitle('mapframe1',wms_title);
	}

    y[0] = wms_ID;
    
	//alert(wms_title + " -- X "+ x + "wms_id" + wms_ID);
	
	if (backlink =='parent'){
		parent.parent.handleSelectedLayer_array('mapframe1',y,x,'querylayer',1);
		parent.parent.handleSelectedLayer_array('mapframe1',y,x,'visible',1);
	}
	else{
		parent.handleSelectedLayer_array('mapframe1',y,x,'querylayer',1);
		parent.handleSelectedLayer_array('mapframe1',y,x,'visible',1);		
	}

}

function mod_addWMSfromfilteredList(pointer_name,version){

	pointer_name=pointer_name + parent.parent.mb_getConjunctionCharacter(pointer_name);
	if (version == '1.0.0'){
		var cap = pointer_name + "REQUEST=capabilities&WMTVER=1.0.0";
		var load = cap;
	}
	else if (version == '1.1.0'){
		var cap = pointer_name + "REQUEST=GetCapabilities&SERVICE=WMS&VERSION=1.1.0";
		var load = cap;
	}
	else if (version == '1.1.1'){
		var cap = pointer_name + "REQUEST=GetCapabilities&SERVICE=WMS&VERSION=1.1.1";
		var load = cap;
	}  
	//alert (load);

	if(load){
		if(load.charAt(0) == '/' && load.charAt(1) == 'c'){
			parent.parent.mod_addWMS_load('http://localhost' + load);
		}
		else{
			parent.parent.mod_addWMS_load(load);
		}  
	}
}

function mod_addWMSLayerfromfilteredList(pointer_name,version,layer_name){

	pointer_name=pointer_name + parent.parent.mb_getConjunctionCharacter(pointer_name);
	if (version == '1.0.0'){
		var cap = pointer_name + "REQUEST=capabilities&WMTVER=1.0.0";
		var load = cap;
		var layer_name = layer_name;
	}
	else if (version == '1.1.0'){
		var cap = pointer_name + "REQUEST=GetCapabilities&SERVICE=WMS&VERSION=1.1.0";
		var load = cap;
		var layer_name = layer_name;
	}
	else if (version == '1.1.1'){
		var cap = pointer_name + "REQUEST=GetCapabilities&SERVICE=WMS&VERSION=1.1.1";
		var load = cap;
		var layer_name = layer_name;
	}  
	//alert (load);

	if(load){
		if(load.charAt(0) == '/' && load.charAt(1) == 'c'){
			parent.parent.mod_addLayer_load('http://localhost' + load, layer_name);
		}
		else{
			parent.parent.mod_addLayer_load(load, layer_name);
		}  
	}
}
// -->
</script>
</head>
<body leftmargin="2" topmargin="0" bgcolor="#ffffff">
<form name='form1' target='result' onsubmit='return validate();'>
<p>
<input class='textfield' name='search' type='text' style='width:110px'>
<img src="../img/add.png" title="keywords" onclick="window.open('mod_SelectKeyword.php','SelectKeyword','width=600,height=400,status=no');">
<input type='submit' name='send' value='ok'>
</p>
</form>
<div id='resultDivTag' class='result'></div>
</body>
</html>
