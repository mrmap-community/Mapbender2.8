<?php
# $Id: mod_exportGUI.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_exportGUI.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Export GUI</title>
<?php
include '../include/dyn_css.php';
?>
<script type="text/javascript">
<!--
function validate(){
   var ind = document.form1.guiList.selectedIndex;
   if(ind > -1){
	   //alert (ind);
     var permission =  confirm("export: " + document.form1.guiList.options[ind].text + " ?");
     if(permission == true){
        document.form1.del.value = 1;
        document.form1.submit();
     }
   }
}
// -->
</script>
</head>
<body>

<?php

require_once(dirname(__FILE__)."/../classes/class_administration.php");
$admin = new administration();
$permguis = $admin->getGuisByPermission($_SESSION["mb_user_id"],true);

 ###export

if($guiList){
	$insert = "";
	//gui
	$sql_gui = "SELECT * FROM gui WHERE gui_name = $1 ";
	$v = array($guiList);
	$t = array('s');
	$res_gui = db_prep_query($sql_gui,$v,$t);
	
	$i = 0;
	while ($row = db_fetch_row($res_gui)){
		$insert =  "INSERT INTO gui (gui_id, gui_name, gui_description, gui_public) VALUES ";
		$insert.= "('".db_result($res_gui, 0, 0)."','".db_result($res_gui, 0, 1)."','".db_result($res_gui, 0, 2)."',".db_result($res_gui, 0, 3).");\n";
	}

	//gui_element
	$sql_gel = "SELECT * from gui_element WHERE fkey_gui_id = $1 ORDER BY e_id";
	$v = array($guiList);
	$t = array('s');
	$res_gel = db_prep_query($sql_gel,$v,$t);
	$cnt_gel = 0;

	while ($row = db_fetch_array($res_gel)){
		$insert.="INSERT INTO gui_element (fkey_gui_id, e_id, e_pos, e_public, e_comment, e_title, e_element,";
		$insert.="e_src, e_attributes, e_left, e_top, e_width, e_height, e_z_index, e_more_styles,";
		$insert.=" e_content, e_closetag, e_js_file, e_mb_mod, e_target, e_requires,e_url) VALUES (";
		
		$insert.="'".$row["fkey_gui_id"]."',";
		$insert.="'".$row["e_id"]."',";
		$insert.="".$row["e_pos"].",";
		$insert.="".$row["e_public"].",";
		$insert.="'".db_escape_string($row["e_comment"])."',";
		$insert.="'".db_escape_string($row["e_title"])."',";
		$insert.="'".$row["e_element"]."',";
		$insert.="'".$row["e_src"]."',";
		$insert.="'".db_escape_string($row["e_attributes"])."',";
		$insert.="".$row["e_left"].",";
		$insert.="".$row["e_top"].",";
		$insert.="".$row["e_width"].",";
		$insert.="".$row["e_height"].",";
		$insert.="".$row["e_z_index"].",";		
		$insert.="'".$row["e_more_styles"]."',";
		$insert.="'".db_escape_string($row["e_content"])."',";
		$insert.="'".$row["e_closetag"]."',";
		$insert.="'".$row["e_js_file"]."',";		
		$insert.="'".$row["e_mb_mod"]."',";
		$insert.="'".$row["e_target"]."',";
		$insert.="'".$row["e_requires"]."',";
		$insert.="'".$row["e_url"]."'";
		$insert.= ");\n";
		$insert = preg_replace("/,,/", ",NULL ,", $insert);
	}
	
	
	$sql_gelvars = "SELECT * from gui_element_vars WHERE fkey_gui_id = $1 ORDER BY fkey_e_id, var_name";
	$v = array($guiList);
	$t = array('s');
	$res_gelvars = db_prep_query($sql_gelvars,$v,$t);
	$cnt_gelvars = 0;

	while ($row = db_fetch_row($res_gelvars)){
		
		$insert.="INSERT INTO gui_element_vars(";
		$i=0;
		while($i < db_numfields($res_gelvars)){
			if($i > 0){
				$insert.=", ";
			}
			$insert.=db_fieldname($res_gelvars, $i);
			$i++;
		}
		$insert.=") VALUES (";
		$i = 0;
		while($i < db_numfields($res_gelvars)){
			if($i > 0){
				$insert.=", ";
			}
			$temp = db_escape_string($row[$i]);
			$temp = preg_replace("/>/","&gt;",$temp);
			$temp = preg_replace("/</","&lt;",$temp);
			$insert.="'" . $temp . "'";
			$i++;
		}
		$insert.=");\n";

		$cnt_gelvars++;

	}
	
	$insert = preg_replace("/,,/",",NULL,",$insert);
	$insert = preg_replace("/, ,/", ",NULL,",$insert);
	
	echo "<textarea rows=40 cols=80>";
	echo $insert; 
	echo "</textarea>";
}

###
if(!$guiList){
	$v = array();
	$t = array();
	$sql = "SELECT * FROM gui WHERE gui_id IN (";
	for($i=0; $i<count($permguis); $i++){
		if($i>0){ $sql .= ",";}
		$sql .= "$".($i + 1);
		array_push($v,$permguis[$i]);
		array_push($t,'s');
	}
	$sql .= ") ORDER BY gui_name";
	$res = db_prep_query($sql,$v,$t);
	$cnt = 0;
	echo "<form name='form1' action='" . $self ."' method='post'>";
	echo "<select class='guiList' size='20' name='guiList' class='guiList' onchange='document.forms[0].submit()'>";
	while($row = db_fetch_array($res)){
		print_r($row);
		echo "<option value='".$row["gui_id"]."'>".$row["gui_name"]."</option>";
		$cnt++;
	}
	echo "</select><br>";
}

?>
<input type='hidden' name='del'>
</form>
</body>
</html>
