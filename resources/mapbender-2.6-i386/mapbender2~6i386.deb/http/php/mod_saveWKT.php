<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php
# $Id: mod_saveWKT.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>mod_saveWKT</title>
<?php
include '../include/dyn_css.php';
?>
<script type="text/javascript">
<!--
function validate(){
	 document.forms[0].x.value = "";
     document.forms[0].y.value = "";
     for(var i=0; i<window.opener.mod_measure_RX.length;i++){
        if(i>0){ document.forms[0].x.value += ",";}
        document.forms[0].x.value += window.opener.mod_measure_RX[i];
     }
     for(var i=0; i<window.opener.mod_measure_RY.length;i++){
        if(i>0){ document.forms[0].y.value += ",";}
        document.forms[0].y.value += window.opener.mod_measure_RY[i];
     }
     document.forms[0].save.value='true';
     document.forms[0].src_epsg.value=window.opener.mod_measure_epsg.substr(5,5); //NEW!!!
     document.forms[0].submit();
}
var geoType;
function checkGeom(){
   if(window.opener.mod_measure_RX.length == 1){
      geoType = "POINT";
   }
   if(window.opener.mod_measure_RX.length > 1 && (window.opener.mod_measure_RX[0] =! window.opener.mod_measure_RX[window.opener.mod_measure_RX.length -1])){
      geoType = "MULTILINESTRING";
   }
   if(window.opener.mod_measure_RX.length > 1 && (window.opener.mod_measure_RX[0] == window.opener.mod_measure_RX[window.opener.mod_measure_RX.length -1])){
      geoType = "MULTIPOLYGON";
   }
   if(document.forms[0].myGeometryType.value != geoType){
      alert("Falscher Geometrietyp!");
   }      
}
// -->
</script>
</head>
<!-- <body onload='checkGeom()'>  
//NEW!!! Bei Erstaufruf ist die ausgew�hlte Tabelle (und deren Geometrie) noch nicht bekannt! 
Deshalb zuvor eine Fehlermeldung.  Jetzt als PHP-Code, siehe if($save)   -->
<body> 
<?php 
/*****************************************************************************
personal postgresql parameters - pers�nliche Postgresql-Einstellungen    */
$host = "localhost";
$port = "5432";
define("DBname", "databasename");
$user = "username";
$password = "password";
//personal example: pick only certain (working-) tables, here: tables which start with "mapbender_"
$tblmb="mapbender_%";  
//*****************************************************************************

import_request_variables("P");

$con_string = "host=$host port=$port dbname=DBname user=$user password=$password";
$con = pg_connect ($con_string) or die ("Error while connecting database DBname");
$sql = "SELECT f_table_name, f_geometry_column,type,srid FROM geometry_columns 
        where f_table_name like '$tblmb'"; //pick only certain tables (see above)
//$sql = "SELECT f_table_name, f_geometry_column,type,srid FROM geometry_columns";
$res = pg_query($con,$sql);
$cnt = 0;
echo "<form action='".$self."' method='POST'>";
#echo "Selektieren: <input name='actionType' type='radio' value='select'>";
#echo "Speichern: <input name='actionType' type='radio' value='create'><br>";
echo "<select name='tablenames' onchange='submit()'>";
echo "<option value=''>Bitte Tabelle ausw&auml;hlen...</option>";
while(pg_fetch_row($res)){   
   echo "<option value='".pg_result($res,$cnt,"f_table_name")."' ";
   if($tablenames == pg_result($res,$cnt,"f_table_name")){
      echo "selected";
      $geometry = pg_result($res,$cnt,"f_geometry_column");
      $geometryType = pg_result($res,$cnt,"type");
      $epsg = pg_result($res,$cnt,"srid");
   }
   echo ">".pg_result($res,$cnt,"f_table_name")."</option>";
   $cnt++;
}
echo "</select>";


if(isset($tablenames)){
   $sql = "SELECT * from ".$tablenames." limit 1";
   $res = pg_query($con,$sql);
   $num = pg_num_fields($res);
   
   echo "<table>";
   $cnt = 0;
   for($i=0; $i<$num; $i++){
      echo "<tr>";
      echo "<td>".pg_fieldname($res,$i)."</td><td><input type='text' name='".pg_fieldname($res,$i)."'></td><td>".pg_fieldtype($res,$i)."</td>";
      echo "</tr>";
      if(!isset($str_names)){
         $str_names = pg_fieldname($res,$i);
      }
      else{
         $str_names .= ",".pg_fieldname($res,$i);
      }
      $cnt++;        
   }
   echo "</table>";
   echo "<br>";
   echo "<input type='button' value='save' onclick='validate()'>";
   echo "<input type='hidden' value='' name='save'>";
   echo "<input type='text' value='".$x."' name='x'>";  //NEW!!!
   echo "<input type='text' value='".$y."' name='y'>";  //NEW!!!
   echo "<input type='text' value='".$geometry."' name='myGeometry'>";
   echo "<input type='text' value='".$geometryType."' name='myGeometryType'>";
   echo "<input type='text' value='".$src_epsg."' name='src_epsg'>";   //NEW!!!
   echo "<input type='text' value='".$epsg."' name='epsg'>";   
   echo "<input name='myStrColumns' type='text' value='".$str_names."'>";   
}
if($save){
 $myColumns = explode(",",$myStrColumns); 
 $myX = explode(",", $x);
 $myY = explode(",", $y);
 $myxcount = count($myX);
 
 if ($myxcount == 1) {
	$geoType = 'POINT';
 }
 if ($myxcount > 1 && $myX[0] != $myX[$myxcount-1]) {
	$geoType = 'MULTILINESTRING';
    if ($geometryType == 'LINESTRING') { $geoType = 'LINESTRING'; } //NEW!! funktioniert aber nur solange, wie keine wirklichen MULTILINESTRING's digitalisiert werden
 }
 if ($myxcount > 1 && $myX[0] == $myX[$myxcount-1]) {
	$geoType = 'MULTIPOLYGON';
    if ($geometryType == 'POLYGON') { $geoType = 'POLYGON'; } //NEW!! funktioniert aber nur...
 }
 //NEW!!! in Tabellen vom GEOMETRY-Typ lassen sich (datensatzweise) verschiedene Geometrien abspeichern
 if ($geometryType != $geoType && $geometryType != 'GEOMETRY') { 
	echo "<br>";
	echo "Geometrie (".$geoType.") stimmt nicht mit der der Tabelle (".$geometryType.") �berein!";
	die;
 }

 if(count(myX) != count(myY)){
   echo "Geometrie verschl�sselt.....................";
   die;
 }
 $sql = "INSERT INTO ".$tablenames."(";
 for($i=0; $i<count($myColumns); $i++){
   if($i>0){
      $sql .= ",";
   }
   $sql .= $myColumns[$i]; 
 }
 $sql .= ") ";
 $sql .= "VALUES (";
 for($i=0; $i<count($myColumns); $i++){
   if($i>0){
      $sql .= ",";
   } 

   if($myColumns[$i] == $myGeometry){
		//NEW!!  $geoType anstelle von $geometryType, um a) auch in Tabellen mit Geometrietyp 'Geometry' abspeichern zu k�nnen
		if ($geoType == "POINT") { 
			$sql .= "transform(GeometryFromText('".$geoType."("; //$geoType anstelle von $geometryType s. o.
		} elseif ($geoType == "LINESTRING") { 
			$sql .= "transform(GeometryFromText('".$geoType."("; 
		} elseif ($geoType == "MULTILINESTRING") { 
			$sql .= "transform(GeometryFromText('".$geoType."(("; 
		} elseif ($geoType == "POLYGON") { 
			$sql .= "transform(GeometryFromText('".$geoType."(("; 
		} elseif ($geoType == "MULTIPOLYGON") { 
			$sql .= "transform(GeometryFromText('".$geoType."((("; 
		}
     	for($j=0; $j<count($myX); $j++){  
     		if($j > 0){$sql .= ", ";}
  	   	$sql .= $myX[$j] . " " . $myY[$j];
     	}  	
		if ($geoType == "POINT") {
//			$sql .= ")))',".$src_epsg."),".$epsg.")"; //OLD!!!  so funktioniert es mit postgis Version 0.9 !!
			$sql .= ")',".$src_epsg."),".$epsg.")"; //NEW!!! aber nur so mit 1.0.0 RC6
			} elseif ($geoType == "LINESTRING") { //NEW!!!
			$sql .= ")',".$src_epsg."),".$epsg.")"; 
			} elseif ($geoType == "MULTILINESTRING") { 
//			$sql .= "))))',".$src_epsg."),".$epsg.")";  // 0.9
			$sql .= "))',".$src_epsg."),".$epsg.")"; // postgis 1.0.0
			} elseif ($geoType == "POLYGON") { 
			$sql .= "))',".$src_epsg."),".$epsg.")"; //NEW!!!
			} elseif ($geoType == "MULTIPOLYGON") { 
//			$sql .= ")))))',".$src_epsg."),".$epsg.")";  // 0.9
			$sql .= ")))',".$src_epsg."),".$epsg.")"; // postgis 1.0.0
		} 
/* Linestrings lassen sich in MULTILINESTRING, Polygone in MULTIPOLYGON-Tabellen abspeichern, wenn gegen $geoType gepr�ft wird, ergibt sich kein Problem
// da sich aber MULTI... nicht in Tabellen vom einfachen Typ LINESTRING bzw. POLYGON  abspeichern lassen, wurde dies oben (unelegant) abgefangen		
		else {
			echo "<br>Tabelle vom Typ Linestring, Polygon etc?";
		}
*/
   }
   else{
      $sql .= "'".$_REQUEST[$myColumns[$i]]."'";
   }
 }
 $sql .= ")";
 #echo  $sql;
$res = pg_query($con,$sql);
}

?>
</form>
</body>
</html>