<?php
# $Id: mod_printView1.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include(dirname(__FILE__)."/../../conf/print.conf");
$_SESSION["mb_print_url"] = $map_url;
$_SESSION["mb_print_resolution"] = $quality;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta name="author-mail" content="info@ccgis.de">
<meta name="author" content="U. Rothstein">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Print Settings</title>
<?php
include '../include/dyn_css.php';
?>
<style type="text/css">
	<!--

	.bg_header{
		background-color: white;
	}
	.bg{
		background-color: black;
	}
	body{
		font-family: Arial, Helvetica, sans-serif;
	}
	-->
</style>
</head>
<body leftmargin="0" topmargin="0"> 
<?php

$printOffset_top = intval($_REQUEST["printOffset_top"]) * $deformation;
$printOffset_left = intval($_REQUEST["printOffset_left"]) * $deformation;
$header_height = intval($_REQUEST["header_height"]) * $deformation;
$map_width = intval($_REQUEST["map_width"]) * $deformation;
$map_height = intval($_REQUEST["map_height"]) * $deformation;
$date = date("d.m.y");
#map
echo "<img style='position:absolute; top:".($printOffset_top + $header_height)."px; left:".($printOffset_left+1)."px; z-index:3;' src='../extensions/ext_weldMaps.php?". SID."' width='".$map_width."' height='".$map_height."'>";
echo "<img style='position:absolute; top:".($printOffset_top + $header_height)."px; left:".($printOffset_left+1)."px; z-index:2;' src='../img/white.gif' width='".$map_width."' height='".$map_height."'>";

echo "<img class='bg' style='position: absolute; top:".($printOffset_top - 1)."px;left:".($printOffset_left-1)."px; z-index:1;width:".($map_width+3)."px; height:".($map_height +$header_height +2)."px;' src='../img/black.gif'>";
#header


echo "<img class='bg_header' style='position: absolute; top:".($printOffset_top+1)."px;left:".($printOffset_left+1)."px; z-index:1;width:".($map_width/2-1)."px; height:".($header_height -2)."px;' src='../img/white.gif'>";

echo "<div  style='position: absolute; top:".($printOffset_top+1)."px;left:".($printOffset_left+1)."px; z-index:1;width:".($map_width/2-1)."px; height:".($header_height -2)."px;'>";
echo "<div style='position:relative;left:5px; font-weight:bold; font-size:20px;z-index:3;'>".$printTitle . "</div>";
echo "<div style='position:relative;left:5px;z-index:3;'>Datum: ".$date . "</div>";
echo "<div style='position:relative;left:5px;z-index:3;'>Ma�stab: 1:".$map_scale . "</div>";
echo"</div>"; 

echo "<img class='bg_header' style='position: absolute; top:".($printOffset_top+1)."px;left:".($printOffset_left + $map_width/2+2)."px; z-index:1;width:".($map_width/2-1)."px; height:".($header_height -2)."px;' src='../img/white.gif'>";
echo "<div style='position: absolute; top:".($printOffset_top+1)."px;left:".($printOffset_left + $map_width/2+2)."px; z-index:1;width:".($map_width/2-1)."px; height:".($header_height -2)."px;' >";
echo "<div style='position:relative;left:5px;z-index:3;'>".$printComment . "</div>";
echo"</div>"; 

echo "<div style='position: absolute; top:".($printOffset_top + $header_height + $map_height+5)."px;left:".($printOffset_left+2)."px; z-index:3;font-size:10px' >";
echo $footer;
echo "</div>";
#$myfactor = 37.81;
#echo "<img style='position: absolute; top:".($printOffset_top + $header_height + $map_height+10)."px;left:".($printOffset_left+2)."px; '  src='../img/black.gif' height='2' width='".(10 * $myfactor)."'>"; 
?>
</body>
</html>
