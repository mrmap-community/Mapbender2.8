<?php
# $Id: mod_export_image.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_export_image.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validateSession.php");

$_SESSION["mb_print_url"] = $map_url;
$_SESSION["mb_print_resolution"] = $quality;
header("Content-type: application/png"); // mark the following content as PNG file
$date = date("d.m.y");
header("Content-Disposition: attachment; filename=export".$date.".png");
header("Pragma: no-cache");
header("Expires: 0");
include(dirname(__FILE__)."/../../conf/print.conf");
$header_height = intval($_REQUEST["header_height"]) * $deformation;
$map_width = intval($_REQUEST["map_width"]) * $deformation;
$map_height = intval($_REQUEST["map_height"]) * $deformation;
$date = date("d.m.y");
#map
//include "../classes/class_weldMaps2PNG.php";
include "../extensions/exp_weldMaps.php";
//$i = new weldMaps($map_urls, $_SESSION["mb_print_resolution"]);
//print $i;
?>