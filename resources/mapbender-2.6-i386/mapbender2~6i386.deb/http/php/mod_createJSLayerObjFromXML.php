<?php
# $Id: mod_createJSLayerObjFromXML.php 868 2006-11-20 14:30:43Z verena $
# http://www.mapbender.org/index.php/mod_createJSLayerObjFromXML.php
# Copyright (C) 2006 WhereGroup 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
require_once(dirname(__FILE__)."/../classes/class_wms.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Load WMS with one layer</title>
<?php
echo "<script type='text/javascript'>";
$mywms = new wms();
$mywms->createObjFromXML(html_entity_decode($_REQUEST['caps']));
if(!$mywms->wms_status){ echo "alert('Error: The Capabilities Document " . html_entity_decode($_REQUEST['caps']) . " could not be accessed. Please check whether the server is responding and accessible to Mapbender.'); </script>"; die; }
$mywms->createJsLayerObjFromWMS("TRUE", $_REQUEST['layer_name']);
echo "parent.mod_addWMS_refresh();";
echo "</script>";
?>
</head>
<body bgcolor='#ffffff'>

</body>
</html>