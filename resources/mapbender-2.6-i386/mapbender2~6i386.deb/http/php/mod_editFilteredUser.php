<?php
# $Id: mod_editFilteredUser.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/Administration
#
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
$myUser = true;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Edit Filtered User</title>
<?php
include '../include/dyn_css.php';
$myPW = "**********";
echo "<script language='JavaScript'>var myPW = '".$myPW."';</script>";
?>
<script language="JavaScript">

function validate(val){
   var ok = validateInput();
   if(ok == 'true'){
     var permission = false;
     if(val == 'save'){
        permission = confirm("Save changes?");
     }
     if(val == 'update'){
        permission = confirm("Save changes?");
     }
     if(val == 'delete'){
        permission = confirm("Delete User?");
     }
     if(permission === true){
        if(document.forms[0].password.value == myPW){
            document.forms[0].password.value = '';
        }
        document.forms[0].action.value = val;
        document.forms[0].submit();
     }
   }
}
function validateInput(){
  var str_alert = "Input incorrect !";
  if(document.forms[0].name.value === ''){
      alert(str_alert);
      document.forms[0].name.focus();
      return 'false';
  }
  if(document.forms[0].password.value === ''){
      alert(str_alert);
      document.forms[0].password.focus();
      return 'false';
  }
  if((document.forms[0].password.value != myPW || document.forms[0].v_password.value !== '' )&& document.forms[0].password.value != document.forms[0].v_password.value){
      alert("Password verification failed. You have to enter the same password twice!");
      document.forms[0].password.value = myPW;
      document.forms[0].password.focus();
      return 'false';
  }
  if(document.forms[0].resolution.value === ''){
      document.forms[0].resolution.value = 72;
      return 'true';
  }
  if(document.forms[0].login_count.value === ''){
      document.forms[0].login_count.value = 0;
      return 'true';
  }
  return 'true';
}
/**
 * filter the Userlist by str
 */
function filterUser(list, all, str){
	str=str.toLowerCase();
	var selection=[];
	var i,j,selected;
	for(i=0;i<list.options.length;i++){
		if (list.options[i].selected) {
			selection[selection.length] = list.options[i].value;
		}
	}
	
	list.options.length = 1;
	for(i=0; i<all.length; i++){
		if (all[i].name.toLowerCase().indexOf(str) == -1) {
			continue;
		}
		selected=false;
		for(j=0;j<selection.length;j++){
			if(selection[j]==all[i].id){
				selected=true;
				break;
			}
		}
		var newOption = new Option(all[i].name, all[i].id,false,selected);
		newOption.setAttribute("title", all[i].email);
		list.options[list.options.length] = newOption;
	}	
}
</script>

</head>
<body>
<?php
#delete
if($action == 'delete'){
   $sql = "DELETE FROM mb_user WHERE mb_user_id = $1";
   $v = array($selected_user);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   $selected_user = 'new';
}

#save
if($action == 'save'){
	$sql = "SELECT mb_user_id FROM mb_user WHERE mb_user_name = $1 ";
	$v = array($name);
	$t = array('s');
	$res = db_prep_query($sql,$v,$t);
	if(db_fetch_row($res)){
		echo "<script language='JavaScript'>alert('Username must be unique!');</script>";
	}
	else{
		$sql = "Insert INTO mb_user (mb_user_name, mb_user_password, mb_user_owner, mb_user_description, ";
		$sql .= "mb_user_email, mb_user_phone, mb_user_department, mb_user_resolution) VALUES ";
		$sql.= "($1,$2,$3,$4,$5,$6,$7,$8)";	
		$tmpPW = md5($password);
		$v = array($name,$tmpPW,$owner_id,$description,$email,$phone,$department,$resolution);
		$t = array('s','s','i','s','s','s','s','i');
		$res = db_prep_query($sql,$v,$t);
		$selected_user = db_insert_id($res,"mb_user","mb_user_id");
	}
}

#update
if($action == 'update'){
	$sql = "SELECT mb_user_id FROM mb_user WHERE mb_user_name = $1 AND mb_user_id <> $2";
	$v = array($name,$selected_user);
	$t = array('s','i');
	$res = db_prep_query($sql,$v,$t);
	if(db_fetch_row($res)){
		echo "<script language='JavaScript'>alert('Username must be unique!');</script>";
	}
	else{
		$sql = "UPDATE mb_user SET mb_user_name = $1";			
		$sql.=", mb_user_description = $2";
		$sql.=", mb_user_login_count = $3";
		$sql.=", mb_user_email = $4";
		$sql.=", mb_user_phone = $5";
		$sql.=", mb_user_department = $6";
		$sql.=", mb_user_resolution = $7";
		$sql.=" where mb_user_id = $8";
		$v = array($name,$description,$login_count,$email,$phone,$department,$resolution,$selected_user);
		$t = array('s','s','i','s','s','s','i','i');     
		$res = db_prep_query($sql,$v,$t);		
		if($password != ''){
			$sql = "UPDATE mb_user SET mb_user_password = $1 WHERE mb_user_name = $2";
			$v = array(md5($password), $name);
			$t = array('s','s');
			$res = db_prep_query($sql,$v,$t);
			if($password && $res){
				echo "<script language='JavaScript'>alert('Password has been updated successfully!');</script>";
			}	
		}
	}
}
if (!isset($name) || $selected_user == 'new'){
  $name = "";
  $password = "";
  $owner_id = $_SESSION["mb_user_id"];
  $owner_name = $_SESSION["mb_user_name"];
  $description = "";
  $login_count = 0;
  $email = "";
  $phone = "";
  $department = "";
  $resolution = 72;
}


/*HTML*****************************************************************************************************/

echo "<form name='form1' action='" . $self ."' method='post'>";
echo "<table border='0'>";
#User
echo "<tr>";
   echo "<td>";
      echo "User: ";
   echo "</td>";
echo "<td>";
   echo "<input type='text' value='' onkeyup='filterUser(document.getElementById(\"selecteduser\"),user,this.value);'/>";
   echo "<br /><select id='selecteduser' name='selected_user' onchange='submit()'>";
   echo "<option value='new'>NEW...</option>";
	$sql = "SELECT mb_user_name,mb_user_id,mb_user_email FROM mb_user ";
	$v = array();
	$t = array();
	if (isset($myUser)) { 
		$sql .= "WHERE mb_user_owner = $1";
		array_push($v, $_SESSION["mb_user_id"]);
		array_push($t, "i");
	}
	$sql .= " ORDER BY mb_user_name ";
	$res = db_prep_query($sql, $v, $t);
   $count=0;
   while($row = db_fetch_array($res)){
	 	echo "<option value='".$row["mb_user_id"]."' title='".$row["mb_user_email"]."'";
   		if($selected_user && $selected_user == $row["mb_user_id"]){
         echo "selected";
      }
      echo ">".$row["mb_user_name"]."</option>";
	  $user_id[$count] = $row["mb_user_id"];
	  $user_name[$count] = $row["mb_user_name"];
	  $user_email[$count] = $row["mb_user_email"];      
      $count++;
   }
   $cnt_user=$count;
   echo "</select>";
   echo "</td>";
echo "</tr>";


if(isset($selected_user) && $selected_user != 0){
   $sql = "SELECT * FROM mb_user WHERE mb_user_id = $1 ORDER BY mb_user_name ";
   $v = array($selected_user);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   if($row = db_fetch_array($res)){
      $name = $row["mb_user_name"];
      $password = $row["mb_user_password"];
      $owner_id = $row["mb_user_owner"];
      $description = $row["mb_user_description"];
      $login_count = $row["mb_user_login_count"];
      $email = $row["mb_user_email"];
      $phone = $row["mb_user_phone"];
      $department = $row["mb_user_department"];
      $resolution = $row["mb_user_resolution"];
   }
   $sql = "SELECT mb_user_name FROM mb_user WHERE mb_user_id = $1";
   $v = array($owner_id);
   $t = array('i');
   $res = db_prep_query($sql,$v,$t);
   if($row = db_fetch_array($res)){
      $owner_name = $row["mb_user_name"];
   }
}
#name
echo "<tr>";
   echo "<td>Name:</td>";
   echo "<td>";
      echo "<input type='text' size='30' name='name' value='".$name."'>";
   echo "</td>";
echo "</tr>";

#password
echo "<tr>";
   echo "<td>Password: </td>";
   echo "<td>";
      echo "<input type='password' size='30' name='password' value='";
      if(isset($selected_user) && $selected_user != 'new'){
         echo $myPW;
      }
      echo "' >";
   echo "</td>";
echo "</tr>";

#confirm password
echo "<tr>";
   echo "<td>Confirm password: </td>";
   echo "<td>";
      echo "<input type='password' size='30' name='v_password' value='";
      echo "'>";
   echo "</td>";
echo "</tr>";


#owner
echo "<tr>";
   echo "<td>Owner: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='owner_name' value='".$owner_name."' readonly>";
      echo "<input type='hidden' size='30' name='owner_id' value='".$owner_id."' readonly>";
   echo "</td>";
echo "</tr>";

#description
echo "<tr>";
   echo "<td>Description: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='description' value='".$description."'>";
   echo "</td>";
echo "</tr>";


#login_count
echo "<tr>";
   echo "<td>Login_count: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='login_count' value='".$login_count."'>";
   echo "</td>";
echo "</tr>";

#email
echo "<tr>";
   echo "<td>Email: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='email' value='".$email."'>";
   echo "</td>";
echo "</tr>";

#phone
echo "<tr>";
   echo "<td>Phone: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='phone' value='".$phone."'>";
   echo "</td>";
echo "</tr>";

#department
echo "<tr>";
   echo "<td>Department: </td>";
   echo "<td>";
      echo "<input type='text' size='30' name='department' value='".$department."'>";
   echo "</td>";
echo "</tr>";

echo"</table>";

#resolution
#echo "<tr>";
#   echo "<td>Resolution: </td>";
#   echo "<td>";
      echo "<input type='hidden' size='30' name='resolution' value='".$resolution."'>";
#   echo "</td>";
#echo "</tr>";

if($selected_user == 'new' || !isset($selected_user)){
   echo "<input type='button' value='save'  onclick='validate(\"save\")'>";
}
if($_SESSION["mb_user_id"] == $owner_id && $selected_user != 'new' && $selected_user != '' ){
   echo "<input type='button' value='save'  onclick='validate(\"update\")'>";
   echo "<input type='button' value='delete'  onclick='validate(\"delete\")'>";
}
?>
<input type='hidden' name='action' value=''>
</form>
<script type="text/javascript">
<!--
var user=[];
<?php
for($i=0; $i<$cnt_user; $i++){
	echo "user[".($i)."]=[];\n";
	echo "user[".($i)."]['id']='" . $user_id[$i]  . "';\n";
	echo "user[".($i)."]['name']='" . $user_name[$i]  . "';\n";
	echo "user[".($i)."]['email']='" . $user_email[$i]  . "';\n";
}
?>
// -->
</script>
</body>
</html>