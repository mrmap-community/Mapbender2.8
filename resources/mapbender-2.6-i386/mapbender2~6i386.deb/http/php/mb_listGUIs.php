<?php
# $Id: mb_listGUIs.php 3684 2009-03-12 16:40:57Z astrid_emde $
# http://www.mapbender.org/index.php/mb_listGUIs.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

function mb_listGUIs($arrayGUIs){
	if(count($arrayGUIs) === 0) {
		echo "<h1>Error</h1>";
		echo "<p>There are no GUIs available for this user.</p>";
		printf("<p><a href=\"../php/mod_logout.php?%s\"><img src=\"../img/button_gray/logout_off.png\" onmouseover=\"this.src='../img/button_gray/logout_over.png'\" onmouseout=\"this.src='../img/button_gray/logout_off.png'\" title=\"Logout\"></a></p>",SID);
		
		return;
	}
	
	$v = array();
	$t = array();

	$sql  = "SELECT DISTINCT gui_id,gui_name,gui_description, ggc.*,gc.category_name,gc.category_description ";
	$sql .= "FROM gui g ";
	$sql .= "LEFT JOIN gui_gui_category ggc ON g.gui_id = ggc.fkey_gui_id ";
	$sql .= "LEFT JOIN gui_category gc ON (ggc.fkey_gui_category_id = gc.category_id) ";
	$sql .= "WHERE gui_id IN (";

	for($i = 0; $i < count($arrayGUIs); $i++) {
		if($i > 0) {
			$sql .= ",";
		}
		
		$sql .= "$".($i + 1);
		
		array_push($v,$arrayGUIs[$i]);
		array_push($t,'s');
	}
	
	$sql .= ") ORDER BY gc.category_name, gui_name";
		
	$result = db_prep_query($sql,$v,$t);
	
	$category = NULL;
echo "<h1><font align='left' color='#000000'>Ma</font><font color='#0000CE'>p</font><font color='#C00000'>b</font><font color='#000000'>ender </font> - "._mb('available Applications')."</h1>";
	printf("<p><a href=\"../php/mod_logout.php?%s\"><img src=\"../img/button_gray/logout_off.png\" onmouseover=\"this.src='../img/button_gray/logout_over.png'\" onmouseout=\"this.src='../img/button_gray/logout_off.png'\" title=\"Logout\"></a></p>",SID);
	
	$total_guis = 0;
	while($row = db_fetch_array($result)){
		if($category !== $row["category_name"]) {
			$category = $row["category_name"];
			
			echo "</ul>";
			
			if(strlen($row["category_name"]) > 0) {
				printf("<h2 class=\"gui_category\">%s</h2>",$row["category_name"]);
			}else{
				printf("<h2 class=\"gui_category\">%s</h2>","");
			}
			if(strlen($row["category_description"]) > 0) {
				printf("<p class=\"gui_category_description\"><em>%s</em></p>",$row["category_description"]);
			}else{
				printf("<p class=\"gui_category_description\"><em>%s</em></p>","");
			}
			
			echo "<ul class=\"gui_list\">";
		}
		
		$class = ($total_guis %2 === 0) ? " class=\"alternate\"" : NULL;
		$url   = sprintf("index.php?%s&gui_id=%s",strip_tags(SID),$row["gui_id"]);
		printf("<li%s onclick=\"location.href='%s'\"><strong><a href=\"%s\">%s</a></strong><br /><em>%s</em></li>",$class,$url,$url,$row["gui_name"],$row["gui_description"]);
		
		$total_guis++;
	}
}
?>