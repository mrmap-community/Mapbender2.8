<?php
# $Id: mb_validateSession.php 2601 2008-07-08 12:18:22Z christoph $
# http://www.mapbender.org/index.php/mb_validateSession.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../../core/globalSettings.php");


$e = new mb_notice("mb_validateSession.php: checking file " . $_SERVER["PHP_SELF"]);

//
// check if user data is valid; if not, return to login screen
//
if (!isset($_SESSION["mb_user_id"]) || 
	!isset($_SESSION["mb_user_ip"]) || 
	$_SESSION['mb_user_ip'] != $_SERVER['REMOTE_ADDR']) {

		$e = new mb_exception("mb_validateSession.php: Invalid user: " . $_SESSION["mb_user_id"]);
		header("Location: " . LOGIN);
		die();
}

//
// set the global var gui_id
//
if (!$gui_id) {
	$e = new mb_notice("gui id not set");
	if ($_REQUEST["guiID"]) {
		$gui_id = $_REQUEST["guiID"];
		$e = new mb_notice("gui id set to guiID: " . $gui_id);
	}
	elseif ($_REQUEST["gui_id"]) {
		$gui_id = $_REQUEST["gui_id"];
		$e = new mb_notice("gui id set to gui_id: " . $gui_id);
	}
	else {
		$e = new mb_notice("mb_validateSession.php: gui_id not set in script: " . $_SERVER["PHP_SELF"]);
	}
}

//
// set the global var e_id
//
if (!$e_id) {
	if (isset($_REQUEST["elementID"])) {
		$e_id = $_REQUEST["elementID"];
	}
	elseif (isset($_REQUEST["e_id"])) {
		$e_id = $_REQUEST["e_id"];
	}
	else {
		$e = new mb_notice("mb_validateSession.php: e_id not set in script: " . $_SERVER["PHP_SELF"]);
	}
}

//
// set variables used for form targets or links
//
$urlParameters = SID;
if (isset($gui_id)) {
	$urlParameters .= "&guiID=" . $gui_id;
}
if (isset($e_id)) {
	$urlParameters .= "&elementID=" . $e_id;
}
$self = $_SERVER["PHP_SELF"] . "?" . $urlParameters;

$e = new mb_notice("mb_validateSession.php: GUI: " . $gui_id . ", checking file " . $_SERVER["PHP_SELF"] . "...session valid.");
?>