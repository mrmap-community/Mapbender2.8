<?php
require_once(dirname(__FILE__) . "/../php/mb_validatePermission.php");
require_once(dirname(__FILE__) . "/../classes/class_json.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET;?>" />
		<title>Untitled Document</title>
		<style type="text/css">
			.ui-selecting {
			  color:red;
			}
			.treeNode {
			  color:green;
			}
			.treeLeaf {
			  color:blue;
			}
			.ui-selected {
			  border-width:thin;
			  border-style:solid;
			  border-color:red;
			  background-color:transparent;
			  font-size:9px;
			}
			.ui-draggable {
			}
			.div-border {
			  border-width:thin;
			  border-style:solid;
			  border-color:black;
			  background-color:transparent;
			  font-size:9px;
			}
			.contextMenu
			{
				display:none;
			}
		</style>
		<link rel='stylesheet' type='text/css' href='../css/popup.css'>
		<script type='text/javascript'>
<?php

	require_once(dirname(__FILE__) . "/../extensions/jquery-1.2.6.min.js");
	require_once(dirname(__FILE__) . "/../extensions/jquery-ui-personalized-1.5.2.js");
	require_once(dirname(__FILE__) . "/../extensions/jquery.contextmenu.r2.js");
	require_once(dirname(__FILE__) . "/../extensions/jqjson.js");
	require_once(dirname(__FILE__) . "/../javascripts/popup.js");
	require_once(dirname(__FILE__) . "/../../lib/event.js");
	require_once(dirname(__FILE__) . "/../../lib/customTreeModel.js");
	require_once(dirname(__FILE__) . "/../../lib/customTreeController.js");
	require_once(dirname(__FILE__) . "/../../lib/buttonNew.js");

?>
			var myTree = new CustomTree();

			var applicationId;

			var findAllWmsInTree = function (aTree) {
				return findAllWmsInNode(aTree.root).sort();
			};

			findAllWmsInNode = function (aNode) {
				if (!aNode.isFolder) {
					return [aNode.wmsId];
				}
				var wmsIdArray = [];
				for (var i = 0; i < aNode.childNodeList.count(); i++) {
					var child = aNode.childNodeList.get(i);
					var newArray = findAllWmsInNode(child);
					wmsIdArray = wmsIdArray.concat(newArray);
				}
				return wmsIdArray;
			};

			var saveTreeOnUnloadOrChange = function (myTree) {
				if (myTree.hasChanged) {
					var saveChanges = confirm("You have changed the tree. All changes will be lost. Save changes?");

					if (saveChanges) {
						Save.updateDatabase(function () {
						});
					}

				}
			};

			var addMissingWmsToCustomTree = function (aTree, anApplicationId) {
				// get available WMS ...
				var queryObj = {
					command:"getWmsByApplication",
					parameters: {
						"applicationId": anApplicationId
					}
				};				

				$.post("../php/mod_customTree_server.php", {
					queryObj:$.toJSON(queryObj)
				}, function (json, status) {
					var replyObj = eval('(' + json + ')');

					var root = aTree.root;

					var wmsIdArray = findAllWmsInTree(aTree);
					
					for (var index in replyObj.data.wmsArray) {
						var found = false;
						for (var j = 0; j < wmsIdArray.length; j++) {
							if (wmsIdArray[j] == index) {
								found = true;
								break;
							}
						}
						if (!found) {
							var wmsNode = new CustomTreeNode();
							wmsNode.name = replyObj.data.wmsArray[index];
							wmsNode.wmsId = index;
							myTree.root.append(wmsNode);
						}
					}

					myTree.hasChanged = false;
					
					displayMyTree = new customTreeController(myTree, {
						contextMenu: true,
						droppable: true,
						id: "myTree"
					});
					
				});
			};

			var getCustomTreeByApplication = function (applicationName) {
				// load a previously saved 
				// customized tree from the database
				var queryObj = {
					command:"getCustomTreeByApplication",
					parameters: {
						"applicationId":applicationName
					}
				};				

				$.post("../php/mod_customTree_server.php", {
					queryObj:$.toJSON(queryObj)
				}, function (json, status) {
					var replyObj = eval('(' + json + ')');

					myTree = new CustomTree();
					var root = myTree.root;
					root.name = "(" + applicationId + ")";

					var nodeArray = replyObj.data.nodeArray;
					
					myTree.importNestedSets(nodeArray);

					addMissingWmsToCustomTree(myTree, applicationId);

					displayMyTree = new customTreeController(myTree, {
						contextMenu: true,
						droppable: true,
						id: "myTree"
					});
				});
			};

			var selectApplication = function (applicationName) {

				applicationId = applicationName;

				getCustomTreeByApplication(applicationId);
			}
			
			var getApplications = function () {
				var queryObj = {
					command:"getApplications"
				};				
				$.post("../php/mod_customTree_server.php", {
					queryObj:$.toJSON(queryObj)
				}, function (json, status) {
					var replyObj = eval('(' + json + ')');

					$select = $("#applicationSelect");
					$select.change(function () {
						saveTreeOnUnloadOrChange(myTree);
						selectApplication(this.options[this.selectedIndex].value);
					});

					for (var index in replyObj.data.applicationArray) {
						var currentApplication = replyObj.data.applicationArray[index];
						$currentOption = $("<option id='application" + index + "' value='" + currentApplication + "'>" + currentApplication + "</option>");
						$select.append($currentOption);
					}
				});
			};
			
			var Save = {
				buttonParameters : {
					on:"../img/button_blink_red/wmc_save_on.png",
					over:"../img/button_blink_red/wmc_save_over.png",
					off:"../img/button_blink_red/wmc_save_off.png",
					type:"toggle"
				},
				updateDatabase : function (callback) {
					if (!applicationId || applicationId == "...") {
						callback();
						return;
					}

					var data = {
						"applicationId": applicationId,
						"folderArray": myTree.exportNestedSets()
					};
					var queryObj = {
						command:"update",
						parameters:{
							data: data
						}
					};
					$.post("mod_customTree_server.php", {
						queryObj:$.toJSON(queryObj)	
					}, function (json, status) {
						var replyObj = eval('(' + json + ')');
						alert(replyObj.success);
						myTree.hasChanged = false;
						callback();
					});
				}
			};

			var Restart = {
				buttonParameters : {
					on:"../img/button_blink_red/exit_on.png",
					over:"../img/button_blink_red/exit_over.png",
					off:"../img/button_blink_red/exit_off.png",
					type:"singular"
				},
				removeAllFolders: function(){
					if (!applicationId || applicationId == "...") {
						return;
					}
					
					var confirmDelete = confirm("You are about to delete your customized folder structure. Proceed?");

					if (confirmDelete) {
						var queryObj = {
							"command": "delete",
							"parameters": {
								"applicationId": applicationId
							}
						};
						
						$.post("../php/mod_customTree_server.php", {
							queryObj: $.toJSON(queryObj)
						}, function(json, status){
							myTree = new CustomTree();
							var root = myTree.root;
							root.name = "(" + applicationId + ")";
							
							addMissingWmsToCustomTree(myTree, applicationId);
						});
						
					}
				}
			}
						
			$(function () {

				getApplications();

				var toolbox = new ButtonGroup("controls");

				// save tool
				var saveButton = new Button(Save.buttonParameters);
				toolbox.add(saveButton);

				saveButton.registerPush(function () {
					Save.updateDatabase(saveButton.triggerStop);	
				});

				// restart tool
				var restartButton = new Button(Restart.buttonParameters);
				toolbox.add(restartButton);
				
				restartButton.registerPush(function () {
					Restart.removeAllFolders();
				});

				// dialogue: save changes on unload
				$(window).unload(function () {
					saveTreeOnUnloadOrChange(myTree);
				})
			});
			
		</script>
	</head>
	<body>
		<select id='applicationSelect'>
			<option>...</option>
		</select>
		<div id="controls"></div>
		<hr>
		<div class="contextMenu" id="folderMenu">
			<ul>
				<li id="addFolder"><img src="images/folder_add.png" /> Add </li>
				<li id="deleteFolder"><img src="images/folder_delete.png" /> Delete</li>
				<li id="editFolder"><img src="images/folder_edit.png" /> Edit</li>
			</ul>
		</div>
		<div class="contextMenu" id="rootMenu">
			<ul>
				<li id="addFolder"><img src="images/folder_add.png" /> Add </li>
			</ul>
		</div>
		<div id='myTree'></div>
		<div id='wmsTree'></div>
	</body>
</html>