<?php
# $Id: mod_map1.php 3223 2008-11-12 08:48:37Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>

<title>mod_map1</title>
<?php
$sql = "SELECT e_width, e_height FROM gui_element WHERE e_id = 'mapframe1' AND fkey_gui_id = $1";
$v = array($_SESSION["mb_user_gui"]);
$t = array("s");
$res = db_prep_query($sql, $v, $t);
$cnt = 0;
while($row = db_fetch_array($res)){
   $e_width = $row["e_width"];
   $e_height = $row["e_height"];
   $cnt++;
}
session_write_close();
if($cnt > 1){ echo "alert('mapframe1: ID not unique!');";}
echo '<script type="text/javascript">';
echo "\n";
echo "var mod_map1_width = '".$e_width."';\n";
echo "var mod_map1_height = '".$e_height."';\n";
echo "</script>\n";
?>
<!--
<script type='text/javascript' src='../extensions/jquery-1.2.6.min.js'></script>
<script type='text/javascript' src='../extensions/jquery.mousewheel.min.js'></script>
<script type='text/javascript' src='../extensions/jqjson.js'></script>
-->
<script type="text/javascript">
<!--

var mapTimeout;
var	sum_delta = 0;
var lastTimestamp;
var lastScrollPositionX;
var lastScrollPositionY;

function init () {
	
	parent.eventInitMap.register(function init_mod_map1(){
		parent.mb_registerMapObj('mapframe1', 'mapframe1', null,mod_map1_width, mod_map1_height);
		
		if (!parent.$.browser.msie) {
			
			parent.$(document, window.frames['mapframe1']).mousewheel(function (event, delta) {
				if (sum_delta == 0) {
					mapTimeout = setTimeout(function () {
							lastScrollPositionX=event.pageX;
							lastScrollPositionY=event.pageY;
							mousewheelZoom();	
						}, 
						100);
				}
				sum_delta = sum_delta + (delta);
				var currentTime = new Date();
				lastTimestamp = currentTime.getTime();
				
				return false;
			});
		}
	});
}

function mousewheelZoom () {
	var currentTime = new Date();

	if (currentTime.getTime() - lastTimestamp > 200) {
				
		var ind = parent.getMapObjIndexByName('mapframe1');			
		var pos = parent.makeClickPos2RealWorldPos("mapframe1", lastScrollPositionX, lastScrollPositionY);
				
		if (sum_delta > 0) {
			parent.zoom("mapframe1", true, Math.pow(parent.Mapbender.zoomMousewheel, sum_delta), pos[0],pos[1]);
		}
		else {
			parent.zoom("mapframe1", false, Math.pow(parent.Mapbender.zoomMousewheel, -sum_delta), pos[0], pos[1]);
		}
		
		var newPosX =  parent.parent.mb_mapObj[ind].width - lastScrollPositionX;
		var newPosY =  parent.parent.mb_mapObj[ind].height - lastScrollPositionY;
				
		var posAfterZoom = parent.makeClickPos2RealWorldPos("mapframe1", newPosX, newPosY);
		parent.zoom('mapframe1', false, 1.0, posAfterZoom[0], posAfterZoom[1]); 
		
		sum_delta = 0;
		clearTimeout(mapTimeout);
	}
	else {
		mapTimeout = setTimeout(function () {
				mousewheelZoom(sum_delta);	
			}, 
			100);
	}
}
// -->
</script>
</head>
<body leftmargin='0' topmargin='0' onload="init()" bgcolor='#ffffff'>
<div id='mapframe1' name='mapframe1' style ='position: absolute; left: 0px; top: 0px; width: 0px; height: 0px; z-index:2;'>
<div id='markResult' name='maps' style ='position: absolute; left: 0px; top: 0px; width: 0px; height: 0px; z-index:26'> </div>
<div id='mapframe1_maps' name='maps' style ='position: absolute; left: 0px; top: 0px; width: 0px; height: 0px; z-index:2;'> </div>
<div id='highlight' style="position:absolute;top:-10px;left:-10px;width:14px;height:14px;z-index:3;visibility:visible"><img src="../img/redball.gif"/></div>
<div id='l_right' name='l_right' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:10;visibility:hidden;background-color:#ff0000;cursor: crosshair;"></div>
<div id='l_bottom'  name='l_bottom' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:11;visibility:hidden;background-color:#ff0000;cursor: crosshair;"></div>
<div id='l_left' name='l_left' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:12;visibility:hidden;background-color:#ff0000;cursor: crosshair;"></div>
<div id='l_top' name='l_top' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:13;visibility:hidden;background-color:#ff0000;cursor: crosshair;"></div>
<div id="sandclock" style="position:absolute; top:0px; left:0px; z-index:14;"></div>
<div id="scalebar" style="position:absolute; top:0px; left:0px; z-index:15;"></div>
<div id="measuring" style="position:absolute; top:0px; left:0px; z-index:16; font-size:10px"></div>
<div id="measure_display" style="position:absolute; top:0px; left:0px; z-index:17;"></div>
<div id="copyright" style="position:absolute; top:0px; left:0px; z-index:18;"></div>
<div id="measure_sub" style="position:absolute; top:0px; left:0px; z-index:19;"></div>
<div id='permanent' style="position:absolute;top:-10px;left:-10px;width:14px;height:14px;z-index:13;visibility:hidden"><img src="../img/redball.gif"/></div>
<div id="digitize_sub" style="position:absolute; top:0px; left:0px; z-index:24;"></div>
<div id="digitize_display" style="position:absolute; top:0px; left:0px; z-index:25;"></div>
<div id='um_title' name='um_title' style="font-family: Arial, Helvetica, sans-serif; DISPLAY:none; OVERFLOW:visible; POSITION:absolute; DISPLAY:none; BACKGROUND:#BEC1C4;border:1px solid black; z-index:98;"></div>
<div id='um_draw' name='um_draw' style="LEFT:0px;OVERFLOW:visible;POSITION:absolute;TOP:0px;z-index:99;"></div>
<img id='um_img' name='um_img' style ='position: absolute; left: 0px; top: 0px; width: 0px; height: 0px; border:0;z-index:100' src='../img/transparent.gif' useMap='#um'>
<map name='um' id='um'></map>
</div>
</body>
</html>
