<?php
# $Id: mod_editGuiWmsMeta.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_editGuiWmsMeta.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

import_request_variables("PG");
include(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Edit WMS Meta Data</title>
<?php
include '../include/dyn_css.php';
?>
<style type="text/css">
   <!--
   body{
      background-color: #ffffff;
      font-family: Arial, Helvetica, sans-serif;
      font-size : 12px;
      color: #808080
   }
   .guiList1{
   	position:absolute;
   	top:30px;
   	left:10px;
   	width:200px
   }
   .buttonbar{
   	position:absolute;
   	top:40px;
   	left:10px;
   }
   .guiList1_text{
   	position:absolute;
   	top:10px;
   	left:10px;
      font-size:16px;
      color: #0066cc;
   }
   .guiList2{
   	position:absolute;
   	top:40px;
   	left:400px;
   	width:200px
   }
   .all{
   	position:absolute;
   	top:38px;
   	left:610px;
   }
   .guiList2_header{
   	position:absolute;
   	top:10px;
   	left:400px;
      font-size:16px;
      color: #0066cc;
   }
   .myElements{
   	position:absolute;
   	top:70px;
   	left:400px;
   }
   .myTable{
   	border: 1px solid;
      font-size: 11px;
   }
   .myForm{
   	position:absolute;
   	top:70px;
   	left:10px;
   }
   .textfield{
      width:277px
   }
   .textfield_small{
      width:150px
   }
   .on{
      color: #0066cc;
   }
   -->
</style>

<script type="text/javascript">
<!--
   function windowSize() {
      window.resizeTo(800,500)
      window.moveTo(130,200)
   }

   function windowQuit() {
      window.close()
   }
// -->
</script>

   </head>
   <body onload='windowSize()'>

<?php
   echo "      <form name='editMetaData' action='".$self."' method='get'>\n";

   $layer_id   = $_REQUEST["layer_id"];
   
   if ( isset($_REQUEST["function"] ) ) {
      $function = $_REQUEST["function"];
      
      if ( $function = "update" ) {
         $sql = "UPDATE layer SET layer_meta_datum = $1, ";
         $sql.= "layer_meta_lieferant = $2, ";
         $sql.= "layer_meta_quelle = $3, ";
         $sql.= "layer_meta_ansprechpartner = $4, ";
         $sql.= "layer_meta_lieferant_basis = $5, ";
         $sql.= "layer_meta_copyright = $6 ";
         $sql.= " WHERE layer_id = $7;";
         $v = array($_REQUEST["layer_meta_datum"], $_REQUEST["layer_meta_lieferant"], $_REQUEST["layer_meta_quelle"], $_REQUEST["layer_meta_ansprechpartner"], $_REQUEST["layer_meta_lieferant_basis"], $_REQUEST["layer_meta_copyright"], $layer_id);
         $t = array("s", "s", "s", "s", "s", "s", "i");
         $res = db_prep_query($sql, $v, $t);
      }
   }
   
   $sql = "SELECT * FROM layer WHERE layer_id = $1;";
   $v = array($layer_id);
   $t = array("i");
   $res = db_prep_query($sql, $v, $t);
   
   if ( db_fetch_row($res, 0) ) { 	
   	  echo "         <h3>Editieren von Metadaten</h3>\n";  
      echo "         <table class='myTable' border='1' cellpadding='2'>\n";
      echo "            <tr>\n";
      echo "               <td >Aktualisierungsdatum</td>\n";
      echo "               <td><input name='layer_meta_datum' type='text' size='100' value='".db_result($res, 0, "layer_meta_datum")."'></td>\n";
      echo "            </tr>\n";
      echo "            <tr>\n";
      echo "               <td>Datenlieferant</td>\n";
      echo "               <td><input name='layer_meta_lieferant' type='text' size='100' value='".db_result($res, 0, "layer_meta_lieferant")."'></td>\n";
      echo "            </tr>\n";
      echo "            <tr>\n";
      echo "               <td>Datenquelle</td>\n";
      echo "               <td><input name='layer_meta_quelle' type='text' size='100' value='".db_result($res, 0, "layer_meta_quelle")."'></td>\n";
      echo "            </tr>\n";
      echo "            <tr>\n";
      echo "               <td>Ansprechpartner</td>\n";
      echo "               <td><input name='layer_meta_ansprechpartner' type='text' size='100' value='".db_result($res, 0, "layer_meta_ansprechpartner")."'></td>\n";
      echo "            </tr>\n";
      echo "            <tr>\n";
      echo "               <td>Datenlieferant (Basisdaten)</td>\n";
      echo "               <td><input name='layer_meta_lieferant_basis' type='text' size='100' value='".db_result($res, 0, "layer_meta_lieferant_basis")."'></td>\n";
      echo "            </tr>\n";
      echo "            <tr>\n";
      echo "               <td>Copyright</td>\n";
      echo "               <td><input name='layer_meta_copyright' type='text' size='100' value='".db_result($res, 0, "layer_meta_copyright")."'></td>\n";
      echo "            </tr>\n";
      echo "         </table>\n";
   }
   echo "         <p></p>\n";
   echo "         <input type='submit' name='function' value='update'>\n";
   echo "         <input type='button' onclick='windowQuit()' value='   exit   '>\n";
   echo "         <input type='hidden' name='layer_id' value='".$layer_id."'>\n";
?>
      </form>
   </body>
</html>