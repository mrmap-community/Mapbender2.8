<?php
# $Id: mod_mapOV.php 3223 2008-11-12 08:48:37Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");

if(isset($_REQUEST["wms"])){
	$rank = $_REQUEST["wms"];
}
else{
	$rank = 0;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>mod_mapOV0.php</title>
<?php
include '../include/dyn_css.php';
?>
<?php
$gui_id = $_SESSION["mb_user_gui"];
$sql = "SELECT e_width,e_height, e_target FROM gui_element WHERE e_id = 'overview' AND fkey_gui_id = $1";
$v = array($gui_id);
$t = array("s");
$res = db_prep_query($sql, $v, $t);
$cnt = 0;
echo "<script type='text/javascript'>";
while($row = db_fetch_array($res)){ 
   echo "var mod_overview_width = " . $row["e_width"].";";
   echo "var mod_overview_height = " . $row["e_height"].";";
   echo "var mod_overview_target = '" . $row["e_target"]."';";
   $cnt++;
}
echo "var mod_overview_rank = ".$rank.";";
if($cnt > 1){ echo "alert('overview: ID not unique!');";}
echo "</script>";
?>
<script type="text/javascript">
<!--

function init () {
	parent.eventInitMap.register(function init_mod_mapOV(){
		parent.mb_registerMapObj('overview', 'overview', mod_overview_rank, mod_overview_width, mod_overview_height);
		document.onmouseover = mod_ov_setHandler;
		document.onmousedown = parent.mod_box_start;
		document.onmouseup = mod_ov_getExtent;
		document.onmousemove = parent.mod_box_run;
		
		var ind = parent.getMapObjIndexByName('overview');
		var ov_extent = parent.mb_mapObj[ind].getExtentInfos();
		parent.mb_mapObj[ind].isOverview = true;
	});
}
function mod_ov_setHandler(e){
   parent.mb_isBF = "overview";
   parent.mb_zF = mod_overview_target;
}
function mod_ov_getExtent(e){
	mod_ov_setValidClipping(parent.mod_box_stop(e));
}
parent.mb_registerSubFunctions("window.frames['overview'].mod_ov_showMapExtent()");
function mod_ov_showMapExtent(){
	for(var i=0; i<parent.mb_mapObj.length; i++){
		if(parent.mb_mapObj[i].frameName == mod_overview_target){
			var arrayBBox = parent.mb_mapObj[i].extent.split(",");
			var minX = parseFloat(arrayBBox[0]);
			var minY = parseFloat(arrayBBox[1]);
			var maxX = parseFloat(arrayBBox[2]);
			var maxY = parseFloat(arrayBBox[3]);
			var ind = parent.getMapObjIndexByName(mod_overview_target);
			var pointMin = parent.mb_mapObj[ind].convertRealToPixel(new parent.Point(minX, maxY)); 
			var pointMax = parent.mb_mapObj[ind].convertRealToPixel(new parent.Point(maxX, minY)); 
			var px1 = pointMin.x;
			var py1 = pointMin.y;
			var px2 = pointMax.x;
			var py2 = pointMax.y;

		parent.mb_isBF = "overview";
		parent.mb_zF = mod_overview_target;
		while((px2 - px1) < 8){
			px1 -= 1;
			px2 += 1;
		}
		while((py2 - py1) < 8){
			py1 -= 1;
			py2 += 1;
		}
		if(px1 < 0){px1 = 1;}
		if(px1 > mod_overview_width){px1 = mod_overview_width-1;}

		if(py1 < 0){py1 = 1;}
		if(py1 > mod_overview_height){py1 = mod_overview_height-1;}

		if(px2 > mod_overview_width){px2 = mod_overview_width-1;}
		if(px2 < 0){px2 = 1;}

		if(py2 > mod_overview_height){py2 = mod_overview_height-1;}
		if(py2 < 0){py2 = 1;}

		parent.mb_drawBox(px1,py1,px2,py2);
		}
	}
}
function mod_ov_setValidClipping(coords){
	if(coords.length > 2){
		parent.mb_calculateExtent(parent.mb_zF,coords[0],coords[1],coords[2],coords[3]);
		parent.setMapRequest(parent.mb_zF);
	}
	else{
		parent.zoom(parent.mb_zF,true,1.0,coords[0], coords[1]);
	}
}
// -->
</script>
</head>
<body leftmargin='0' topmargin='0' onload="init()"  bgcolor='#ffffff'>
<div id='overview' name='overview' style =' position:absolute;left:0px;top:0px;width:0px;height:0px;' >
<div id='overview_maps' name='maps' style =' position:absolute;left:0px;top:0px;width:0px;height:0px;' ></div>
<div id='l_top' name='l_top' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:11;visibility:hidden;background-color:red;cursor: crosshair;"></div>
<div id='l_right' name='l_right' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:12;visibility:hidden;background-color:red;cursor: crosshair;"></div>
<div id='l_bottom'  name='l_bottom' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:13;visibility:hidden;background-color:red;cursor: crosshair;"></div>
<div id='l_left' name='l_left' style="position:absolute;top:0px;left:0px;width:0px;height:0px;overflow:hidden;z-index:14;visibility:hidden;background-color:red;cursor: crosshair;"></div>
<div id='highlight' style="position:absolute;top:-10px;left:-10px;width:14px;height:14px;z-index:3;visibility:visible"><img src="../img/redball.gif" width="14" height="14" /></div>
</div>
</body>
</html>
