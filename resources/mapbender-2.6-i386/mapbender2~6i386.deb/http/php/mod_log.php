<?php
# $Id: mod_log.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/Administration
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
require(dirname(__FILE__)."/../include/dyn_php.php");

if($_REQUEST['req']){
	ignore_user_abort();
	$req = array();
	$req[0] = urldecode($_REQUEST['req']);
	$time_client = $_REQUEST['time_client'];
	
	if(empty($req)){$req = "init";}
	include(dirname(__FILE__)."/../classes/class_log.php");
	$log = new log("default", $req, $time_client, $logtype);
}
echo "log into $logtype successful!";
?>