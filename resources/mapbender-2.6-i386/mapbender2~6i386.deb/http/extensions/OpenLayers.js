
Fatal error: Allowed memory size of 33554432 bytes exhausted (tried to allocate 35 bytes) in /home/cbaudson/workspace/build/jsmin-1.1.0.php on line 79
