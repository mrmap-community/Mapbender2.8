<?PHP
# $Id: markResult.php 2411 2008-04-23 16:09:45Z christoph $
# http://www.mapbender.org/index.php/markResult.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

/*
* following parameters are required:
* $width, $height ->  dimensions of the image
* $color -> Color of the polygon/line, commasaparated RGB-values
*
*/

import_request_variables("PG");
require(dirname(__FILE__)."/../php/mb_validateSession.php");
$tmpx = array();
$tmpy = array();
$x = array();
$y = array();
$tmpx = explode(":", $_REQUEST["x"]);
$tmpy = explode(":", $_REQUEST["y"]);
for($i=0; $i<count($tmpx); $i++){
	$x[$i] = array();
	$y[$i] = array();
	$x[$i] = explode(",",$tmpx[$i]);
	$y[$i] = explode(",",$tmpy[$i]);	
}

if(!$_REQUEST["color"]){ $color = "255,0,0"; }
$myCol = mb_split(",", $color);

$image = imagecreate($width,$height);

$transparent = ImageColorAllocate($image,155,155,155); 
ImageFilledRectangle($image,0,0,$width,$height,$transparent); 
ImageColorTransparent ($image , $transparent);

  
$red = imagecolorallocate($image,$myCol[0],$myCol[1],$myCol[2]); 
for($j=0; $j<count($x); $j++){
	for($i=0; $i < (count($x[$j])-1); $i++){
		imageline($image,$x[$j][$i],$y[$j][$i],$x[$j][$i+1],$y[$j][$i+1],$red);
		imageline($image,$x[$j][$i]+1,$y[$j][$i],$x[$j][$i+1]+1,$y[$j][$i+1],$red);
		imageline($image,$x[$j][$i]-1,$y[$j][$i],$x[$j][$i+1]-1,$y[$j][$i+1],$red);
		imageline($image,$x[$j][$i],$y[$j][$i]+1,$x[$j][$i+1],$y[$j][$i+1]+1,$red);
		imageline($image,$x[$j][$i],$y[$j][$i]-1,$x[$j][$i+1],$y[$j][$i+1]-1,$red);	
	} 
}
header("Content-Type: image/png"); 
imagepng($image); 
?>
