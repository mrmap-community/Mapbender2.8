<?php
# $Id: class_bbox.php 1965 2008-01-15 08:24:29Z christoph $
# http://www.mapbender.org/index.php/
# Copyright (C) 2002 CCGIS
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../../core/globalSettings.php");

define("ELEMENT_PATTERN", "/sessionID/");

class Element {
	
	var $guiId;
	var $id;
	var $pos;
	var $isPublic;
	var $comment;
	var $title;
	var $element;
	var $src;
	var $attributes;
	var $left;
	var $top;
	var $width;
	var $height;
	var $zIndex;
	var $moreStyles;
	var $content;
	var $closeTag;
	var $jsFile;
	var $mbMod;
	var $target;
	var $requires;
	var $helpUrl;
	var $isBodyAndUsesSplashScreen = false;
	
	public function __contruct() {
		
	}
	
	public function select ($id, $applicationId) {
		$sql = "SELECT fkey_gui_id, e_id, e_pos, e_public, e_comment, e_public, ".
				"gettext($1, e_title) as e_title, e_element, e_src, e_attributes, " .
				"e_left, e_top, e_width, e_height, e_z_index, e_more_styles, " .
				"e_content, e_closetag, e_js_file, e_mb_mod, e_target, " .
				"e_requires, e_url FROM gui_element WHERE e_id = $2 AND " .
				"fkey_gui_id = $3 LIMIT 1";
		$v = array ($_SESSION["mb_lang"], $id, $applicationId);
		$t = array ("s", "s", "s");
		$res = db_prep_query($sql, $v, $t);
		$row = db_fetch_array($res);
		if ($row) {
			$this->guiId = $applicationId;
			$this->id = $row["e_id"];
			$this->pos = $row["e_pos"];
			$this->isPublic = $row["e_public"];
			$this->comment = $row["e_comment"];
			$this->title = $row["e_title"];
			$this->element = $row["e_element"];
			$this->src = $row["e_src"];
			$this->attributes = $row["e_attributes"];
			$this->left = $row["e_left"];
			$this->top = $row["e_top"];
			$this->width = $row["e_width"];
			$this->height = $row["e_height"];
			$this->zIndex = $row["e_z_index"];
			$this->moreStyles = $row["e_more_styles"];
			$this->content = $row["e_content"];
			$this->closeTag = $row["e_closetag"];
			$this->jsFile = $row["e_js_file"];
			$this->mbMod = $row["e_mb_mod"];
			$this->target = $row["e_target"];
			$this->requires = $row["e_requires"];
			$this->helpUrl = $row["e_url"];
			return true;
		}
		return false;		
	}
	
	public function __toString () {
		return $this->toHtml();
	}
	
	public function getJavaScriptModules () {
		$jsArray = array();
		if ($this->mbMod != "") {
			$moduleArray = explode(",", $this->mbMod);
			for ($i = 0; $i < count($moduleArray); $i++) {
				$currentFile = dirname(__FILE__) . "/../javascripts/" . trim($moduleArray[$i]);
				if (file_exists($currentFile)) {
					array_push($jsArray, $currentFile);
				}
				else {
					$e = new mb_exception("Javascript module not found: " . $currentFile);
				}
			}
		}
		return $jsArray;
	}
	
	public function toHtmlArray () {
		if ($this->isPublic) {
			return array($this->getHtmlOpenTag(), $this->getHtmlContent(), $this->getHtmlCloseTag());	
		}
		return array("", "", "");
	}
	
	public function toHtml () {
		if ($this->isPublic) {
			return implode("", $this->toHtmlArray());
		}
		return "";
	}

	private function getHtmlOpenTag () {
		$openTag = "";
		
		if (!$this->element) {
			return "";
		}
	
		if ($this->id) {
			// tag name
			$openTag .= "<" . $this->element . " ";
			
			// id and name
			$openTag .= "id='" . $this->id . "' name='" . $this->id . "' ";
			
			// attributes
			if ($this->attributes) {
				$openTag .= stripslashes($this->replaceSessionStringByUrlParameters($this->attributes)) . " ";
			}
			
			// title
			if ($this->title) {
				$openTag .= "title='" . $this->title . "' ";
			}
			
			// src
			if ($this->src) {
   				$openTag .= "src = '" . $this->replaceSessionStringByUrlParameters($this->src);

				// for iframes which are not "loadData", 
				// add additional parameters
				if ($this->closeTag == "iframe" && $this->id != "loadData") {
					if(mb_strpos($this->src, "?")) {
						$openTag .= "&";
					}
					else {
	      				$openTag .= "?";
      				}
	      			$openTag .= "e_id_css=" . $this->id . "&" .
	      					 "e_id=" . $this->id . "&" .
	      					 "e_target=" . $this->target . "&" .
	      					 $this->getUrlParameters();
				}
   				$openTag .= "' ";
			}
			
			// style
			$openTag .= " style = '";
			if ($this->top != "" && $this->left != "") {
				$openTag .= "position:absolute;" .
						 "left:" . $this->left . ";" .
						 "top:" . $this->top . ";";
			}
			if ($this->width != "" && $this->height != "") {
				$openTag .= "width:" . $this->width . ";" .
						 "height:" . $this->height . ";";
			}
			if ($this->zIndex) {
		    	$openTag .= "z-index:" . $this->zIndex . ";";
			}
			if ($this->moreStyles) {
		    	$openTag .= $this->moreStyles;
			}
			$openTag .= "'>";

			if ($this->element == "body") {
				$e_id = "body";
				$gui_id = $this->guiId;
				include(dirname(__FILE__)."/../include/dyn_php.php");
				
				$splashScreen = "";
				
				if ($use_load_message) {
					$this->isBodyAndUsesSplashScreen = true;
					if (isset($htmlWhileLoading) && $htmlWhileLoading != '') {
						$splashScreen .= $htmlWhileLoading; 
					} elseif (isset($includeWhileLoading) && $includeWhileLoading != '' && file_exists(dirname(__FILE__)."/".$includeWhileLoading)) { 
						ob_start();
						include(dirname(__FILE__)."/".$includeWhileLoading);
						$splashScreen .= ob_get_contents();
						ob_end_clean();
					}
					else {
						$splashScreen .= "<img src='../img/indicator_wheel.gif'>&nbsp;" . 
							"<b>Ma<font color='#0000CE'>p</font><font color='#C00000'>b</font>ender " . 
							MB_VERSION_NUMBER . " " . strtolower(MB_VERSION_APPENDIX) . "</b>..." .
							"loading application '" . $this->guiId . "'";
					}
				}	
				$openTag .= "<div id='loading_mapbender' " .
								"style='margin:0px;padding:0px;width:100%;height:100%;'>" . 
								$splashScreen . "</div>" . 
								"<div id='complete_mapbender' " .
								"style='display:none'>";
				unset ($e_id, $gui_id);
			}
		}
		return $openTag;
	}
	
	private function getHtmlContent () {
		$htmlContent = "";
		if ($this->content != "" && $this->element) {
			$htmlContent .= stripslashes($this->content);
		}
		return $htmlContent;
	}
	
	private function getHtmlCloseTag () {
		if ($this->element == "body" && $this->isBodyAndUsesSplashScreen) {
			return "</div></body>";
		}
		if ($this->closeTag != "") {
			return "</" . $this->closeTag . ">";
		}
		return "";
	}
	
	private function getUrlParameters () {
		$urlParameters = SID;
		if (isset($this->guiId)) {
			$urlParameters .= "&guiID=" . $this->guiId;
		}
		if (isset($this->id)) {
			$urlParameters .= "&elementID=" . $this->id;
		}
		return $urlParameters;
	}
	
	private function replaceSessionStringByUrlParameters ($string) {
		$urlParameters = $this->getUrlParameters();
		return preg_replace(ELEMENT_PATTERN, $urlParameters, $string);
	}
	
}


?>
