<?php
# $Id: class_log.php 2684 2008-07-22 07:26:19Z christoph $
# http://www.mapbender.org/index.php/class_log.php
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

/*
* class exception
*	 [15/Jul/2004:	 10:00:08 +0200] 192.168.2.102 urldecode(username) userid
*modul "GET /map/http/ HTTP/1.1"
*/
require_once(dirname(__FILE__)."/../../core/globalSettings.php");

class log {
	var $dir = "../../log/";
	var $log_username = true;

	var $url = array();
	/*
	 * {'file' || 'db'}
	 */
	var $logtype = 'db';
	
	function log($module,$req,$time_client,$type = ""){

		$this->url = $req;
		if($type == "")
			$type = $this->logtype;

		if($type == "file"){
			if(is_dir($this->dir)){
				$logfile = $this->dir . "mb_access_" . date("Y_m_d") . ".log";
				if(!$h = @fopen($logfile,"a")){
					#exit;
				}
				else{
					for($i = 0; $i < count($this->url); $i++){
						$content = strtotime("now")." ";
						$content .= "[".date("d/M/Y:H:i:s O")."]";
						$content .= " " . $_SESSION["mb_user_ip"];
						$content .= ' "';
						if($this->log_username == true){
							$content .= $_SESSION["mb_user_name"];
						}
						$content .= '"';
						$content .= " " . $_SESSION["mb_user_id"];
						$content .= " " . $module;
						$content .= ' "' . $this->url[$i] . '"';
						$content .= chr(13).chr(10);
						if(!fwrite($h,$content)){
							#exit;
						}
					}
					fclose($h);
				}
			}
		}
		else if($type == 'db'){


			include_once(dirname(__FILE__)."/../../conf/mapbender.conf");
			$con = db_connect(DBSERVER,OWNER,PW);
			db_select_db(DB,$con);
			for($i = 0; $i < count($this->url); $i++){
				$sql = "INSERT INTO mb_log (";
				$sql .= "time_client, time_server, time_readable, mb_session, ";
				$sql .= "gui, module, ip, username, userid, request";
				$sql .= ") VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)";

				$v = array($time_client, strtotime("now"), "[".date("d/M/Y:H:i:s O")."]", SID, $_SESSION["mb_user_gui"], $module, $_SESSION["mb_user_ip"], $_SESSION["mb_user_name"], $_SESSION["mb_user_id"], $this->url[$i]);
				$t = array("s", "s", "s", "s", "s", "s", "s", "s", "s", "s");
				$res = db_prep_query($sql, $v, $t)or die(db_error());

				if(!$res){
					include_once(dirname(__FILE__)."/class_mb_exception.php");
					$e = new mb_exception("class_log: Writing table mb_log failed.");
				}
			}
		}
	}
}
?>
