<?php
# $Id: class_wmc.php 3877 2009-04-15 11:42:00Z christoph $
# http://www.mapbender.org/index.php/class_wmc.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__) . "/../classes/class_wms.php");
require_once(dirname(__FILE__) . "/../classes/class_layer_monitor.php");
require_once(dirname(__FILE__) . "/../classes/class_point.php");
require_once(dirname(__FILE__) . "/../classes/class_bbox.php");
require_once(dirname(__FILE__) . "/../classes/class_json.php");
require_once(dirname(__FILE__) . "/../classes/class_map.php");
require_once(dirname(__FILE__) . "/../classes/class_administration.php");
require_once(dirname(__FILE__) . "/../classes/class_wmcToXml.php");

/**
 * Implementation of a Web Map Context Document, WMC 1.1.0
 * 
 * Use cases:
 * 
 * Instantiation (1) create a WMC object from a WMC XML document
 * 		$myWmc = new wmc();
 * 		$myWmc->createFromXml($xml);
 * 
 *    If you want to create a WMC object from a WMC in the database
 *    	$xml = wmc::getDocument($wmcId);
 * 		$myWmc = new wmc();
 * 		$myWmc->createFromXml($xml);
 *    
 * 
 * Instantiation (2) create a WMC from the client side
 * 		$myWmc = new wmc();
 * 		$myWmc->createFromJs($mapObject, $generalTitle, $extensionData);
 * 	
 * 	  	(creates a WMC from the JS data and then creates an object from that WMC)
 * 
 * Output (1) (do Instantiation first) Load a WMC into client
 * 		This will return an array of JS statements
 *  
 * 		$myWmc->toJavaScript();
 * 
 * Output (2) (do Instantiation first) Merge with another WMC, then load
 * 	
 * 		$myWmc->merge($anotherWmcXml);
 * 		$myWmc->toJavaScript();
 * 
 */
class wmc {
	/**
	 * Representing the main map in a map application
	 * @var Map
	 */
	var $mainMap;

	/**
	 * Representing an (optional) overview map in a map application
	 * @var Map
	 */
	var $overviewMap;

	/**
	 * @var Array
	 */
	var $generalExtensionArray = array();

	/**
	 * The XML representation of this WMC.
	 * @var String
	 */
	var $xml;
	
	// constants
	var $monitoringIsOn = false;
	var $saveWmcAsFile = false;
	var $extensionNamespace = "mapbender";
	var $extensionNamespaceUrl = "http://www.mapbender.org/context";
		
	// set in constructor
	var $wmc_id;
	var $userId;

	// set during parsing
	var $wmc_version;
	var $wmc_name;
	var $wmc_title;
	var $wmc_abstract;
	var $wmc_keyword = array();
	var $wmc_contactposition;
	var $wmc_contactvoicetelephone;
	var $wmc_contactemail;
	var $wmc_contactfacsimiletelephone;
	var $wmc_contactperson;
	var $wmc_contactorganization;
	var $wmc_contactaddresstype;
	var $wmc_contactaddress;
	var $wmc_contactcity;
	var $wmc_contactstateorprovince;
	var $wmc_contactpostcode;
	var $wmc_contactcountry;
	var $wmc_logourl;
	var $wmc_logourl_format;
	var $wmc_logourl_type;
	var $wmc_logourl_width;
	var $wmc_logourl_height;
	var $wmc_descriptionurl;
	var $wmc_descriptionurl_format;
	var $wmc_descriptionurl_type;

	public function __construct () {
		$this->userId = $_SESSION["mb_user_id"];
		$this->wmc_id = time();
	} 
	
	// ---------------------------------------------------------------------------
	// INSTANTIATION
	// ---------------------------------------------------------------------------

	/**
	 * Parses the XML string and instantiates the WMC object.
	 * 
	 * @param $xml String
	 */
	public function createFromXml ($xml) {
		return $this->createObjFromWMC_xml($xml);
	}

	/**
	 * Loads a WMC from the database.
	 * 
	 * @param integer $wmc_id the ID of the WMC document in the database table "mb_user_wmc"
	 */
	function createFromDb($wmcId){
		$this->monitoringIsOn = true;
		
		$doc = wmc::getDocument($wmcId);
		if ($doc === false) {
			return false;
		}
		$this->createObjFromWMC_xml($doc);
		return true;
	}

	public function createFromApplication ($appId) {
		// get the map objects "overview" and "mapframe1"
		$this->mainMap = map::selectMainMapByApplication($appId);
		$this->overviewMap = map::selectOverviewMapByApplication($appId);
		$this->createXml();
		$this->saveAsFile();
	}

	/**
	 * Creates a WMC object from a JS map object {@see map_obj.js}
	 * 
	 * @param object $mapObject a map object
	 * @param integer $user_id the ID of the current user
	 * @param string $generalTitle the desired title of the WMC
	 * @param object $extensionData data exclusive to Mapbender, which will be 
	 * 								mapped into the extension part of the WMC
	 */
	public function createFromJs($mapObject, $generalTitle, $extensionData) {
	
		if (count($mapObject) > 2) {
			$e = new mb_exception("Save WMC only works for two concurrent map frames (overview plus main) at the moment.");
		}
		
		// set extension data		
		$this->generalExtensionArray = $extensionData;

		// set title
		$this->wmc_title = $generalTitle;
		
		// create the map objects
		for ($i = 0; $i < count($mapObject); $i++) {
			$currentMap = new Map();
			$currentMap->createFromJs($mapObject[$i]);

			if (isset($mapObject[$i]->isOverview)) {
				$this->overviewMap = $currentMap;
			}
			else {
				$this->mainMap = $currentMap;
			}
		}

		
		// create XML
		$this->createXml();

		$this->saveAsFile();
		return true;
	}
	
	// ---------------------------------------------------------------------------
	// DATABASE FUNCTIONS
	// ---------------------------------------------------------------------------

	/**
	 * Stores this WMC in the database. The WMC has to be instantiated first, see above.
	 * 
	 * @return mixed[] an assoc array with attributes "success" (boolean) and "message" (String).
	 */
	public function insert () {
		$result = array();
		if ($this->userId && $this->xml && $this->wmc_title) {
			$sql = "INSERT INTO mb_user_wmc VALUES ($1, $2, $3, $4, $5)";
			$v = array($this->wmc_id, $this->userId, $this->xml, administration::convertOutgoingString($this->wmc_title), time());
			$t = array("s", "i", "s", "s", "s");
			
			$res = db_prep_query($sql, $v, $t);
			if (db_error()) {
				$errMsg = "Error while saving WMC document '" . $this->wmc_title . "': " . db_error();
				$result["success"] = false;
				$result["message"] = $errMsg;
				$e = new mb_exception("mod_insertWMCIntoDB: " . $errMsg);
			}
			else {
				$result["success"] = true;
				$msg = "WMC document '" . $this->wmc_title . "' has been saved.";
				$result["message"] = $msg;
				$e = new mb_notice("mod_insertWMCIntoDB: WMC  '" . $this->wmc_title . "' saved successfully.");
			}
		}
		else {
			$result["success"] = false;
			$errMsg = "missing parameters (user_id: ".$this->userId.", title: " . $this->wmc_title . ")";
			$result["message"] = $errMsg;
			$e = new mb_exception("mod_insertWMCIntoDB: " . $errMsg .")");
		}
		return $result;
	}
	
	/**
	 * deletes a {@link http://www.mapbender.org/index.php/WMC WMC} 
	 * entry specified by wmc_id and user_id
	 *
	 * @param	integer		the user_id
	 * @param	string		the wmc_id
	 * @return	boolean		Did the query run successful?
	 */
	public static function delete ($wmcId, $userId) {
		if (!isset($userId) || $userId === null) {
			$userId = $_SESSION["mb_user_id"];
		}
		
		$sql = "DELETE FROM mb_user_wmc ";
		$sql .= "WHERE fkey_user_id = $1 AND wmc_id = $2";
		$v = array($userId, $wmcId);
		$t = array('i', 's');
		$res = db_prep_query($sql, $v, $t);
		if ($res) {
			return true;
		}
		return false;
	}

	/**
	 * Returns a WMC document
	 * @return String|boolean The document if it exists; else false
	 * @param $id String the WMC id
	 */
	public static function getDocument ($id) {
		$sql = "SELECT wmc FROM mb_user_wmc WHERE wmc_id = $1 AND fkey_user_id = $2";
		$v = array($id, $_SESSION["mb_user_id"]);
		$t = array('s', 'i');
		$res = db_prep_query($sql,$v,$t);
		$row = db_fetch_array($res);
		if ($row) {
			return $row["wmc"];
		}
		return false;
	}

	// ---------------------------------------------------------------------------
	// GETTER FUNCTIONS
	// ---------------------------------------------------------------------------
	
	/**
	 * @return string the title of the WMC.
	 */
	public function getTitle() {
		return $this->wmc_title;
	}

	// ---------------------------------------------------------------------------
	// OUTPUT FUNCTIONS
	// ---------------------------------------------------------------------------
	
	/**
	 * Wrapper function, returns XML at the moment
	 * @return String
	 */
	public function __toString() {
		return $this->toXml();
	}

	/**
	 * Returns the XML document if available
	 * 
	 * @return String The XML document; if unavailable, null is returned.
	 */
	public function toXml () {
		if (!$this->xml) {
			$this->createXml();
		}
		return $this->xml;
	}

	/**
	 * Returns an array of JavaScript statements
	 * 
	 * @return String[]
	 */
	public function toJavaScript () {
/*
		// counts how often a layer has been loaded
		if ($this->monitoringIsOn) {
			$monitor = new Layer_load_count();
			for ($i = 0; $i < count($this->wmc_layer_id); $i++) {
				$monitor->increment($this->wmc_layer_id[$i]);
			}
		}
*/		
		// will contain the JS code to create the maps
		// representing the state stored in this WMC
		$wmcJsArray = array();
		
		// set general extension data
		if (count($this->generalExtensionArray) > 0) {
			$json = new Mapbender_JSON();
			array_push($wmcJsArray, "restoredWmcExtensionData = " . $json->encode($this->generalExtensionArray) . ";"); 
		}
		
		// reset WMS data
		array_push($wmcJsArray, "wms = [];");
		array_push($wmcJsArray, "wms_layer_count = 0;");

		// add WMS for main map frame
		$wmsArray = $this->mainMap->getWmsArray();

		// find the WMS in the main map which is equal to the WMS
		// in the overview map
		$overviewWmsIndex = null;
		$ovWmsArray = array();
		if ($this->overviewMap !== null) {
			$ovWmsArray = $this->overviewMap->getWmsArray();
			$overviewWmsIndex = 0;
			for ($i = 0; $i < count($ovWmsArray); $i++) {
				for ($j = 0; $j < count($wmsArray); $j++) {
					if ($ovWmsArray[$i]->equals($wmsArray[$j])) {
						$overviewWmsIndex = $j;	
						$wmsIndexOverview = $i;					
						break;
					}
				}
			}
		}

		// for all wms...
		for ($i = 0; $i < count($wmsArray); $i++) {
			array_push($wmcJsArray, $wmsArray[$i]->createJsObjFromWMS_());
		}

		// delete existing map objects...
		array_push($wmcJsArray, "mb_mapObj = [];");

		// .. and add the overview map (if exists) and set map request
		if ($this->overviewMap !== null) {
			$wmcJsArray = array_merge($wmcJsArray, $this->overviewMap->toJavaScript($overviewWmsIndex));
		}

		// .. and add main map ..
		$wmcJsArray = array_merge($wmcJsArray, $this->mainMap->toJavaScript(null));

		// set visibility of ov map WMS (may be different from main)
		if ($this->overviewMap !== null) {
			for ($i = 0; $i < count($ovWmsArray[$wmsIndexOverview]->objLayer); $i++) {
				$visStr = "mb_mapObj[0].wms[" .$wmsIndexOverview . "].handleLayer(" . 
					"'" . $ovWmsArray[$wmsIndexOverview]->objLayer[$i]->layer_name . "', " . 
					"'visible', " . 
					($ovWmsArray[$wmsIndexOverview]->objLayer[$i]->gui_layer_visible ? 1 : 0) . ");";
				array_push($wmcJsArray, $visStr);
			}
			array_push($wmcJsArray, "mb_mapObj[0].restateLayers(" . $ovWmsArray[$wmsIndexOverview]->wms_id . ");");
		}
		

		// .. request the map
		array_push($wmcJsArray, "setMapRequest('" . $this->mainMap->getFrameName() . "');");
		if ($this->overviewMap !== null) {
			array_push($wmcJsArray, "setMapRequest('" . $this->overviewMap->getFrameName() . "');");
		}

		array_push($wmcJsArray, "eventAfterLoadWMS.trigger();");
		return $wmcJsArray;
	}
	
	// ------------------------------------------------------------------------
	// manipulation
	// ------------------------------------------------------------------------
	/**
	 * Merges this WMC with another WMC.
	 * The settings of the other WMC overwrite the settings of this WMC.
	 * 
	 * @return void
	 * @param $xml2 Object
	 */
	public function merge ($xml2) {
		$someWmc = new wmc();
		$someWmc->createFromXml($xml2);

		$this->mainMap->merge($someWmc->mainMap);
		if (isset($this->overviewMap) && isset($someWmc->overviewMap)) {
			$this->overviewMap->merge($someWmc->overviewMap);
		}
	}

	/**
	 * Appends the layers of another WMC to this WMC.
	 * 
	 * @return void
	 * @param $xml2 Object
	 */
	public function append ($xml2) {
		$someWmc = new wmc();
		$someWmc->createFromXml($xml2);

		$this->mainMap->append($someWmc->mainMap);
		if (isset($this->overviewMap) && isset($someWmc->overviewMap)) {
			// There is only one WMS in the overview map; merge, not append
			$this->overviewMap->merge($someWmc->overviewMap);
		}
	}

	/**
	 * Adds a WMS to this WMC
	 * 
	 * @return 
	 */
	public function appendWmsArray ($wmsArray) {
		return $this->mainMap->appendWmsArray($wmsArray);
	}
	
	/**
	 * Merges a WMS into this WMC
	 * 
	 * @return 
	 */
	public function mergeWmsArray ($wmsArray) {
		$this->mainMap->mergeWmsArray($wmsArray);
	}

// ---------------------------------------------------------------------------
// private functions
// ---------------------------------------------------------------------------

	/**
	 * Loads a WMC from an actual WMC XML document.
	 * Uses WMS class.
	 * 
	 * @param string $data the data from the XML file
	 */
	private function createObjFromWMC_xml($data){
		// store xml 
		$this->xml = $data;
	
		$values = administration::parseXml($data);

		//
		// Local variables that indicate which section of the WMC
		// is currently parsed.
		//
		$extension = false;		$general = false;		$layerlist = false;
		$layer = false;  		$formatlist = false;	$dataurl = false;
		$metadataurl = false; 	$stylelist = false;

		//
		// reset WMC data
		//
		$this->mainMap = new Map();
		$this->overviewMap = null;
		$this->generalExtensionArray = array();
		
		$layerlistArray = array();
		$layerlistArray["main"] = array();
		$layerlistArray["overview"] = array();
			 
		foreach ($values as $element) {
			$tag = strtoupper(administration::sepNameSpace($element[tag]));
			$tagLowerCase = administration::sepNameSpace($element[tag]);
			$type = $element[type];
			$attributes = $element[attributes];
			$value = mb_utf8_decode(html_entity_decode($element[value]));
			
			if ($tag == "VIEWCONTEXT" && $type == "open") {
				$this->wmc_id = $attributes["id"];
				$this->wmc_version = $attributes["version"];
			}
			if ($tag == "GENERAL" && $type == "open") {
				$general = true;
			}
			if ($tag == "LAYERLIST" && $type == "open") {
				$layerlist = true;
			}
			if ($general) {
				if ($tag == "WINDOW") {
					$this->mainMap->setWidth($attributes["width"]);
					$this->mainMap->setHeight($attributes["height"]);
				}
				if ($tag == "BOUNDINGBOX") {
					$bbox = new Mapbender_bbox($attributes["minx"], $attributes["miny"], $attributes["maxx"], $attributes["maxy"], $attributes["SRS"]);
					$this->mainMap->setExtent($bbox);
				}
				if ($tag == "NAME") {
					$this->wmc_name = $value;
				}
				if ($tag == "TITLE") {
					$this->wmc_title = $value;
				}
				if ($tag == "ABSTRACT") {
					$this->wmc_abstract = $value;
				}
				if ($tag == "CONTACTINFORMATION" && $type == "open") {
					$contactinformation = true;
				}
				if ($contactinformation) {
					if ($tag == "CONTACTPOSITION") {
						$this->wmc_contactposition = $value;
					}
					if ($tag == "CONTACTVOICETELEPHONE") {
						$this->wmc_contactvoicetelephone = $value;
					}
					if ($tag == "CONTACTFACSIMILETELEPHONE") {
						$this->wmc_contactfacsimiletelephone = $value;
					}
					if ($tag == "CONTACTELECTRONICMAILADDRESS") {
						$this->wmc_contactemail = $value;
					}
					if ($tag == "CONTACTPERSONPRIMARY" && $type == "open") {
						$contactpersonprimary = true;
					}
					if ($contactpersonprimary) {
						if ($tag == "CONTACTPERSON") {
							$this->wmc_contactperson = $value;
						}
						if ($tag == "CONTACTORGANIZATION") {
							$this->wmc_contactorganization = $value;;
						}
						if ($tag == "CONTACTPERSONPRIMARY" && $type == "close") {
							$contactpersonprimary = false;
						}
					}
					if ($tag == "CONTACTADDRESS" && $type == "open") {
						$contactaddress = true;
					}
					if ($contactaddress) {
						if ($tag == "ADDRESSTYPE") {
							$this->wmc_contactaddresstype = $value;
						}
						if ($tag == "ADDRESS") {
							$this->wmc_contactaddress = $value;
						}
						if ($tag == "CITY") {
							$this->wmc_contactcity = $value;
						}
						if ($tag == "STATEORPROVINCE") {
							$this->wmc_contactstateorprovince = $value;
						}
						if ($tag == "POSTCODE"){
							$this->wmc_contactpostcode = $value;
						}
						if ($tag == "COUNTRY") {
							$this->wmc_contactcountry = $value;
						}
						if ($tag == "CONTACTADDRESS" && $type == "close") {
							$contactaddress = false;
						}
					}
				}
				if ($tag == "LOGOURL" && $type == "open") {
						$logourl = true;
						$this->wmc_logourl_width = $attributes["width"];
						$this->wmc_logourl_height = $attributes["height"];
						$this->wmc_logourl_format = $attributes["format"];
				}
				if ($logourl) {
					if ($tag == "LOGOURL" && $type == "close") {
						$logourl = false;
					}
					if ($tag == "ONLINERESOURCE") {
						$this->wmc_logourl_type = $attributes["xlink:type"];
						$this->wmc_logourl = $attributes["xlink:href"];
					}
				}
				if ($tag == "DESCRIPTIONURL" && $type == "open") {
						$descriptionurl = true;
						$this->wmc_descriptionurl_format = $attributes["format"];
				}
				if ($descriptionurl) {
					if ($tag == "DESCRIPTIONURL" && $type == "close"){
						$descriptionurl = false;
					}
					if ($tag == "ONLINERESOURCE") {
						$this->wmc_descriptionurl_type = $attributes["xlink:type"];
						$this->wmc_descriptionurl = $attributes["xlink:href"];
					}
				}
				if ($tag == "KEYWORDLIST" && $type == "open") {
					$keywordlist = true;
				}
				if ($keywordlist) {
					if ($tag == "KEYWORDLIST" && $type == "close") {
						$keywordlist = false;
						$cnt_keyword = -1;
					}
					if ($tag == "KEYWORD") {
						$cnt_keyword++;
						$this->wmc_keyword[$cnt_keyword] = $value;
					}
				}
				if ($tag == "EXTENSION" && $type == "close") {
					$generalExtension = false;
					//
					// After the general extension tag is closed,
					// we have all necessary information to CREATE
					// the map objects that are contained in this
					// WMC.
					//
					$this->setMapData();
				}
				if ($generalExtension) {
					if ($value !== "") {
						if (isset($this->generalExtensionArray[$tag])) {
							if (!is_array($this->generalExtensionArray[$tag])) {
								$firstValue = $this->generalExtensionArray[$tag];
								$this->generalExtensionArray[$tag] = array();
								array_push($this->generalExtensionArray[$tag], $firstValue);
							}	
							array_push($this->generalExtensionArray[$tag], $value);
						}
						else {
							$this->generalExtensionArray[$tag] = $value;									
						}
					}
				}
				if ($tag == "EXTENSION" && $type == "open") {
					$generalExtension = true;
				}
				if ($tag == "GENERAL" && $type == "close") {
		   			$general = false;
			 	}
			}
			if ($layerlist) {
				if ($tag == "LAYERLIST" && $type == "close") {
				   $layerlist = false;
				}
				if ($tag == "LAYER" && $type == "open") {
					//
					// The associative array currentLayer holds all 
					// data of the currently processed layer.
					// The data will be set in the classes' WMS
					// object when the layer tag is closed.
					//
					$currentLayer = array();
					
					$currentLayer["queryable"] = $attributes["queryable"];
					if ($attributes["hidden"] == "1") {
						$currentLayer["visible"] = 0;
					}
					else {
						$currentLayer["visible"] = 1;
					}
					$currentLayer["format"] = array();
					$currentLayer["style"] = array();
					$layer = true;
				}
				if ($layer) {
					if ($tag == "LAYER" && $type == "close") {

						//
						// After a layer tag is closed,
						// we have all necessary information to CREATE
						// a layer object and append it to the WMS object
						//
						if (isset($currentLayer["extension"]["OVERVIEWHIDDEN"])) {
							array_push($layerlistArray["overview"], $currentLayer);		
						}
						$modifiedLayer = $currentLayer;
						unset($modifiedLayer["extension"]["OVERVIEWHIDDEN"]);
						array_push($layerlistArray["main"], $modifiedLayer);											
				 		$layer = false;
					}
					if ($formatlist) {
						if ($tag == "FORMAT") {
						 	array_push($currentLayer["format"], array("current" => $attributes["current"], "name" => $value));
							if ($attributes["current"] == "1") {
								$currentLayer["formatIndex"] = count($currentLayer["format"]) - 1;
							}
						 }
						 if ($tag == "FORMATLIST" && $type == "close") {
							 $formatlist = false;
						 }
					 }
					 elseif ($metadataurl) {
						if ($tag == "ONLINERESOURCE") {
							$currentLayer["metadataurl"] = $attributes["xlink:href"];
						}
						if ($tag == "METADATAURL" && $type == "close") {
							$metadataurl = false;
						}
					 }
					 elseif ($dataurl) {
						if ($tag == "ONLINERESOURCE") {
						 	$currentLayer["dataurl"] = $attributes["xlink:href"];
						}
						 if ($tag == "DATAURL" && $type == "close") {
							$dataurl = false;
						 }
					 }
					 elseif ($stylelist) {
						if ($style) {
							$index = count($currentLayer["style"]) - 1;
							if ($tag == "STYLE" && $type == "close") {
								$style = false;
							}
							if ($tag == "SLD" && $type == "open") {
								$sld = true;
							}
							if ($sld) {
								if ($tag == "SLD" && $type == "close") {
									$sld = false;
								}
								if ($tag == "ONLINERESOURCE") {
									$currentLayer["style"][$index]["sld_type"] = $attributes["xlink:type"];
									$currentLayer["style"][$index]["sld_url"] = $attributes["xlink:href"];
								}
								if ($tag == "TITLE") {
									$currentLayer["style"][$index]["sld_title"] = $value;
								}
							}
							else {
								if ($tag == "NAME"){
									$currentLayer["style"][$index]["name"] = $value ? $value : "default";
								}
								if ($tag == "TITLE") {
									$currentLayer["style"][$index]["title"] = $value ? $value : "default";
								}
								if ($legendurl) {
									if ($tag == "LEGENDURL" && $type == "close") {
										$legendurl = false;
									}
									if ($tag == "ONLINERESOURCE") {
									 	$currentLayer["style"][$index]["legendurl_type"] = $attributes["xlink:type"];
									 	$currentLayer["style"][$index]["legendurl"] = $attributes["xlink:href"];
									}
								}
								if ($tag == "LEGENDURL" && $type == "open") {
								 	$legendurl = true;
								 	$currentLayer["style"][$index]["legendurl_width"] = $attributes["width"];
								 	$currentLayer["style"][$index]["legendurl_height"] = $attributes["height"];
								 	$currentLayer["style"][$index]["legendurl_format"] = $attributes["format"];
								}
							}
						}
						if ($tag == "STYLE" && $type == "open") {
							$style = true;
							array_push($currentLayer["style"], array("current" => $attributes["current"]));
							if ($attributes["current"] == "1") {
								$currentLayer["styleIndex"] = count($currentLayer["style"]) - 1;
							}
						}
						if ($tag == "STYLELIST" && $type == "close") {
							$stylelist = false;
						}
					}
					else {
						if ($tag == "SERVER" && $type == "open") {
							 $server = true;
							 $currentLayer["service"] = $attributes["service"];
							 $currentLayer["version"] = $attributes["version"];
							 $currentLayer["wms_title"] = $attributes["title"];
						}
						if ($server) {
							if ($tag == "SERVER" && $type == "close") {
						 		$server = false;
						 	}
							if ($tag == "ONLINERESOURCE") {
						 		$currentLayer["url"] = $attributes["xlink:href"];
							}
						}
						if ($tag == "NAME") {
					 		$currentLayer["name"] = $value;
						}
						if ($tag == "TITLE") {
					 		$currentLayer["title"] = $value;
						}
						if ($tag == "ABSTRACT") {
					 		$currentLayer["abstract"] = $value;
						}
						if ($tag == "SRS") {
							$currentLayer["epsg"] = explode(" ", $value);						 	
						}
						if ($tag == "EXTENSION" && $type == "close") {
							$extension = false;
						}
						if ($extension == true){
							if ($value !== "") {
								if (isset($currentLayer["extension"][$tag])) {
									if (!is_array($currentLayer["extension"][$tag])) {
										$firstValue = $currentLayer["extension"][$tag];
										$currentLayer["extension"][$tag] = array();
										array_push($currentLayer["extension"][$tag], $firstValue);
									}	
									array_push($currentLayer["extension"][$tag], $value);
								}
								else {
									$currentLayer["extension"][$tag] = $value;									
								}
							}
						}
						if ($tag == "EXTENSION" && $type == "open") {
							$currentLayer["extension"] = array();
							$extension = true;
						}
						if ($tag == "METADATAURL" && $type == "open") {
							$metadataurl = true;
						}
						if ($tag == "DATAURL" && $type == "open") {
							$dataurl = true;
						}
						if ($tag == "FORMATLIST" && $type == "open") {
							$formatlist = true;
						}
						if ($tag == "STYLELIST" && $type == "open") {
							$stylelist = true;
						}
					}
				}
			}
		}
		
		// set WMS data
		
		$layerlistCompleteArray = array_merge($layerlistArray["main"], $layerlistArray["overview"]);

		for ($i = 0; $i < count($layerlistCompleteArray); $i++) {
			$this->setLayerData($layerlistCompleteArray[$i]);
		}

		// set zoom full extent for root layer of first WMS
		$firstWms = $this->mainMap->getWms(0);
		$firstWms->objLayer[0]->layer_epsg = array();
		$boxList = $this->mainMap->getZoomFullExtentArray();
		for ($i = 0; $i < count($boxList); $i++) {
			$currentBox = $boxList[$i];
			array_push($firstWms->objLayer[0]->layer_epsg, array(
				"epsg" => $currentBox->epsg,
				"minx" => $currentBox->min->x,
				"miny" => $currentBox->min->y,
				"maxx" => $currentBox->max->x,
				"maxy" => $currentBox->max->y
			));
		}
		return true;
	}

	/**
	 * Saves the current WMC in the log folder.
	 * 
	 * @return string the filename of the WMC document.
	 */
	private function saveAsFile() {
		if ($this->saveWmcAsFile) {
			$filename = "wmc_" . date("Y_m_d_H_i_s") . ".xml";
			$logfile = "../tmp/" . $filename;
			
			if($h = fopen($logfile,"a")){
				$content = $this->xml;
				if(!fwrite($h,$content)){
					$e = new mb_exception("class_wmc.php: failed to write wmc.");
					return false;
				}
				fclose($h);
			}
			$e = new mb_notice("class_wmc: saving WMC as file " . $filename . "; You can turn this behaviour off in class_wmc.php");
			return $filename;
		}
		return null;
	}
	
	/**
	 * Called during WMC parsing; sets the data of a single layer.
	 * 
	 * @return 
	 * @param $currentLayer Array an associative array with layer data
	 */
	private function setLayerData ($currentLayer) {
		$currentMap = $this->mainMap;
		$currentMapIsOverview = false;

		if (isset($currentLayer["extension"]["OVERVIEWHIDDEN"])) {
			$currentMap = $this->overviewMap;
			$currentMapIsOverview = true;
		}

		if (is_null($currentMap)) {
			$e = new mb_exception('class_wmc.php: setLayerData: $currentMap is null. Aborting.');
			return null;
		}

		$wmsArray = $currentMap->getWmsArray();

		//
		// check if current layer belongs to an existing WMS.
		// If yes, store the index of this WMS in $wmsIndex.
		// If not, set the value to null.
		//
		$wmsIndex = null;

		// find last WMS with the same online resource
		for ($i = count($wmsArray) - 1; $i >= 0; $i--) {
			if (isset($currentLayer["url"]) && 
				$currentLayer["url"] == $wmsArray[$i]->wms_getmap) {
					$wmsIndex = $i;
					break;
			}
		}

		// Even if this WMS has been found before it could still
		// be a duplicate! We would have to create a new WMS and 
		// not append this layer to that WMS.
		// For the overview layer we never add a new wms.
		// check if this layer is an overview layer. If yes, skip this layer.
		if ($wmsIndex !== null && !$currentMapIsOverview) {

			// check if this WMS has a layer equal to the current layer.
			// If yes, this is a new WMS. If not, append this layer
			// to the existing WMS.
			$matchingWmsLayerArray = $this->wmsArray[$wmsIndex]->objLayer;
			
			for ($i = 0; $i < count($matchingWmsLayerArray); $i++) {
				if ($matchingWmsLayerArray[$i]->layer_name == $currentLayer["name"]) {

					// by re-setting the index to null, a new WMS will be 
					// added below.
					$wmsIndex = null;
					break;
				}
			}
		}

		// if yes, create a new WMS ...
		if ($wmsIndex === null) {
			$wmsIndex = 0;
			$wms = new wms();

			//
			// set WMS data
			//
			$wms->wms_id = $currentLayer["extension"]["WMS_ID"]; // TO DO: how about WMS without ID?
			$wms->wms_version = $currentLayer["version"];
			$wms->wms_title = $currentLayer["wms_title"];
			$wms->wms_abstract = $currentLayer["abstract"];
			$wms->wms_getmap = $currentLayer["url"];
			$wms->wms_getfeatureinfo = $currentLayer["url"]; // TODO : Add correct data
			
			$styleIndex = $currentLayer["styleIndex"];
			$wms->wms_getlegendurl = $currentLayer["style"][$styleIndex]["legendurl"];

			$wms->wms_filter = ""; // TODO : Add correct data

			$formatIndex = $currentLayer["formatIndex"];
			$wms->gui_wms_mapformat = $currentLayer["format"][$formatIndex]["name"];

			$wms->gui_wms_featureinfoformat = "text/html"; // TODO : Add correct data
			$wms->gui_wms_exceptionformat = "application/vnd.ogc.se_xml"; // TODO : Add correct data
			$wms->gui_wms_epsg = $this->mainMap->getEpsg();
			$wms->gui_wms_visible = $currentLayer["extension"]["WMS_VISIBLE"];
			$wms->gui_wms_opacity = 100; // TODO : Add correct data
			$wms->gui_wms_sldurl = $currentLayer["style"][$styleIndex]["sld_url"];

			$wms->gui_epsg = $currentLayer["epsg"];
			//
			// set data formats
			//
			for ($i = 0; $i < count($currentLayer["format"]); $i++) {
				array_push($wms->data_type, "map");							
				array_push($wms->data_format, $currentLayer["format"][$i]["name"]);							
			}

			// set root layer
			$wms->addLayer(0, "");
			$wms->objLayer[0]->layer_uid = $currentLayer["extension"]["WMS_LAYER_ID"];
			$wms->objLayer[0]->layer_name = $currentLayer["extension"]["WMS_NAME"];
			$wms->objLayer[0]->layer_title = $currentLayer["wms_title"];
			$wms->objLayer[0]->layer_pos = 0;
			$wms->objLayer[0]->layer_queryable = 0;
			$wms->objLayer[0]->layer_minscale = 0;
			$wms->objLayer[0]->layer_maxscale = 0;
			$wms->objLayer[0]->gui_layer_wms_id = $currentLayer["extension"]["WMS_ID"];
			$wms->objLayer[0]->gui_layer_status = 1;
			$wms->objLayer[0]->gui_layer_selectable = $currentLayer["extension"]["WMS_SELECTABLE"];
			$wms->objLayer[0]->gui_layer_visible = 1;
			$wms->objLayer[0]->gui_layer_queryable = 0;
			$wms->objLayer[0]->gui_layer_querylayer = 0;
			$wms->objLayer[0]->gui_layer_minscale = 0;
			$wms->objLayer[0]->gui_layer_maxscale = 0;

			// layer epsg
			if ($currentLayer["extension"]["EPSG"]) {
				$layerEpsgArray = array();
				$layerMinXArray = array();
				$layerMinYArray = array();
				$layerMaxXArray = array();
				$layerMaxYArray = array();
				if (!is_array($currentLayer["extension"]["EPSG"])) {
					$layerEpsgArray[0] = $currentLayer["extension"]["EPSG"];
					$layerMinXArray[0] = $currentLayer["extension"]["MINX"];
					$layerMinYArray[0] = $currentLayer["extension"]["MINY"];
					$layerMaxXArray[0] = $currentLayer["extension"]["MAXX"];
					$layerMaxYArray[0] = $currentLayer["extension"]["MAXY"];
				}
				else {
					$layerEpsgArray = $currentLayer["extension"]["EPSG"];
					$layerMinXArray = $currentLayer["extension"]["MINX"];
					$layerMinYArray = $currentLayer["extension"]["MINY"];
					$layerMaxXArray = $currentLayer["extension"]["MAXX"];
					$layerMaxYArray = $currentLayer["extension"]["MAXY"];
				}
	
				for ($i=0; $i < count($layerEpsgArray); $i++) {
					$currentLayerEpsg = array();
					$currentLayerEpsg["epsg"] = $layerEpsgArray[$i];
					$currentLayerEpsg["minx"] = floatval($layerMinXArray[$i]);
					$currentLayerEpsg["miny"] = floatval($layerMinYArray[$i]); 
					$currentLayerEpsg["maxx"] = floatval($layerMaxXArray[$i]);
					$currentLayerEpsg["maxy"] = floatval($layerMaxYArray[$i]);
					array_push($wms->objLayer[0]->layer_epsg, $currentLayerEpsg);
				}
			}			
			// add WMS
			array_push($wmsArray, $wms);

			// the index of the WMS we just added
			$wmsIndex = count($wmsArray) - 1;
		}

		// add layer to existing WMS ...
		$currentWms = $wmsArray[$wmsIndex];
		$currentWms->newLayer($currentLayer, null);
		$currentMap->setWmsArray($wmsArray);
		return true;
	}
	
	/**
	 * Called during WMC parsing; sets the maps within a WMC.
	 * 
	 * @return 
	 */
	private function setMapData () {
		if ($this->generalExtensionArray["OV_WIDTH"] && 
			$this->generalExtensionArray["OV_HEIGHT"] &&
			$this->generalExtensionArray["OV_FRAMENAME"] &&
			$this->generalExtensionArray["OV_MINX"] &&
			$this->generalExtensionArray["OV_MINY"] &&
			$this->generalExtensionArray["OV_MAXX"] &&
			$this->generalExtensionArray["OV_MAXY"] &&
			$this->generalExtensionArray["OV_SRS"]) {
			
			$this->overviewMap = new Map();
			$this->overviewMap->setWidth($this->generalExtensionArray["OV_WIDTH"]);
			$this->overviewMap->setHeight($this->generalExtensionArray["OV_HEIGHT"]);
			$this->overviewMap->setFrameName($this->generalExtensionArray["OV_FRAMENAME"]);
			$this->overviewMap->setIsOverview(true);

			$bbox = new Mapbender_bbox($this->generalExtensionArray["OV_MINX"], $this->generalExtensionArray["OV_MINY"], $this->generalExtensionArray["OV_MAXX"], $this->generalExtensionArray["OV_MAXY"], $this->generalExtensionArray["OV_SRS"]);
			$this->overviewMap->setExtent($bbox);
		}
		if ($this->generalExtensionArray["EPSG"] && 
			$this->generalExtensionArray["MINX"] && 		
			$this->generalExtensionArray["MINY"] && 		
			$this->generalExtensionArray["MAXX"] && 		
			$this->generalExtensionArray["MAXY"]) {

			$mainEpsgArray = array();
			$mainMinXArray = array();
			$mainMinYArray = array();
			$mainMaxXArray = array();
			$mainMaxYArray = array();
			if (!is_array($this->generalExtensionArray["EPSG"])) {
				$mainEpsgArray[0] = $this->generalExtensionArray["EPSG"];
				$mainMinXArray[0] = $this->generalExtensionArray["MINX"];
				$mainMinYArray[0] = $this->generalExtensionArray["MINY"];
				$mainMaxXArray[0] = $this->generalExtensionArray["MAXX"];
				$mainMaxYArray[0] = $this->generalExtensionArray["MAXY"];
			}
			else {
				$mainEpsgArray = $this->generalExtensionArray["EPSG"];
				$mainMinXArray = $this->generalExtensionArray["MINX"];
				$mainMinYArray = $this->generalExtensionArray["MINY"];
				$mainMaxXArray = $this->generalExtensionArray["MAXX"];
				$mainMaxYArray = $this->generalExtensionArray["MAXY"];
			}

			for ($i=0; $i < count($mainEpsgArray); $i++) {
				$box = new Mapbender_bbox(
					floatval($mainMinXArray[$i]), floatval($mainMinYArray[$i]), 
					floatval($mainMaxXArray[$i]), floatval($mainMaxYArray[$i]),
					$mainEpsgArray[$i]
				);				
				$this->mainMap->addZoomFullExtent($box);
			}
		}			

		if ($this->generalExtensionArray["MAIN_FRAMENAME"]) {
			$this->mainMap->setFrameName($this->generalExtensionArray["MAIN_FRAMENAME"]);
		}
		else {
			$this->mainMap->setFrameName("mapframe1");
		}
		return true;
	}

	/**
	 * Creates a WMC document (XML) from the current object
	 * 
	 * @return String XML
	 */
	private function createXml() {
		$wmcToXml = new WmcToXml($this);
		$this->xml = $wmcToXml->getXml();
	}
} 

/**
 * @deprecated
 */
function mb_utf8_encode ($str) {
//	if(CHARSET=="UTF-8") return utf8_encode($str);
	return $str;
}

/**
 * @deprecated
 */
function mb_utf8_decode ($str) {
//	if(CHARSET=="UTF-8") return utf8_decode($str);
	return $str;
}
?>
