<?php
# $Id: class_kml_geometry.php 1966 2008-01-15 08:25:15Z christoph $
# http://www.mapbender.org/index.php/class_wmc.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../../core/globalSettings.php");

/**
 * A Mapbender user as described in the table mb_user.
 */
class User {
	/**
	 * @var Integer The user ID
	 */
	var $id;
	
	/**
	 * Constructor
	 * @param $userId Integer 	the ID of the user that	is represented by 
	 * 							this object.
	 */
	public function __construct ($userId) {
		$this->id = $userId;
	}	
	
	/**
	 * @return String the ID of this user
	 */
	public function __toString () {
		return (string) $this->id;	
	}
	
	/**
	 * Returns an array of application IDs that the user is allowed to access.
	 * 
	 * @return Array an array of application IDs
	 * @param $ignorepublic boolean whether or not to ignore 
	 * 								public applications (?)
	 */
	public function getApplicationsByPermission ($ignorepublic) {
		$mb_user_id = $this->id;
		$arrayGuis = array();
		$mb_user_groups = array();
		$sql_groups = "SELECT fkey_mb_group_id FROM mb_user_mb_group WHERE fkey_mb_user_id = $1 ";
		$v = array($mb_user_id);
		$t = array("i");
		$res_groups = db_prep_query($sql_groups,$v,$t);
		$cnt_groups = 0;
		while($row = db_fetch_array($res_groups)){
			$mb_user_groups[$cnt_groups] = $row["fkey_mb_group_id"];
			$cnt_groups++;
		}
		if($cnt_groups > 0){
			$v = array();
			$t = array();
			$sql_g = "SELECT gui.gui_id FROM gui JOIN gui_mb_group ";
			$sql_g .= " ON gui.gui_id = gui_mb_group.fkey_gui_id WHERE gui_mb_group.fkey_mb_group_id IN (";
			for($i=0; $i<count($mb_user_groups);$i++){
				if($i > 0){$sql_g .= ",";}
				$sql_g .= "$".strval($i+1);
				array_push($v,$mb_user_groups[$i]);
				array_push($t,"i");
			}
			$sql_g .= ") GROUP BY gui.gui_id";
			$res_g = db_prep_query($sql_g,$v,$t);
			while($row = db_fetch_array($res_g)){
				array_push($arrayGuis,$row["gui_id"]);
			}
		}
		$sql_guis = "SELECT gui.gui_id FROM gui JOIN gui_mb_user ON gui.gui_id = gui_mb_user.fkey_gui_id";
		$sql_guis .= " WHERE (gui_mb_user.fkey_mb_user_id = $1) ";
		if (!isset($ignore_public) OR $ignore_public== false){
			$sql_guis .= " AND gui.gui_public = 1 ";
		}
		$sql_guis .= " GROUP BY gui.gui_id";
		$v = array($mb_user_id);
		$t = array("i");
		$res_guis = db_prep_query($sql_guis,$v,$t);
		$guis = array();
		while($row = db_fetch_array($res_guis)){
			if(!in_array($row['gui_id'],$arrayGuis)){
				array_push($arrayGuis,$row["gui_id"]);
			}
		}
		return $arrayGuis;
	}	
	
	/** identifies the IDs of WFS confs where the user is owner
	 * 
	 * @param integer userid the user-ID of the current user
	 * @return integer[] the IDs of the wfs_conf-table
	 */
	public function getWfsConfByPermission(){
		$userid = $this->id;
	 	$guisByPer = array();
//	 	1.
		$adm = new administration();
	 	$guisByPer = $adm->getGuisByPermission($userid, true);
//	 	2. 
		$ownWFSconfs = array();
		if(count($guisByPer)>0){
			$v = array();
			$t = array();
			$sql = "SELECT wfs_conf.wfs_conf_id  FROM gui_wfs_conf, wfs_conf " .
					"where wfs_conf.wfs_conf_id = gui_wfs_conf.fkey_wfs_conf_id " .
					"and gui_wfs_conf.fkey_gui_id IN(";
			for($i=0; $i<count($guisByPer); $i++){
				if($i>0){ $sql .= ",";}
				$sql .= "$".strval($i+1);
				
				array_push($v, $guisByPer[$i]);
				array_push($t, "s");
			}
			$sql .= ") GROUP BY wfs_conf.wfs_conf_id ORDER BY wfs_conf.wfs_conf_id";
			
			$res = db_prep_query($sql,$v,$t);
			$i=0;
			while($row = db_fetch_array($res)){
				$ownWFSconfs[$i] = $row['wfs_conf_id'];
				$i++;
			}
		}
		return $ownWFSconfs;
	}
	
	/**
	 * Returns all WMCs that this user owns
	 * 
	 * @return integer[] an array of WMC ids; ids from table mb_user_wmc
	 */
	public function getWmcByOwner () {
		$sql = "SELECT wmc_id FROM mb_user_wmc ";
		$sql .= "WHERE fkey_user_id = $1 GROUP BY wmc_id";
		$v = array($this->id);
		$t = array("i");
		$res_wmc = db_prep_query($sql, $v, $t);

  		$wmcArray = array();
		while($row = db_fetch_array($res_wmc)){
			array_push($wmcArray, $row["wmc_id"]);
		}
		return $wmcArray;
	}
}
?>
