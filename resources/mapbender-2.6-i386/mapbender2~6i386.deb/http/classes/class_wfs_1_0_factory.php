<?php
# $Id: class_wfs.php 3094 2008-10-01 13:52:35Z christoph $
# http://www.mapbender.org/index.php/class_wfs.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../../core/globalSettings.php");
require_once(dirname(__FILE__)."/../classes/class_wfs_factory.php");
require_once(dirname(__FILE__)."/../classes/class_wfs_1_0.php");
require_once(dirname(__FILE__)."/../classes/class_wfs_featuretype.php");
require_once(dirname(__FILE__)."/../classes/class_connector.php");
require_once(dirname(__FILE__)."/../classes/class_administration.php");

/**
 * Creates WFS 1.0 objects from a capabilities documents.
 * 
 * @return Wfs_1_0
 */
class Wfs_1_0_Factory extends WfsFactory {

	protected function createFeatureTypeFromUrl ($aWfs, $featureTypeName) {
		$url = $aWfs->describeFeatureType . 
			$aWfs->getConjunctionCharacter($aWfs->describeFeatureType) . 
			"&SERVICE=WFS&VERSION=" . $aWfs->getVersion() . 
			"&REQUEST=DescribeFeatureType&TYPENAME=" . $featureTypeName;
		
		$xml = $this->get($url);
		return $this->createFeatureTypeFromXml ($xml, $aWfs);
	}
		
	protected function createFeatureTypeFromXml ($xml, $myWfs) {
		$newFeatureType = new WfsFeatureType($myWfs);

		$admin = new administration();
		$values = $admin->parseXml($xml);

		foreach ($values as $element) {	
			if ($this->sepNameSpace($element[tag]) == "schema" && $element[type] == "open") {
				$section = "namespace";
			}
			
			if ($section == "namespace" && is_array($element[attributes])) {	
					
				while (list($k, $val) = each ($element[attributes])) {
   					if (substr($k, 0, 5) == "xmlns") {
   						$key = $this->sepNameSpace($k);
						$newFeatureType->addNamespace($key, $val);
   					}
				}
			}
			if($this->sepNameSpace($element[tag]) == "complexContent" && $element[type] == "open"){
				$section = "complexcontent";
			}
			if($section == "complexcontent" && $this->sepNameSpace($element[tag]) == "element" && $element[attributes][name]){
				$newFeatureType->addElement(
					$element[attributes]["name"], 
					$this->sepNameSpace($element[attributes]["type"])
				);				
			}
			if($this->sepNameSpace($element[tag]) == "complexContent" && $element[type] == "close"){
				$section = "";
			}
		}	
		return $newFeatureType;	
	}

	/**
	 * Creates WFS 1.0 objects from a capabilities documents.
	 * 
	 * @return Wfs_1_0
	 * @param $xml String
	 */
	public function createFromXml ($xml) {
		try {
			
			$myWfs = new Wfs_1_0();
		
			$admin = new administration();
			$values = $admin->parseXml($xml);
			
			$myWfs->getCapabilitiesDoc = $admin->char_encode($xml);
			$myWfs->id = $this->createId();
		
			foreach ($values as $element) {
				$tag = strtoupper($element[tag]);

				if($tag == "WFS_CAPABILITIES" && $element[type] == "open"){
					$myWfs->version = $element[attributes][version];
					if ($myWfs->version !== "1.0.0") {
						throw new Exception("Not a WFS 1.0.0 capabilities document.");
					}
				}
				if($tag == "NAME"  && $element[level] == '3'){
					$myWfs->name = $element[value];
				}
				if($tag == "TITLE"  && $element[level] == '3'){
					$myWfs->title = $this->stripEndlineAndCarriageReturn($element[value]);
				}
				if($tag == "ABSTRACT" && $element[level] == '3'){
					$myWfs->summary = $this->stripEndlineAndCarriageReturn($element[value]);
				}
				if($tag == "FEES"){
					$myWfs->fees = $element[value];
				}
				if($tag == "ACCESSCONSTRAINTS"){
					$myWfs->accessconstraints = $element[value];
				}
				
				# getCapabilities
				if($tag == "GETCAPABILITIES" && $element[type] == "open"){
					$section = "getcapabilities";
				}
				if($section == "getcapabilities" && $tag == "GET"){
					$myWfs->getCapabilities = $element[attributes][onlineResource];
				}
				
				# descriptFeatureType
				if($tag == "DESCRIBEFEATURETYPE" && $element[type] == "open"){
					$section = "describefeaturetype";
					$myWfs->describeFeatureType = $element[attributes][onlineResource];
					
					
				}
				if($section == "describefeaturetype" && $tag == "POST"){
					$myWfs->describeFeatureType = $element[attributes][onlineResource];
				}
				
				# getFeature
				if($tag == "GETFEATURE" && $element[type] == "open"){
					$section = "getfeature";
				}
				if($section == "getfeature" && $tag == "POST"){
					$myWfs->getFeature = $element[attributes][onlineResource];
				}
				if($tag == "GETFEATURE" && $element[type] == "close"){
					$section = "";
				}			
				# transaction
				if($tag == "TRANSACTION" && $element[type] == "open"){
					$section = "transaction";
				}
				if($section == "transaction" && $tag == "POST"){
					$myWfs->transaction = $element[attributes][onlineResource];
				}
				if($tag == "TRANSACTION" && $element[type] == "close"){
					$section = "";
				}
				if($tag == "FEATURETYPE" && $element[type] == "open"){
					$section = "featuretype";
				}
				if($section == "featuretype" && $tag == "NAME"){
					$featuretype_name = $element[value];
				}
				if($section == "featuretype" && $tag == "TITLE"){
					$featuretype_title = $this->stripEndlineAndCarriageReturn($element[value]);
				}
				if($section == "featuretype" && $tag == "ABSTRACT"){
					$featuretype_abstract = $element[value];
				}
				if($section == "featuretype" && $tag == "SRS"){
					$featuretype_srs = $element[value];

					$currentFeatureType = $this->createFeatureTypeFromUrl($myWfs, $featuretype_name);
					if ($currentFeatureType !== null) {
						$currentFeatureType->name = $featuretype_name;
						$currentFeatureType->title = $featuretype_title;
						$currentFeatureType->summary = $featuretype_abstract;
						$currentFeatureType->srs = $featuretype_srs;

						$myWfs->addFeatureType($currentFeatureType);
					}
				}
			}
			return $myWfs;
		}
		catch (Exception $e) {
			$e = new mb_exception($e);
			return null;
		}
	}
	
	public function createFromDb ($id) {
		$myWfs = new Wfs_1_0();
		return parent::createFromDb($id, $myWfs);
	}
}
?>