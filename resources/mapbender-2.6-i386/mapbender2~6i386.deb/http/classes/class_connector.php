<?php
# $Id: class_connector.php 4672 2009-09-22 08:07:04Z christoph $
# http://www.mapbender.org/index.php/class_connector
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../../core/globalSettings.php");
session_write_close();
/**
 * Establishes a connection to a given URL (and loads the content).
 * Supports HTTP (GET and POST), cURL and socket connections.
 * 
 * @class
 */
class connector {

	var $file;	
	private $connectionType;
	private $httpType = "get";
	private $httpVersion = "1.0";
	private $httpPostData;
	private $httpContentType;
		
	/**
	 * @constructor
	 * @param String url the URL that will be loaded (optional)
	 */
	public function __construct() {
		$this->set("connectionType", CONNECTION);
		if (func_num_args() == 1) {
			$url = func_get_arg(0);
			$this->load($url);
		}
	}
	
	/**
	 * Loads content from the given URL.
	 */
	public function load($url) {
		if (!$url) {
			$e = new mb_exception("connector: no URL given");
			return false;
		}
		switch ($this->connectionType) {
			case "curl":
		        $host = parse_url($url,PHP_URL_HOST);
		        
		        // fill array (HOSTs not for Proxy)
		        $NOT_PROXY_HOSTS_array = explode(",", NOT_PROXY_HOSTS);

				if (in_array($host, $NOT_PROXY_HOSTS_array)){
				    $e = new mb_notice("HTTP host:".$host);
					$this->file = $this->getHTTP($url);
				}
				else {
				    $e = new mb_notice("CURL host:".$host);
					$this->file = $this->getCURL($url);
				}
				break;
			case "http":
				$this->file = $this->getHTTP($url);
				break;
			case "socket":
				$this->file = $this->getSOCKET($url);
				break;
		}
		if(!$this->file){
			$e = new mb_exception("connector: unable to load: ".$url);
			return false;
		}
		return $this->file;		
	}
	
	/**
	 * Sets the environment variables. The following can be set:
	 * - connectionType ("http", "curl", "socket")
	 * - httpType ("get", "post")
	 * - etc.
	 */
	public function set ($key, $value) {
		switch ($key) {
			case "connectionType":
				if ($this->isValidConnectionType($value)) {
					$this->connectionType = $value;
				}
				break;
				
			case "httpVersion":
				if (in_array($value, array("1.0", "1.1"))) {
					$this->httpVersion = $value;
				}
				else {
					$e = new mb_exception("class_connector.php: invalid http type '" . $value . "'");
				}
				break;
							
			case "httpType":
				if (in_array(mb_strtoupper($value), array("POST", "GET"))) {
					$this->httpType = $value;
				}
				else {
					$e = new mb_exception("class_connector.php: invalid http type '" . $value . "'");
				}
				break;
			
			case "httpPostData":
				$this->httpPostData = $value;
				break;
				
			case "httpContentType":
				if ($this->isValidHttpContentType($value)) {
					$this->httpContentType = $value;
				}
				break;
		}
	}	
	
	private function isValidConnectionType ($value) {
		if (in_array(mb_strtoupper($value), array("HTTP", "CURL", "SOCKET"))) {
			return true;
		}
		else {
			$e = new mb_exception("class_connector.php: invalid connection type '" . $value . "'");
			return false;
		}
	}
	
	private function isValidHttpContentType ($value) {
		$validHttpContentTypeArray = array("XML");
		if (in_array(mb_strtoupper($value), $validHttpContentTypeArray)) {
			switch (mb_strtoupper($value)) {
				case "XML":
					$this->httpContentType = "application/xml";
					break;
			}
			return true;
		}
		else {
			$e = new mb_exception("class_connector.php: invalid HTTP content type '" . $value . "'");
			return false;
		}
	}
	
	private function getCURL($url){
		$ch = curl_init ($url);
//		curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		if(CONNECTION_PROXY != ""){
			curl_setopt($ch, CURLOPT_PROXY,CONNECTION_PROXY.":".CONNECTION_PORT);	
		}		
		if(CONNECTION_PASSWORD != ""){
			curl_setopt ($ch, CURLOPT_PROXYUSERPWD, CONNECTION_USER.':'.CONNECTION_PASSWORD);	
		}
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
		
		//if httpType is POST, set CURLOPT_POST and CURLOPT_POSTFIELDS  
		if($this->httpType == 'POST'){
			curl_setopt ($ch, CURLOPT_POST, 1);
			curl_setopt ($ch, CURLOPT_POSTFIELDS, $this->httpPostData);
			$this_header = array(
   			 		"MIME-Version: 1.0",
    				"Content-type: text/html; charset=" . CHARSET,
    				"Content-transfer-encoding: text"
			); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);
		}
		
		$file = curl_exec ($ch);
		curl_close ($ch);

		return $file;	
	}

	private function getHTTP($url){
		if ($this->httpType == "get") {
			return @file_get_contents($url);
	 	}
		else {
			$errno = 0;
			$errstr = "";
			$urlComponentArray = parse_url($url);
			$scheme = $urlComponentArray["scheme"];
			$host = $urlComponentArray["host"];
			$port = $urlComponentArray["port"]; 
			if ($port == "") {
				if ($scheme == "https") {
					$port = 443;
				}
				else {
					$port = 80;		
				}
			}	
			$path = $urlComponentArray["path"];
			$query = $urlComponentArray["query"];
			$buf = '';
			if ($scheme == "https") {
				$fp = fsockopen("ssl://". $host, $port, $errno, $errstr);				
			}
			else {
			    $fp = fsockopen($host, $port);
			}
			$postStr = "";
			$postPath = "POST " . $path . "?" . $query . " HTTP/".$this->httpVersion . "\r\n";
			$postStr .= $postPath;
		    fputs($fp, $postPath);
			
			$postHost = "Host: " . $host . "\r\n";
			$postStr .= $postHost;
		    fputs($fp, $postHost);
			
		    if ($this->isValidHttpContentType($this->httpContentType)) {
				$postContentType = "Content-type: " . $this->httpContentType . "\r\n";
				$postStr .= $postContentType;
		    	fputs($fp, $postContentType);
		    }
			$postContentLength = "Content-length: " . strlen($this->httpPostData) . "\r\n";
			$postStr .= $postContentLength;
		    fputs($fp, $postContentLength);
			
			$postClose = "Connection: close\r\n\r\n";
			$postStr .= $postClose;
		    fputs($fp, $postClose);

		    $postStr .= $this->httpPostData;
			fputs($fp, $this->httpPostData);

			new mb_notice("connector.http.postData: ".$this->httpPostData);
			
		    $xmlstr = false;
		    while (!feof($fp)) {
		    	$content = fgets($fp,4096);
//		    	if( strpos($content, '<?xml') === 0){
		    	if( strpos($content, '<') === 0){
		    		$xmlstr = true;
		    	}
		    	if($xmlstr == true){
		    		$buf .= $content;
		    	}
			}
		    fclose($fp);
		    new mb_notice("connector.http.response: ".$buf);
		    return $buf;			
		}
	}

	private function getSOCKET($url){
		$r = "";
		$fp = fsockopen (CONNECTION_PROXY, CONNECTION_PORT, $errno, $errstr, 30);
		if (!$fp) {
			echo "$errstr ($errno)<br />\n";
		} 
		else {
			fputs ($fp, "GET ".$url." HTTP/1.0\r\n\r\n");
			while (!feof($fp)) {
				$r .= fgets($fp,4096);
			}
			fclose($fp);
			return $r;
		}
	}
}
?>
