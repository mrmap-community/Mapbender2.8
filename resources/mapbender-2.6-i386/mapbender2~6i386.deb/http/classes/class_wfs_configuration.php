<?php
# $Id: class_wfs_conf.php 3510 2009-02-03 10:36:01Z christoph $
# http://www.mapbender.org/index.php/class_wfs_conf.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../../core/globalSettings.php");
require_once(dirname(__FILE__)."/../classes/class_user.php");
require_once(dirname(__FILE__)."/../classes/class_administration.php");
require_once(dirname(__FILE__)."/../classes/class_json.php");

class WfsConfigurationElement {
	var $name;
	var $type;
	var $search;
	var $styleId;
	var $toUpper;
	var $label;
	var $labelId;
	var $geom;
	var $show;
	var $mandatory;
	var $respos;
	var $minInput;
	var $formElementHtml;
	var $authVarname;
	var $detailPos;
	var $operator;
	var $showDetail;
}	


class WfsConfiguration {
	
	var $id;
	var $wfsId;
	var $featureTypeId;
	var $label; 
	var $labelId;
	var $style;
	var $button;
	var $buttonId;
	var $buffer;
	var $resStyle;
	var $elementArray = array();

	function __construct () {
	}
	
	public function getGeometryColumnName () {
		foreach ($this->elementArray as $element) {
			if ($element->geom) {
				return $element->name;
			}
		}
		$e = new mb_warning("This WFS conf doesn't have a geometry column.");
		return null;
	}
	
	/**
	 * Finds the featuretype element which stores the authentication data.
	 * 
	 * @return String 
	 */
	public function getAuthElement () {
		foreach ($this->elementArray as $element) {
			if (!empty($element->authVarname)) {
				$validname = preg_match('/^\$_[a-zA-z]+(\[\"[a-zA-Z_]+\"\])?$/', $element->authVarname);

				if ($validname === 1) {
					return $element;
				}
				else {
					$e = new mb_exception("Found auth element, but variable name is not valid: " . $element->authVarname);
				}
			}
		}
		return null;
	}

	/**
	 * Checks if the user currently logged in is allowed to access
	 * the WFS configuration
	 * 
	 * @return Boolean
	 */
	private function accessAllowed () {
		if ($_SESSION["mb_user_id"]) {
			$user = new User($_SESSION["mb_user_id"]);

			$allowedWfsConfIds = $user->getWfsConfByPermission();

			$idArray = array_intersect(array($this->id), $allowedWfsConfIds);

			if (count($idArray) === 1) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Creates an object from the database.
	 * Maybe we could have a factory for this later...let's
	 * keep it simple for now
	 * 
	 * @return WfsConfiguration
	 * @param $id Integer
	 */
	public static function createFromDb ($id) {
		if (!is_numeric($id)) {
			return null;	
		}
		$wfsConf = new WfsConfiguration();
		$wfsConf->id = intval($id);
		
		if (!$wfsConf->accessAllowed()) {
			return null;
		}
		
		$sql = <<<SQL
SELECT * FROM wfs_conf JOIN wfs ON wfs_conf.fkey_wfs_id = wfs.wfs_id 
WHERE wfs_conf.wfs_conf_id = $1 LIMIT 1
SQL;

        $v = array($wfsConf->id);
        $t = array("i");
        $res = db_prep_query($sql, $v, $t);
        $row = db_fetch_array($res);
		
		$wfsConf->label = $row["g_label"];
		$wfsConf->labelId = $row["g_label_id"];
		$wfsConf->style = $row["g_style"];
		$wfsConf->button = $row["g_button"];
		$wfsConf->buttonId = $row["g_button_id"];
		$wfsConf->buffer = $row["g_buffer"];
		$wfsConf->resStyle = $row["g_res_style"];
		$wfsConf->wfsId = $row["fkey_wfs_id"];
		$wfsConf->featureTypeId = $row["fkey_featuretype_id"];

		$sql = <<<SQL
SELECT * FROM wfs_conf_element JOIN wfs_element 
ON wfs_conf_element.f_id = wfs_element.element_id 
WHERE wfs_conf_element.fkey_wfs_conf_id = $1
SQL;
		$v = array($wfsConf->id);
		$t = array('i');
		$res = db_prep_query($sql, $v, $t);
	
		
		while ($row = db_fetch_array($res)) {
			$element = new WfsConfigurationElement();

			$element->name = $row["element_name"];
			$element->type = $row["element_type"];
			$element->search = $row["f_search"];
			$element->styleId = $row["f_style_id"];
			$element->toUpper = $row["f_toupper"];
			$element->label = $row["f_label"];
			$element->labelId = $row["f_label_id"];
			$element->geom = $row["f_geom"];
			$element->show = $row["f_show"];
			$element->mandatory = $row["f_mandatory"];
			$element->respos = $row["f_respos"];
			$element->minInput = $row["f_min_input"];
			$element->formElementHtml = $row["f_form_element_html"];
			$element->authVarname = stripslashes($row["f_auth_varname"]);
			$element->detailpos = $row["f_detailpos"];
			$element->operator = $row["f_operator"];
			$element->showDetail = $row["f_show_detail"];

			array_push($wfsConf->elementArray, $element);
		}
		
		return $wfsConf;
	}
}
?>