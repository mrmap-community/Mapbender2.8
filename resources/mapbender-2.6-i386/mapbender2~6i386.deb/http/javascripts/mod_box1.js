
var mb_isActive=false;var mb_isBF=false;var mb_zF=false;var mb_boxMapObj=null;var mb_offset_top=0;var mb_offset_right=0;var mb_offset_bottom=0;var mb_offset_left=0;function mod_box_start(e){mb_boxMapObj=getMapObjByName(mb_isBF);mb_isActive=true;mb_boxMapObj.getMousePos(e);mb_start_x=clickX;mb_start_y=clickY;mb_end_x=mb_start_x+1;mb_end_y=mb_start_y+1;mb_offset_left=mb_start_x;mb_offset_top=mb_start_y;mb_offset_bottom=mb_start_y;mb_offset_right=mb_start_x;mb_drawBox(mb_start_x,mb_start_y,mb_end_x,mb_end_y);return false;}
function mod_box_run(e){if(mb_isActive){mb_boxMapObj.getMousePos(e);var width=mb_boxMapObj.width;var height=mb_boxMapObj.height;if(((clickX>width)||(clickY>height)||(clickX<=0)||(clickY<=0))){isActive=false;mod_box_stop(e);}
else{mb_end_x=clickX;mb_end_y=clickY;evalExtent();}
return false;}}
function mod_box_stop(e){mb_hideElement("l_top");mb_hideElement("l_left");mb_hideElement("l_right");mb_hideElement("l_bottom");if(mb_isActive){mb_isActive=false;return mb_setMapExtent(mb_start_x,mb_start_y,mb_end_x,mb_end_y);}
mb_isActive=false;}
function mb_drawBox(left,top,right,bottom){mb_boxMapObj=getMapObjByName(mb_isBF);var map_el=mb_boxMapObj.getDomElement();if(!map_el.ownerDocument.getElementById(mb_boxMapObj.elementName+"_l_top")){el_top=map_el.ownerDocument.createElement("div");el_top.style.position="absolute";el_top.style.top="0px";el_top.style.left="0px";el_top.style.width="0px";el_top.style.height="0px";el_top.style.overflow="hidden";el_top.style.zIndex="10";el_top.style.visibility="hidden";el_top.style.cursor="crosshair";el_top.style.backgroundColor="#ff0000";el_left=el_top.cloneNode(false);el_right=el_top.cloneNode(false);el_bottom=el_top.cloneNode(false);el_top.id=mb_boxMapObj.elementName+"_l_top";el_left.id=mb_boxMapObj.elementName+"_l_left";el_right.id=mb_boxMapObj.elementName+"_l_right";el_bottom.id=mb_boxMapObj.elementName+"_l_bottom";map_el.appendChild(el_top);map_el.appendChild(el_left);map_el.appendChild(el_right);map_el.appendChild(el_bottom);}
mb_arrangeBox("l_top",left,top,right,top+2);mb_arrangeBox("l_left",left,top,left+2,bottom);mb_arrangeBox("l_right",right-2,top,right,bottom);mb_arrangeBox("l_bottom",left,bottom-2,right,bottom);mb_displayElement("l_top");mb_displayElement("l_left");mb_displayElement("l_right");mb_displayElement("l_bottom");}
function mb_arrangeBox(name,left,top,right,bottom){var map_el=mb_boxMapObj.getDomElement();var el=map_el.ownerDocument.getElementById(mb_boxMapObj.elementName+"_"+name).style;el.height=Math.abs(bottom-top);el.width=Math.abs(right-left);el.top=top+"px";el.left=left+"px";}
function mb_displayElement(name){var map_el=mb_boxMapObj.getDomElement();var el=map_el.ownerDocument.getElementById(mb_boxMapObj.elementName+"_"+name).style.visibility="visible";}
function mb_hideElement(name){var map_el=mb_boxMapObj.getDomElement();var el=map_el.ownerDocument.getElementById(mb_boxMapObj.elementName+"_"+name).style.visibility="hidden";}
function evalExtent(){if(mb_start_x>mb_end_x){mb_offset_right=mb_start_x;mb_offset_left=mb_end_x;}
else{mb_offset_left=mb_start_x;mb_offset_right=mb_end_x;}
if(mb_start_y>mb_end_y){mb_offset_bottom=mb_start_y;mb_offset_top=mb_end_y;}
else{mb_offset_top=mb_start_y;mb_offset_bottom=mb_end_y;}
if((mb_start_x!=mb_end_x)&&(mb_start_y!=mb_end_y)){mb_drawBox(mb_offset_left,mb_offset_top,mb_offset_right,mb_offset_bottom);}}
function mb_setMapExtent(x1,y1,x2,y2){if(x1<x2){var minx=x1;var maxx=x2;}
else{var minx=x2;var maxx=x1;}
if(y1<y2){var miny=y2;var maxy=y1;}
else{var miny=y1;var maxy=y2;}
var ret=[];if((maxx-minx)>3&&(miny-maxy)>3){var posMin=makeClickPos2RealWorldPos(mb_isBF,minx,miny);var posMax=makeClickPos2RealWorldPos(mb_isBF,maxx,maxy);ret[0]=posMin[0];ret[1]=posMin[1];ret[2]=posMax[0];ret[3]=posMax[1];return ret;}
else{var posMin=makeClickPos2RealWorldPos(mb_isBF,minx,miny);ret[0]=posMin[0];ret[1]=posMin[1];return ret;}}
function mod_box_setValidClipping(coords){if(typeof(coords)!=="undefined"){if(coords.length>2){mb_calculateExtent(mb_zF,coords[0],coords[1],coords[2],coords[3]);setMapRequest(mb_zF);}
else{zoom(mb_zF,true,1.0,coords[0],coords[1]);}}}