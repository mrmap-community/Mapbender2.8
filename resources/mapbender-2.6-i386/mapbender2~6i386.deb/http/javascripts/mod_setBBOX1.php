<?php
# $Id: mod_setBBOX1.php 3373 2009-01-02 09:05:49Z christoph $
# http://www.mapbender.org/index.php/mod_setBBOX1.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
echo "var mod_setBBOX_target = '".$e_target[0]."';";
?>
eventInit.register(function () {
	mod_setBBOX_init();
});
function mod_setBBOX_init(){
	var my_target = mod_setBBOX_target.split(",");
	var myBBOX = "<?php echo $_SESSION['mb_myBBOX'] ?>";
	for(var i=0; i<my_target.length; i++){
		if(myBBOX != ""){
			var coord = myBBOX.split(","); 
			mb_calculateExtent(my_target[i],parseFloat(coord[0]),parseFloat(coord[1]),parseFloat(coord[2]),parseFloat(coord[3]));
		}
	}
}
