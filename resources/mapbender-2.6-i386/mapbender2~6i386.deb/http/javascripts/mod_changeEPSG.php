<?php
# $Id:mod_changeEPSG.php 3397 2009-01-02 15:24:40Z christoph $
# http://www.mapbender.org/index.php/mod_changeEPSG.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require(dirname(__FILE__)."/../php/mb_validateSession.php");

include(dirname(__FILE__)."/../include/dyn_js.php");

echo "var myTarget = '".$e_target[0]."';";
echo "var myId = '".$e_id."';";
?>
var exists = false;

eventAfterMapRequest.register(function () {
	mod_changeEPSG_setBox();
});

eventInit.register(function () {
//	mod_changeEPSG_init();
});

function mod_changeEPSG_setBox(){
	$("#"+myId+" option").each(function () {
		if (this.value == mb_mapObj[0].epsg) {
			isEPSG = true;
			$(this).attr("selected", "selected");
		}
	});
}

$("#"+myId).change(function () {
	var srsArray = [];
	for (var i = 0; i < mb_mapObj.length; i++) {
		var currentSrs = {
			"frameName" : mb_mapObj[i].elementName,
			"epsg" : mb_mapObj[i].epsg,
			"extent" : mb_mapObj[i].extent,
			"width" : mb_mapObj[i].width,
			"height" : mb_mapObj[i].height
		};
		srsArray.push(currentSrs);
	}

	var req = new Mapbender.Ajax.Request({
		"method":"changeEpsg",
		"parameters":{
			"srs":srsArray,
			"newSrs": $("#"+myId).get(0).value
		}
	});
	req.send("../php/mod_changeEPSG_server.php", function (obj, success, message) {
		if (!success) {
			new Mb_exception("!!!!!!"+message);
			return;
		}
		
		var newExtent = obj;
		
		for(var i = 0; i < newExtent.length; i++) {
			if(newExtent[i].frameName == myTarget){

				var ind = getMapObjIndexByName(myTarget);
				
				for(var ii = 0; ii < mb_mapObj[ind].mb_MapHistoryObj.length; ii++) {
					if (mb_mapObj[ind].mb_MapHistoryObj[ii].epsg == newExtent[i].newSrs) {
						exists = ii;
						var goback = true;
					}
				}

				if (goback) {
					var extArray = mb_mapObj[ind].mb_MapHistoryObj[exists].extent.split(",");
					var newExt = new Extent(
						parseFloat(extArray[0]),
						parseFloat(extArray[1]),
						parseFloat(extArray[2]),
						parseFloat(extArray[3])
					);
					mb_mapObj[ind].setSrs({
						srs: newExtent[i].newSrs,
						extent: newExt
					});
				}
				else{
					mb_mapObj[ind].setSrs({
						srs: newExtent[i].newSrs,
						extent: new Extent(
							parseFloat(newExtent[i].minx),
							parseFloat(newExtent[i].miny),
							parseFloat(newExtent[i].maxx),
							parseFloat(newExtent[i].maxy)
						)
					});
				}
			}
			else {
				var ind = getMapObjIndexByName(newExtent[i].frameName);
				mb_mapObj[ind].setSrs({
					srs: newExtent[i].newSrs,
					extent: new Extent(
						parseFloat(newExtent[i].minx),
						parseFloat(newExtent[i].miny),
						parseFloat(newExtent[i].maxx),
						parseFloat(newExtent[i].maxy)
					)
				});
			}
			setMapRequest(newExtent[i].frameName);
		}


	});
});