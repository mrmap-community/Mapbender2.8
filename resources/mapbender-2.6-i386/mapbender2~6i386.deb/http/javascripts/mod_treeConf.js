
mb_registerSubFunctions("window.frames['treeConfGDE'].checkLayer()");