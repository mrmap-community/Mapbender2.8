<?php 
# $Id:$
# http://www.mapbender.org/Mapbender_without_iframes
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");

?>

(function () {

<?php
	include '../include/dyn_js.php';
?>


	try {
		if (skipWmsIfSrsNotSupported) {}
	}
	catch (e) {
		skipWmsIfSrsNotSupported = 0;
	}

	var mapTimeout;
	var	sum_delta = 0;
	var lastTimestamp;
	var lastScrollPosition;
	var mapObject;
	
	
	
	eventInitMap.register(function init_mod_map1(){
			
		mapObject = mb_registerMapObj('', 'mapframe1', null,<?php echo $e_width; ?>, <?php echo $e_height; ?>);
		
		mapObject.skipWmsIfSrsNotSupported = 
			skipWmsIfSrsNotSupported === 1 ? true : false;


		$(document).mousewheel(function (e, delta) {
			if (sum_delta == 0) {
				mapTimeout = setTimeout(function () {
						lastScrollPosition = mapObject.getMousePosition(e);
						mousewheelZoom();	
					}, 
					100);
			}
			sum_delta = sum_delta + (delta);
			var currentTime = new Date();
			lastTimestamp = currentTime.getTime();
			
			return false;
		});
	});
	
	function mousewheelZoom () {
		var currentTime = new Date();
	
		if (currentTime.getTime() - lastTimestamp > 200) {
			if (lastScrollPosition !== null) {
				var pos = mapObject.convertPixelToReal(lastScrollPosition);
	
				if (sum_delta > 0) {
					mapObject.zoom(true, Math.pow(Mapbender.zoomMousewheel, sum_delta), pos.x, pos.y);
				}
				else {
					mapObject.zoom(false, Math.pow(Mapbender.zoomMousewheel, -sum_delta), pos.x, pos.y);
				}
				
				var newPos = new Point();
				newPos.x = mapObject.width - lastScrollPosition.x;
				newPos.y = mapObject.height - lastScrollPosition.y;
						
				var posAfterZoom = mapObject.convertPixelToReal(newPos);
				mapObject.zoom(false, 1.0, posAfterZoom.x, posAfterZoom.y);
			}			
			sum_delta = 0;
			clearTimeout(mapTimeout);
		}
		else {
			mapTimeout = setTimeout(function () {
					mousewheelZoom(sum_delta);	
				}, 
				100
			);
		}
	}
})();
