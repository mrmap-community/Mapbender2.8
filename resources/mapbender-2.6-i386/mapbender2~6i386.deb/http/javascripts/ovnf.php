<?php 
# $Id:$
# http://www.mapbender.org/Mapbender_without_iframes
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include '../include/dyn_js.php';
?>
try {
	if (skipWmsIfSrsNotSupported) {}
}
catch (e) {
	skipWmsIfSrsNotSupported = 0;
}

var mod_overview_target = "<?php echo $e_target[0]; ?>";
if (typeof(overview_wms) === 'undefined')overview_wms = 0;
overview_wms = parseInt(overview_wms);

var mod_overview_width = <?php echo $e_width; ?>;
var mod_overview_height = <?php echo $e_height; ?>;

mb_registerMapObj('', 'overview', overview_wms ,<?php echo $e_width; ?>, <?php echo $e_height; ?>);
parent.eventInitMap.register(function init_overview(){
	var ind = getMapObjIndexByName('overview');
	
	var el = mb_mapObj[ind].getDomElement();
	el.onmouseover = mod_ovSetHandler;
	el.onmousedown = mod_box_start;
	el.onmouseup = mod_ovGetExtent;
	el.onmousemove = mod_box_run;
	
	var ov_extent = mb_mapObj[ind].getExtentInfos();
	mb_mapObj[ind].isOverview = true;
	
	mb_mapObj[ind].skipWmsIfSrsNotSupported = 
		skipWmsIfSrsNotSupported === 1 ? true : false;

});

function mod_ovSetHandler(e){
	mb_isBF = 'overview';
	mb_zF = mod_overview_target;
}
function mod_ovGetExtent(e){
	mb_isBF = 'overview';
	mb_zF = mod_overview_target;
	mod_box_setValidClipping(mod_box_stop(e));
}

eventAfterMapRequest.register(function () {
	var targetMapObj = getMapObjByName(mod_overview_target);
	
	if (!targetMapObj) {
		return;
	}
	var arrayBBox = targetMapObj.extent.split(",");
	var minX = parseFloat(arrayBBox[0]);
	var minY = parseFloat(arrayBBox[1]);
	var maxX = parseFloat(arrayBBox[2]);
	var maxY = parseFloat(arrayBBox[3]);
	var mapObj = getMapObjByName("overview");
	var pointMin = mapObj.convertRealToPixel(new Point(minX, maxY)); 
	var pointMax = mapObj.convertRealToPixel(new Point(maxX, minY)); 
	var px1 = pointMin.x;
	var py1 = pointMin.y;
	var px2 = pointMax.x;
	var py2 = pointMax.y;

	mb_isBF = "overview";
	mb_zF = mod_overview_target;
	
	while((px2 - px1) < 8){
		px1 -= 1;
		px2 += 1;
	}
	while((py2 - py1) < 8){
		py1 -= 1;
		py2 += 1;
	}
	
	if(px1 < 0){px1 = 1;}
	if(px1 > mod_overview_width){px1 = mod_overview_width-1;}

	if(py1 < 0){py1 = 1;}
	if(py1 > mod_overview_height){py1 = mod_overview_height-1;}

	if(px2 > mod_overview_width){px2 = mod_overview_width-1;}
	if(px2 < 0){px2 = 1;}

	if(py2 > mod_overview_height){py2 = mod_overview_height-1;}
	if(py2 < 0){py2 = 1;}

	mb_drawBox(px1,py1,px2,py2);
});


