<?php
# $Id: mod_savewmc.php 264 2006-05-12 11:07:19Z vera_schulze 
# http://www.mapbender.org/index.php/mod_savewmc.php
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
include(dirname(__FILE__) . "/../include/dyn_js.php");

echo "mod_savewmc_target = '".$e_target[0]."';";
?>
function setOnUnload() {
	if (ie) {
		document.getElementsByTagName('body')[0].onunload = function() {
			var x = new Function ("", "mod_savewmc_session()"); x(); 
		};
	}
	else {
		document.getElementsByTagName('body')[0].setAttribute("onUnload", "mod_savewmc_session();");
	}
}

try {if (saveInSession) {}}catch(e) {saveInSession = 0;}

if (saveInSession == 1) {
	eventAfterMapRequest.register(function () {
		mod_savewmc_session();
	});
//	mb_registerInitFunctions('setOnUnload()');
}

<?php 
if ($e_src) {
	sprintf("var mod_savewmc_img = new Image(); 
			mod_savewmc_img.src = '%s';", $e_src);
}
?>
//var mod_savewmc_img_over = new Image(); mod_savewmc_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

function mod_savewmc_session(){
	sendMapDataToServer("session", 1, function(result, status) {});
}

function mod_savewmc(title){
	var generalTitle = title ? title : prompt("Save WMC as...");
	if (generalTitle != "" && generalTitle != null) {
		sendMapDataToServer(generalTitle, 0, function(result, status) {alert(status + ": " + result);});
	}
}

function sendMapDataToServer(generalTitle, storeInSession, callbackFunction) {
	var user = "<?php echo $_SESSION["mb_user_id"]; ?>";
	var ind = getMapObjIndexByName(mod_savewmc_target);
	
	var	extensionDataString = "";
	if (currentWmcExtensionData != null) {
		extensionDataString = $.toJSON(currentWmcExtensionData);
	}

	if (storeInSession) {
		$.ajaxSetup({async:false}); 
	}
	$.post("../php/mod_savewmc_server.php", {
		"saveInSession":storeInSession, 
		"generalTitle":generalTitle, 
		"extensionData":extensionDataString, 
		"mapObject":$.toJSON(mb_mapObj)
	}, callbackFunction);
}
