
var nameGeometryArray="GeometryArray";var nameMultiGeometry="MultiGeometry";var nameGeometry="Geometry";function GeomType(){this.polygon="polygon";this.line="line";this.point="point";}
var geomType=new GeomType();function GeometryArray(){this.addMember=function(geomType){this.add(new MultiGeometry(geomType));};this.name=nameGeometryArray;this.list=[];}
GeometryArray.prototype=new List();GeometryArray.prototype.getGeometry=function(i,j){var tmp=this.get(i);return tmp.get(j);};GeometryArray.prototype.getPoint=function(i,j,k,l){if(l==undefined){return this.get(i).get(j).get(k);}
return this.get(i).get(j).innerRings.get(k).get(l);};GeometryArray.prototype.union=function(geom){var oldLen=this.count();this.importGeoJSON(geom.toString());var j=0;for(var i=oldLen;i<this.count();i++){if(typeof geom.get(j).wfs_conf!=="undefined"){this.get(i).wfs_conf=geom.get(j).wfs_conf;}
j++;}
return this;};GeometryArray.prototype.findMultiGeometry=function(geom){var a=[];for(var i=0;i<this.count();i++){if(this.get(i).equals(geom)){a.push(i);}}
return a;};GeometryArray.prototype.delGeometry=function(i,j){if(this.get(i).del(j)===false){this.del(i);}};GeometryArray.prototype.delPoint=function(i,j,k,l){var res=this.get(i).delPoint(j,k,l);if(res===false){this.del(i);}};GeometryArray.prototype.close=function(){if(!this.get(-1).get(-1).close()){this.delGeometry(-1,-1);}
else{if(this.get(-1).get(-1).count()===0){this.get(-1).del(-1);}
if(this.get(-1).count()===0){this.del(-1);}}};GeometryArray.prototype.delAllPointsLike=function(point){var finished=false;while(finished===false){finished=true;for(var i=0;finished===true&&i<this.count();i++){for(var j=0;finished===true&&j<this.get(i).count();j++){var currentGeometry=this.get(i).get(j);if(currentGeometry.geomType==geomType.polygon&&currentGeometry.innerRings){for(var k=0;finished===true&&k<currentGeometry.innerRings.count();k++){for(var l=0;finished===true&&l<currentGeometry.innerRings.get(k).count();l++){if(this.getPoint(i,j,k,l).equals(point)){this.delPoint(i,j,k,l);finished=false;}}}}
if(!finished){break;}
for(var k=0;finished===true&&k<this.get(i).get(j).count();k++){if(this.getPoint(i,j,k).equals(point)){this.delPoint(i,j,k);finished=false;}}}}}};GeometryArray.prototype.updateAllPointsLike=function(oldP,newP){for(var i=0;i<this.count();i++){this.get(i).updateAllPointsLike(oldP,newP);}};GeometryArray.prototype.placemarkToString=function(placemarkId){var str="{\"type\": \"Feature\", \"geometry\": ";var geometriesFromPlacemark=[];for(var i=0,len=this.count();i<len;i++){if(this.get(i).isFromKml()&&this.get(i).e.getElementValueByName("Mapbender:placemarkId")==placemarkId){geometriesFromPlacemark.push(i);}}
if(geometriesFromPlacemark.length>1){str+="{\"type\": \"GeometryCollection\", \"geometries\": [";for(var i=0;i<geometriesFromPlacemark.length;i++){if(i>0){str+=",";}
str+=this.get(geometriesFromPlacemark[i]).placemarkToString();}
str+="]}";var propString=this.get(geometriesFromPlacemark[0]).e.toString();if(propString){str+=","+propString;}}
else if(geometriesFromPlacemark.length===1){str+=this.get(geometriesFromPlacemark[0]).placemarkToString();}
str+="}";return str;};GeometryArray.prototype.getBBox=function(){var q=this.get(0).get(0).get(0);var min=cloneObject(q);var max=cloneObject(q);for(var i=0;i<this.count();i++){var pos=this.get(i).getBBox();if(pos[0].x<min.x){min.x=pos[0].x;}
if(pos[1].x>max.x){max.x=pos[1].x;}
if(pos[1].y>max.y){max.y=pos[1].y;}
if(pos[0].y<min.y){min.y=pos[0].y;}}
return[min,max];};GeometryArray.prototype.importGeometryFromText=function(text,srs){var tmpArray=text.split("(");var geometryType=tmpArray[0];switch(geometryType){case"MULTIPOLYGON":var text=text.replace(/\)/g,"");var sepArray=text.split("(((");var polyArray=sepArray[1].split(",((");this.addMember(geomType.polygon);for(var i=0;i<polyArray.length;i++){var ringArray=polyArray[i].split(",(");for(var j=0;j<ringArray.length;j++){var coordinatesArray=ringArray[j].split(",");if(j===0){this.get(-1).addGeometry();for(var m=0;m<-1+coordinatesArray.length;m++){var currentPoint=coordinatesArray[m].split(" ");this.getGeometry(-1,-1).addPointByCoordinates(parseFloat(currentPoint[0]),parseFloat(currentPoint[1]));this.getGeometry(-1,-1).setEpsg(srs);}
this.close();}
else{var ring=new Geometry(geomType.polygon);for(var m=0;m<-1+coordinatesArray.length;m++){var currentPoint=coordinatesArray[m].split(" ");ring.addPointByCoordinates(parseFloat(currentPoint[0]),parseFloat(currentPoint[1]));}
ring.close();this.getGeometry(-1,-1).addInnerRing(ring);this.getGeometry(-1,-1).setEpsg(srs);}}}
break;}};GeometryArray.prototype.importPoint=function(currentGeometry,featureEpsg){var coordinates=currentGeometry.coordinates;this.addMember(geomType.point);this.get(-1).addGeometry();this.getGeometry(-1,-1).addPointByCoordinates(coordinates[0],coordinates[1],coordinates[2]);this.getGeometry(-1,-1).setEpsg(featureEpsg);this.close();};GeometryArray.prototype.importLine=function(currentGeometry,featureEpsg){var coordinates=currentGeometry.coordinates;this.addMember(geomType.line);this.get(-1).addGeometry();for(var m=0;m<coordinates.length;m++){var currentPoint=coordinates[m];this.getGeometry(-1,-1).addPointByCoordinates(currentPoint[0],currentPoint[1],currentPoint[2]);}
this.getGeometry(-1,-1).setEpsg(featureEpsg);this.close();};GeometryArray.prototype.importMultiLine=function(currentGeometry,featureEpsg){var coordinates=currentGeometry.coordinates;this.addMember(geomType.line);for(var m=0;m<coordinates.length;m++){this.get(-1).addGeometry();var currentLine=coordinates[m];for(var n=0;n<currentLine.length;n++){var currentPoint=currentLine[n];this.getGeometry(-1,-1).addPointByCoordinates(currentPoint[0],currentPoint[1],currentPoint[2]);}
this.getGeometry(-1,-1).setEpsg(featureEpsg);}
this.close();};GeometryArray.prototype.importMultiPoint=function(currentGeometry,featureEpsg){var coordinates=currentGeometry.coordinates;this.addMember(geomType.point);for(var m=0;m<coordinates.length;m++){this.get(-1).addGeometry();var currentPoint=coordinates[m];this.getGeometry(-1,-1).addPointByCoordinates(currentPoint[0],currentPoint[1],currentPoint[2]);this.getGeometry(-1,-1).setEpsg(featureEpsg);}
this.close();};GeometryArray.prototype.importPolygon=function(currentGeometry,featureEpsg){var coordinates=currentGeometry.coordinates;this.addMember(geomType.polygon);for(var m=0;m<coordinates.length;m++){this.get(-1).addGeometry();var currentPolygon=coordinates[m];for(var n=0;n<currentPolygon.length;n++){var currentPoint=currentPolygon[n];this.getGeometry(-1,-1).addPointByCoordinates(currentPoint[0],currentPoint[1],currentPoint[2]);}
this.getGeometry(-1,-1).setEpsg(featureEpsg);}
this.close();};GeometryArray.prototype.importMultiPolygon=function(currentGeometry,featureEpsg){var coordinates=currentGeometry.coordinates;this.addMember(geomType.polygon);for(var m=0;m<coordinates.length;m++){this.get(-1).addGeometry();var currentPolygon=coordinates[m];for(var n=0;n<currentPolygon.length;n++){var currentRing=currentPolygon[n];if(n==0){for(var p=0;p<currentRing.length;p++){var currentPoint=currentRing[p];this.getGeometry(-1,-1).addPointByCoordinates(currentPoint[0],currentPoint[1],currentPoint[2]);}}
else{var ring=new Geometry(geomType.polygon);for(var p=0;p<currentRing.length;p++){var currentPoint=currentRing[p];ring.addPointByCoordinates(currentPoint[0],currentPoint[1],currentPoint[2]);}
ring.close();this.getGeometry(-1,-1).addInnerRing(ring);}}
this.getGeometry(-1,-1).setEpsg(featureEpsg);}
this.close();};GeometryArray.prototype.importFeature=function(currentFeature){var isFeature=(currentFeature.type=="Feature")?true:false;if(currentFeature.geometry&&isFeature){var featureEpsg="EPSG:4326";if(!currentFeature.crs||currentFeature.crs.type!=="name"||!currentFeature.crs.properties.name){var e=new Mb_warning("SRS not set or unknown in GeoJSON. Using 'EPSG:4326'.");}
else{featureEpsg=currentFeature.crs.properties.name;}
var currentGeometry=currentFeature.geometry;var geometrytype=currentGeometry.type;switch(geometrytype){case"Point":this.importPoint(currentGeometry,featureEpsg);break;case"MultiPoint":this.importMultiPoint(currentGeometry,featureEpsg);break;case"LineString":this.importLine(currentGeometry,featureEpsg);break;case"MultiLineString":this.importMultiLine(currentGeometry,featureEpsg);break;case"Polygon":this.importPolygon(currentGeometry,featureEpsg);break;case"MultiPolygon":this.importMultiPolygon(currentGeometry,featureEpsg);break;case"GeometryCollection":var exc=new Mb_exception("Geometry: GeometryCollections are not yet supported");break;}}
if(currentFeature.properties){var properties=currentFeature.properties;if(geometrytype!="GeometryCollection"){for(var l in properties){if(typeof(properties[l])!="function"){this.get(-1).e.setElement(l,properties[l]);}}
this.get(-1).e.setElement("fid",currentFeature.id);}}}
GeometryArray.prototype.importGeoJSON=function(geoJSON){if(typeof(geoJSON)=='string'){var geoJSON=eval('('+geoJSON+')');}
var isFeatureCollection=(geoJSON.type=="FeatureCollection")?true:false;switch(geoJSON.type){case"FeatureCollection":var featureArray=geoJSON.features;for(var j=0;j<featureArray.length;j++){var currentFeature=featureArray[j];this.importFeature(currentFeature);}
break;case"Feature":this.importFeature(geoJSON);break;}
return true;}
GeometryArray.prototype.featureToString=function(i){var str="{\"type\": \"FeatureCollection\", \"features\": [";str+=this.get(i).toString();str+="]}";return str;};GeometryArray.prototype.toString=function(){var str="{\"type\": \"FeatureCollection\", \"features\": [";var multiGeometriesFromKml=[];var multiGeometriesNotFromKml=[];for(var i=0,len=this.count();i<len;i++){if(this.get(i).isFromKml()){var placemarkId=this.get(i).e.getElementValueByName("Mapbender:placemarkId");var isFound=false;for(var j=0;j<multiGeometriesFromKml&&isFound===false;j++){if(multiGeometriesFromKml==placemarkId){isFound=true;}}
if(!isFound){multiGeometriesFromKml.push(placemarkId);}}
else{multiGeometriesNotFromKml.push(i);}}
for(var i=0,len=multiGeometriesNotFromKml.length;i<len;i++){if(i>0){str+=",";}
str+=this.get(multiGeometriesNotFromKml[i]).toString();}
if(multiGeometriesNotFromKml.length>0&&multiGeometriesFromKml.length>0){str+=",";}
for(var i=0;i<multiGeometriesFromKml.length;i++){if(i>0){str+=",";}
str+=this.placemarkToString();}
str+="]}";return str;};function MultiGeometry(geomType){this.addGeometry=function(){this.add(new Geometry(this.geomType));};this.del=function(i){i=this.getIndex(i);if(i!==false){var tmpLength=this.count()-1;for(var z=i;z<tmpLength;z++){this.list[z]=this.list[z+1];}
this.list.length-=1;if(this.list.length===0){return false;}}
return true;};this.list=[];this.e=new Wfs_element();this.geomType=geomType;this.name=nameMultiGeometry;}
MultiGeometry.prototype=new List();MultiGeometry.prototype.updateAllPointsLike=function(oldP,newP){for(var i=0;i<this.count();i++){this.get(i).updateAllPointsLike(oldP,newP);}};MultiGeometry.prototype.getBBox=function(){var q=this.get(0).get(0);var min=cloneObject(q);var max=cloneObject(q);for(var i=0;i<this.count();i++){var pos=this.get(i).getBBox();if(pos[0].x<min.x){min.x=pos[0].x;}
if(pos[1].x>max.x){max.x=pos[1].x;}
if(pos[1].y>max.y){max.y=pos[1].y;}
if(pos[0].y<min.y){min.y=pos[0].y;}}
return[min,max];};MultiGeometry.prototype.getBBox4=function(){var bbox=this.getBBox();var realBox=new MultiGeometry(geomType.polygon);realBox.addGeometry(geomType.polygon);realBox.get(-1).addPointByCoordinates(bbox[0].x,bbox[0].y);realBox.get(-1).addPointByCoordinates(bbox[0].x,bbox[1].y);realBox.get(-1).addPointByCoordinates(bbox[1].x,bbox[1].y);realBox.get(-1).addPointByCoordinates(bbox[1].x,bbox[0].y);realBox.get(-1).close();return realBox;};MultiGeometry.prototype.getCenter=function(){var tmp=this.getBBox();var x=parseFloat(tmp[0].x)+parseFloat((tmp[1].x-tmp[0].x)/2);var y=parseFloat(tmp[0].y)+parseFloat((tmp[1].y-tmp[0].y)/2);return new Point(x,y);};MultiGeometry.prototype.getTotalPointCount=function(){var c=0;for(var i=0;i<this.count();i++){c+=this.get(i).count();}
return c;};MultiGeometry.prototype.getPoint=function(j,k){return this.get(j).get(k);};MultiGeometry.prototype.equals=function(multigeom){if(this.geomType!=multigeom.geomType){return false;}
if(this.count()!=multigeom.count()){return false;}
if(this.getTotalPointCount()!=multigeom.getTotalPointCount()){return false;}
for(var i=0;i<this.count();i++){if(!this.get(i).equals(multigeom.get(i))){return false;}}
return true;};MultiGeometry.prototype.delPoint=function(i,j,k){var res;if(k==undefined){res=this.get(i).del(j);if(res===false){return this.del(i);}}
else{res=this.get(i).innerRings.get(j).del(k);if(res===false){this.get(i).innerRings.del(j);}}
return true;};MultiGeometry.prototype.isFromKml=function(){if(this.e.getElementValueByName("Mapbender:kml")){return true;}
return false;};MultiGeometry.prototype.toText=function(){var text="";var numOfGeom=this.count();if(numOfGeom>=1){if(this.geomType==geomType.polygon){if(numOfGeom>1){text+="MULTIPOLYGON (";for(var i=0;i<numOfGeom;i++){if(i>0){text+=", ";}
var currentPolygon=this.get(i);text+="("+currentPolygon.toText()+")";}
text+=")";}
else{text+="POLYGON ("+this.get(0).toText()+")";}}
else if(this.geomType==geomType.line){text+="LINESTRING (";var currentLine=this.get(0);for(var j=0;j<currentLine.count();j++){if(j>0){text+=", ";}
var currentPoint=currentLine.get(j);text+=currentPoint.x+" "+currentPoint.y}
text+=")";}}
return text;};MultiGeometry.prototype.toString=function(){var str=this.toStringWithoutProperties();var propString=this.e.toString();if(propString){str+=","+propString;}
var fid=this.e.getElementValueByName("fid");if(fid){str+=", \"id\":\""+fid+"\"";}
str+="}";return str;};MultiGeometry.prototype.placemarkToString=function(){var str="";for(var i=0,len=this.count();i<len;i++){if(i>0){str+=",";}
str+=this.get(i).toString();}
return str;};MultiGeometry.prototype.toStringWithoutProperties=function(){var str="{\"type\": \"Feature\", ";var epsg=this.getEpsg();if(epsg){str+="\"crs\": {\"type\": \"name\", \"properties\": {\"name\": \""+epsg+"\"}}, ";}
str+="\"geometry\": {";var len=this.count();switch(this.geomType){case geomType.polygon:if(len>1){str+="\"type\": \"MultiPolygon\", ";}
else{str+="\"type\": \"Polygon\", ";}
break;case geomType.line:if(len>1){str+="\"type\": \"MultiLineString\", ";}
else{str+="\"type\": \"LineString\", ";}
break;case geomType.point:if(len>1){str+="\"type\": \"MultiPoint\", ";}
else{str+="\"type\": \"Point\", ";}
break;}
str+="\"coordinates\": "
if(len>1){str+="[";for(var i=0;i<len;i++){if(i>0){str+=",";}
str+=this.get(i).toString();}
str+="]";}
else{str+=this.get(0).toString();}
str+="}";return str;};MultiGeometry.prototype.getEpsg=function(){if(this.count()>0){return this.get(0).getEpsg();}
return false;};function InnerRings(){this.list=[];};InnerRings.prototype=new List();function Geometry(aGeomtype){this.del=function(i){i=this.getIndex(i);if(i!==false){var tmpLength=this.count()-1;for(var z=i;z<tmpLength;z++){this.list[z]=this.list[z+1];}
this.list.length-=1;if(this.geomType==geomType.polygon){if(i==tmpLength){this.list[0]=this.list[tmpLength-1];}
else if(i===0){this.list[tmpLength-1]=this.list[0];}
if(this.list.length==1){return false;}}
updateDist();if(this.list.length===0){return false;}
return true;}
return false;};this.addPointByCoordinates=function(x,y,z){var newPoint=new Point(x,y,z);this.add(newPoint);};this.addPoint=function(aPoint){this.add(new Point(aPoint.x,aPoint.y,aPoint.z));updateDist();};this.addPointAtIndex=function(p,i){i=this.getIndex(i);if(i!==false){for(var z=this.count();z>i;z--){this.list[z]=this.list[z-1];}
this.list[i]=new Point(p.x,p.y,p.z);updateDist();}};this.updatePointAtIndex=function(p,i){i=this.getIndex(i);if((i===0||i==this.count()-1)&&this.geomType==geomType.polygon){this.list[0]=p;this.list[this.count()-1]=p;}
else{this.list[i]=p;}
updateDist();};var updateDist=function(){};this.getCurrentDist=function(numberOfDigits){if(typeof(numberOfDigits)=="number"){return roundToDigits(dist[this.count()-1],numberOfDigits);}
return dist[this.count()-1];};this.getTotalDist=function(numberOfDigits){if(typeof(numberOfDigits)=="number"){return roundToDigits(totaldist[this.count()-1],numberOfDigits);}
return totaldist[this.count()-1];};this.close=function(){complete=true;if(this.geomType==geomType.polygon){if(this.count()>2){if(!this.get(0).equals(this.get(-1))){this.addPoint(this.get(0));}}
else{return false;}}
if(this.geomType==geomType.line){if(this.count()<2){return false;}}
return true;};this.isComplete=function(){return complete;};this.setEpsg=function(someEpsg){epsg=someEpsg;return true;var e=new Mb_exception("EPSG code not valid ("+someEpsg+")");return false;};this.getEpsg=function(){return epsg;};this.list=[];var dist=[];var totaldist=[];var complete=false;var epsg;var that=this;this.geomType=aGeomtype;this.name=nameGeometry;if(this.geomType==geomType.polygon){this.innerRings=new InnerRings();this.addInnerRing=function(somePolygon){this.innerRings.add(somePolygon);};this.delInnerRing=function(index){this.innerRings.del(index);};}}
Geometry.prototype=new List();Geometry.prototype.toText=function(){var text="";switch(this.geomType){case geomType.polygon:text+="(";for(var j=0;j<this.count();j++){if(j>0){text+=", ";}
var currentPoint=this.get(j);text+=currentPoint.x+" "+currentPoint.y}
text+=")";if(this.innerRings&&this.innerRings.count()>0){for(var k=0;k<this.innerRings.count();k++){text+=", ";text+=this.innerRings.get(k).toText();}}
break;}
return text;};Geometry.prototype.getBBox=function(){var q=this.get(0);var min=cloneObject(q);var max=cloneObject(q);for(var j=0;j<this.count();j++){var pos=this.get(j);if(pos.x<min.x){min.x=pos.x;}
else if(pos.x>max.x){max.x=pos.x;}
if(pos.y<min.y){min.y=pos.y;}
else if(pos.y>max.y){max.y=pos.y;}}
if(this.geomType==geomType.polygon){for(var i=0;i<this.innerRings.count();i++){var currentRing=this.innerRings.get(i);for(var j=0;j<currentRing.count();j++){var pos=currentRing.get(j);if(pos.x<min.x){min.x=pos.x;}
else if(pos.x>max.x){max.x=pos.x;}
if(pos.y<min.y){min.y=pos.y;}
else if(pos.y>max.y){max.y=pos.y;}}}}
return[min,max];};Geometry.prototype.updateAllPointsLike=function(oldP,newP){var len=this.count();for(var i=0;i<len;i++){if(oldP.equals(this.get(i))){if(i>0&&newP.equals(this.get(i-1))){this.del(i);len--;i--;}
else{this.updatePointAtIndex(newP,i);}}}
if(this.geomType==geomType.polygon){for(var j=0;j<this.innerRings.count();j++){var len=this.innerRings.get(j).count();for(var i=0;i<len;i++){if(oldP.equals(this.innerRings.get(j).get(i))){if(i>0&&newP.equals(this.innerRings.get(j).get(i-1))){this.innerRings.get(j).del(i);len--;i--;}
else{this.innerRings.get(j).updatePointAtIndex(newP,i);}}}}}};Geometry.prototype.equals=function(geom){if(this.geomType!=geom.geomType){return false;}
if(this.count()!=geom.count()){return false;}
for(var i=0;i<this.count();i++){if(!this.get(i).equals(geom.get(i))){return false;}}
if(!this.innerRings&&!geom.innerRings){}
else if(this.innerRings&&geom.innerRings){if(this.innerRings.count()!=geom.innerRings.count()){return false;}
for(var j=0;j<this.innerRings.count();j++){if(!this.innerRings.get(j).equals(geom.innerRings.get(j))){return false;}}}
else{return false;}
return true;};Geometry.prototype.bufferLine=function(bufferX,bufferY){if(typeof(bufferY)=='undefined')
bufferY=bufferX;if(this.geomType!=geomType.line||this.count()<2)
return false;var ret=new Geometry(geomType.polygon)
last_vec=this.get(1).minus(this.get(0));last_vec_o=new Point(-last_vec.y,last_vec.x);last_vec_o=last_vec_o.dividedBy(last_vec_o.dist(new Point(0,0)));last_vec_o.x*=bufferX;last_vec_o.y*=bufferY;last_vec=last_vec.dividedBy(last_vec.dist(new Point(0,0)));last_vec.x*=bufferX;last_vec.y*=bufferY;ret.list.unshift(this.get(0).plus(last_vec_o).minus(last_vec));ret.list.push(this.get(0).minus(last_vec_o).minus(last_vec));for(var i=1;i<this.count()-1;i++){vec=this.get(i+1).minus(this.get(i));vec_o=new Point(-vec.y,vec.x);vec_o=vec_o.dividedBy(vec_o.dist(new Point(0,0)));vec_o.x*=bufferX;vec_o.y*=bufferY;vec=vec.dividedBy(vec.dist(new Point(0,0)));vec.x*=bufferX;vec.y*=bufferY;if(vec.equals(last_vec))
continue;var angle=(Math.atan2(vec.x,vec.y)-Math.atan2(last_vec.x,last_vec.y))
if(angle<-Math.PI)angle=2*Math.PI+angle;if(angle>+Math.PI)angle=2*Math.PI-angle;var ndist=1/(Math.cos(angle/2))
var int_vec=vec_o.plus(last_vec_o);int_vec=int_vec.times(ndist/int_vec.dist(new Point(0,0)));int_vec.x*=bufferX;int_vec.y*=bufferY;if(angle>Math.PI/2){ret.list.unshift(this.get(i).plus(last_vec_o).plus(last_vec));ret.list.unshift(this.get(i).plus(vec_o).minus(vec));}
else{ret.list.unshift(this.get(i).plus(int_vec));}
if(angle<-Math.PI/2){ret.list.push(this.get(i).minus(last_vec_o).plus(last_vec));ret.list.push(this.get(i).minus(vec_o).minus(vec));}
else{ret.list.push(this.get(i).minus(int_vec));}
last_vec=vec;last_vec_o=vec_o;}
ret.list.unshift(this.get(i).plus(last_vec_o).plus(last_vec));ret.list.push(this.get(i).minus(last_vec_o).plus(last_vec));ret.close();return ret;}
Geometry.prototype.toString=function(){var str="";if(this.geomType==geomType.polygon){str+="[[";for(var i=0;i<this.count();i++){if(i>0){str+=", ";}
str+=this.get(i).toString();}
if(typeof(this.innerRings)=="object"&&this.innerRings.count()>0){for(var j=0;j<this.innerRings.count();j++){var currentRing=this.innerRings.get(j);str+="],[";for(var i=0;i<currentRing.count();i++){if(i>0){str+=", ";}
str+=currentRing.get(i).toString();}}}
str+="]]";}
else if(this.geomType==geomType.line){str+="[";for(var i=0;i<this.count();i++){if(i>0){str+=", ";}
str+=this.get(i).toString();}
str+="]";}
else if(this.geomType==geomType.point){str+=this.get(0).toString();}
return str;};function Wfs_element(){this.count=function(){return this.name.length;};this.getName=function(i){if(this.isValidElementIndex(i)){return this.name[i];}
return false;};this.getValue=function(i){if(this.isValidElementIndex(i)){return this.value[i];}
return false;};this.setElement=function(aName,aValue){var i=this.getElementIndexByName(aName);if(i===false){i=this.count();}
this.name[i]=aName;this.value[i]=aValue;};this.delElement=function(aName){var i=this.getElementIndexByName(aName);if(i!==false){this.name.splice(i,1);this.value.splice(i,1);}}
this.isValidElementIndex=function(i){if(i>=0&&i<this.name.length){return true;}
var e=new Mb_exception("class Wfs_element: function isValidElementIndex: illegal element index");return false;};this.name=[];this.value=[];}
Wfs_element.prototype.getElementIndexByName=function(elementName){for(var j=0,len=this.count();j<len;j++){if(this.getName(j)==elementName){return j;}}
return false;};Wfs_element.prototype.getElementValueByName=function(elementName){var i=this.getElementIndexByName(elementName);if(i===false){return false;}
return this.getValue(i);};Wfs_element.prototype.toString=function(){var str="";if(this.count()>0){str+="\"properties\": {";for(i=0,len=this.count();i<len;i++){if(i>0){str+=",";}
var key=this.getName(i);var value=this.getValue(i);str+="\""+key+"\":\""+value+"\"";}
str+="}";}
return str;};function Canvas(aMapframe,aTagName,aStyle,aLineWidth){this.drawGeometry=function(t,g,col){var mapframeWidth=mb_mapObj[mapObjInd].width;var mapframeHeight=mb_mapObj[mapObjInd].height;if(t==geomType.point){var poiIcon=g.e.getElementValueByName("Mapbender:icon");for(var i=0,ilen=g.count();i<ilen;i++){var currentGeom=g.get(i);var p=realToMap(mapframe,currentGeom.get(0));var px=p.x;var py=p.y;var radius=diameter/2;if((px-radius<mapframeWidth&&px+radius>0&&py-radius<mapframeHeight&&py+radius>0)||(p.dist(new Point(0,0))<radius||p.dist(new Point(mapframeWidth,mapframeHeight))<radius||p.dist(new Point(0,mapframeHeight))<radius||p.dist(new Point(mapframeWidth,0))<radius)){if(poiIcon){displayIcon(poiIcon,px,py);}
else{drawCircle(px-1,py-1,diameter,col);}}}}
else if(t==geomType.line||t==geomType.polygon){for(var i=0,ilen=g.count();i<ilen;i++){var currentGeom=g.get(i);if(t==geomType.polygon&&currentGeom.innerRings.count()>0){for(var k=0;k<currentGeom.innerRings.count();k++){var currentRing=currentGeom.innerRings.get(k);var previousPoint=realToMap(mapframe,currentRing.get(0));for(var j=1,jlen=currentRing.count();j<jlen;j++){(function(){var currentPoint=realToMap(mapframe,currentRing.get(j));var pq=calculateVisibleDash(previousPoint,currentPoint,mapframeWidth,mapframeHeight);if(pq){drawLine([pq[0].x-1,pq[1].x-1],[pq[0].y-1,pq[1].y-1],col);}
previousPoint=currentPoint;})();}}}
var previousPoint=realToMap(mapframe,currentGeom.get(0));for(var j=1,jlen=currentGeom.count();j<jlen;j++){(function(){var currentPoint=realToMap(mapframe,currentGeom.get(j));var pq=calculateVisibleDash(previousPoint,currentPoint,mapframeWidth,mapframeHeight);if(pq){drawLine([pq[0].x-1,pq[1].x-1],[pq[0].y-1,pq[1].y-1],col);}
previousPoint=currentPoint;})();}}}
else{var e=new Mb_exception("class Canvas: function drawGeometry: unknown geomType "+t);}};this.isTooSmall=function(g){var tmp=g.getBBox();var min=realToMap(mapframe,tmp[0]);var max=realToMap(mapframe,tmp[1]);if((Math.abs(max.x-min.x)<minWidth)&&(Math.abs(max.y-min.y)<minWidth)){return true;}
return false;};this.getCanvas=function(){return canvas;};this.setDiameter=function(px){diameter=px;};var drawCircle=function(x,y,diameter,color){canvas.setColor(color);canvas.drawEllipse(x-diameter/2,y-diameter/2,diameter,diameter);};var drawLine=function(x_array,y_array,color){canvas.setColor(color);canvas.drawPolyline(x_array,y_array);};var displayIcon=function(url,x,y){if(ie){var newImg=document.createElement("img");var newImgTop=y-Math.round(80/2);var newImgLeft=x-Math.round(80/2);that.canvasDivTag.getTag().innerHTML="<img src='"+url+"' style='position:absolute;top:"+newImgTop+";left:"+newImgLeft+";z-index:100'/>";}
else{var newImg=document.createElement("img");newImg.src=url;that.canvasDivTag.getTag().appendChild(newImg);newImg.style.position="absolute";newImg.style.top=y-Math.round(80/2);newImg.style.left=x-Math.round(80/2);newImg.style.zIndex=100;}};var mapframe=aMapframe;var mapObjInd=getMapObjIndexByName(mapframe);if(mb_mapObj[mapObjInd].getDomElement().frameName){this.canvasDivTag=new DivTag(aTagName,mapName,aStyle);}
else{this.canvasDivTag=new DivTag(aTagName,"",aStyle,mb_mapObj[mapObjInd].getDomElement());}
var that=this;var diameter=8;var minWidth=8;var lineWidth=aLineWidth||2;var style=aStyle;var canvas=new jsGraphics(aTagName,mb_mapObj[mapObjInd].getDomElement().frameName?window.frames[mapframe]:window);canvas.setStroke(lineWidth);mb_registerPanSubElement(aTagName);}
Canvas.prototype.clean=function(){this.canvasDivTag.clean();};Canvas.prototype.paint=function(gA){for(var q=0;q<gA.count();q++){var m=gA.get(q);var t=m.geomType;var col=m.color;if(t==geomType.point){this.drawGeometry(t,m,col);}
else{if(this.isTooSmall(m)){var newMember=new MultiGeometry(geomType.point);newMember.addGeometry();newMember.get(-1).addPoint(m.getCenter());this.drawGeometry(geomType.point,newMember,col);}
else{if(t==geomType.line){this.drawGeometry(t,m,col);}
else if(t==geomType.polygon){this.drawGeometry(t,m,col);}
else{var e=new Mb_exception("class Canvas: function paint: unknown geomType"+t);}}}}
this.getCanvas().paint();};function Highlight(aTargetArray,aTagName,aStyle,aLineWidth){this.del=function(m,color){var newMultiGeom;if(m.name==nameMultiGeometry){newMultiGeom=m;}
else if(m.name==nameGeometry){var newMultiGeom=new MultiGeometry(m.geomType);newMultiGeom.add(m);}
var a=gA.findMultiGeometry(newMultiGeom);var del=false;for(var i=0;i<a.length&&del===false;i++){if(gA.get(a[i]).color==color){gA.del(a[i]);del=true;}}};this.add=function(m,color){if(m.name==nameMultiGeometry){gA.addCopy(m);}
else if(m.name==nameGeometry){var newMultiGeom=new MultiGeometry(m.geomType);newMultiGeom.add(m);gA.addCopy(newMultiGeom);}
if(typeof(color)!='undefined'){gA.get(-1).color=color;}
else{gA.get(-1).color=lineColor;}};this.hide=function(){for(var i=0;i<canvas.length;i++){if(typeof(canvas[i])=="object"){canvas[i].clean();}}};this.clean=function(){if(gA.count()>0){gA=new GeometryArray();this.paint();}};this.paint=function(){this.hide();for(var i=0;i<canvas.length;i++){if(typeof(canvas[i])=="object"){canvas[i].clean();}}
for(var i=0;i<targets.length;i++){if(typeof(canvas[i])=='undefined'){canvas[i]=new Canvas(targets[i],tagname+i,style,lineWidth);}
canvas[i].paint(gA);}};this.setDiameter=function(radius){for(var i=0;i<targets.length;i++){if(typeof(canvas[i])!="undefined"){canvas[i].setDiameter(radius);}}}
this.setMouseOver=function(callback){for(var i=0;i<targets.length;i++){if(typeof(canvas[i])!=='undefined'){canvas[i].canvasDivTag.getTag().onmouseover=function(e){callback(e);};}}};this.setMouseOut=function(callback){for(var i=0;i<targets.length;i++){if(typeof(canvas[i])!=='undefined'){canvas[i].canvasDivTag.getTag().onmouseout=function(e){callback(e);};}}};this.setMouseClick=function(callback){for(var i=0;i<targets.length;i++){if(typeof(canvas[i])!=='undefined'){canvas[i].canvasDivTag.getTag().onclick=function(e){callback(e);};}}};var lineWidth=aLineWidth;var tagname='mod_gaz_draw'+aTagName;var style=aStyle;var targets=aTargetArray;var canvas=[];var gA=new GeometryArray();var lineColor="#ff0000";this.paint();}
function Snapping(aTarget,aTolerance,aColor,aZIndex){this.draw=function(center,radius){mG=new MultiGeometry(geomType.point);mG.addGeometry();mG.get(-1).addPoint(center);highlight.add(mG,snappingColor);highlight.paint();};this.getTolerance=function(){return tolerance;};this.getTarget=function(){return target;};this.cleanHighlight=function(){return highlight.clean();};this.addPoint=function(aPoint){coord.push(aPoint);};this.getPointCount=function(){return coord.length;};this.getPoint=function(i){return coord[i];};this.resetPoints=function(){coord=[];};this.getNearestNeighbour=function(){if(min_i!=-1){return this.getPoint(min_i);}
return false;};this.setIndexOfNearestNeighbour=function(i){min_i=i;};this.resetIndexOfNearestNeighbour=function(){min_i=-1;};var tolerance=(typeof(aTolerance)=='undefined')?10:aTolerance;var zIndex=(typeof(aZIndex)=='undefined')?50:aZIndex;var coord=[];var min_i=-1;var target=aTarget;var snappingColor=aColor;var lineWidth=2;var style={"position":"absolute","top":"0px","left":"0px","z-index":zIndex};var highlight=new Highlight([target],"snapping"+Math.round(Math.random()*Math.pow(10,10)),style,lineWidth);}
Snapping.prototype.check=function(currPoint){var minDist=false;for(var i=0;i<this.getPointCount();i++){var currDist=currPoint.dist(realToMap(this.getTarget(),this.getPoint(i)));if(minDist===false||currDist<minDist){minDist=currDist;if(minDist<this.getTolerance()){this.setIndexOfNearestNeighbour(i);}}}
if(this.getPointCount()>0&&minDist>this.getTolerance()){this.resetIndexOfNearestNeighbour();}
this.cleanHighlight();if(this.isSnapped()){this.draw(this.getNearestNeighbour(),this.getTolerance());}};Snapping.prototype.store=function(geom,point){this.resetPoints();this.resetIndexOfNearestNeighbour();for(var i=0;i<geom.count();i++){if(geom.name==nameGeometryArray||geom.name==nameMultiGeometry){for(var j=0;j<geom.get(i).count();j++){if(geom.get(i).name==nameMultiGeometry){if(geom.get(i).get(j).geomType==geomType.polygon&&geom.get(i).get(j).innerRings&&geom.get(i).get(j).innerRings.count()>0){for(var l=0;l<geom.get(i).get(j).innerRings.count();l++){var currentRing=geom.get(i).get(j).innerRings.get(l);for(var k=0;k<currentRing.count();k++){if((currentRing.isComplete()===true&&typeof(point)=='undefined')||(typeof(point)!='undefined'&&!currentRing.get(k).equals(point))){this.add(currentRing.get(k));}}}}
for(var k=0;k<geom.get(i).get(j).count();k++){if((geom.get(i).get(j).isComplete()===true&&typeof(point)=='undefined')||(typeof(point)!='undefined'&&!geom.get(i).get(j).get(k).equals(point))){this.add(geom.getPoint(i,j,k));}}}
else{if((geom.get(i).isComplete()===true&&typeof(point)=='undefined')||(typeof(point)!='undefined'&&!geom.get(i).get(j).get(k).equals(point))){this.add(geom.getPoint(i,j));}}}}
else{if(typeof(point)!='undefined'&&!geom.get(i).get(j).get(k).equals(point)){this.add(geom.get(i));}}}};Snapping.prototype.isSnapped=function(){if(this.getNearestNeighbour()!==false){return true;}
return false;};Snapping.prototype.getSnappedPoint=function(){return this.getNearestNeighbour();};Snapping.prototype.add=function(aPoint){this.addPoint(aPoint);};Snapping.prototype.clean=function(){this.cleanHighlight();};function calculateVisibleDash(p0,p1,width,height){if(p0.x>p1.x){var p_temp=p0;p0=p1;p1=p_temp;p_temp=null;}
var p=p0;var q=p1;var m;var ix;var iy;if(p1.x!=p0.x){m=-(p1.y-p0.y)/(p1.x-p0.x);if(p0.x<width&&p1.x>0&&!(p0.y<0&&p1.y<0)&&!(p0.y>height&&p1.y>height)){if(p0.x<0){iy=p0.y-m*(0-p0.x);if(iy>0&&iy<height){p=new Point(0,iy);}
else if(iy>height){ix=p0.x+((p0.y-height)/m);if(ix>0&&ix<width){p=new Point(ix,height);}else{return false;}}
else if(iy<0){ix=p0.x+(p0.y/m);if(ix>0&&ix<width){p=new Point(ix,0);}else{return false;}}
else{return false;}}
else if(p0.y>=0&&p0.y<=height){p=p0;}
else if(p0.y<0){ix=p0.x+(p0.y/m);if(ix>0&&ix<width){p=new Point(ix,0);}else{return false;}}
else if(p0.y>height&&m>0){ix=p0.x+((p0.y-height)/m);if(ix>0&&ix<width){p=new Point(ix,height);}else{return false;}}
else{return false;}
if(p1.x>width){iy=p1.y-m*(width-p1.x);if(iy>0&&iy<height){q=new Point(width,iy);}
else if(iy<0){ix=p0.x+(p0.y/m);if(ix>0&&ix<width){q=new Point(ix,0);}else{return false;}}
else if(iy>height){ix=p0.x+((p0.y-height)/m);if(ix>0&&ix<width){q=new Point(ix,height);}else{return false;}}
else{return false;}}
else if(p1.y>=0&&p1.y<=height){q=p1;}
else if(p1.y<0){ix=p1.x+(p1.y/m);if(ix>0&&ix<width){q=new Point(ix,0);}else{return false;}}
else if(p1.y>height){ix=p1.x+((p1.y-height)/m);if(ix>0&&ix<width){q=new Point(ix,height);}else{return false;}}}
else{return false;}}
else{if(!(p0.y<0&&p1.y<0)&&!(p0.y>height&&p1.y>height)){if(p0.y<0){p=new Point(p0.x,0);}
else if(p0.y>height){p=new Point(p0.x,height);}
else{p=p0;}
if(p1.y<0){q=new Point(p0.x,0);}
else if(p1.y>height){q=new Point(p0.x,height);}
else{q=p1;}}
else{return false;}}
return[new Point(Math.round(q.x),Math.round(q.y)),new Point(Math.round(p.x),Math.round(p.y))];}
function objString(a){var z="";for(attr in a){var b=a[attr];if(typeof(b)=="object"){z+=objString(b);}
else{z+=attr+" "+b+"\n";}}
return z;}