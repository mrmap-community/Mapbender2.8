<?php
# $Id: mod_pan.php 3861 2009-04-07 15:52:47Z christoph $
# http://www.mapbender.org/index.php/mod_pan.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
echo "var mod_pan_target = '".$e_target[0]."';";
?>
var mod_pan_elName = "pan1";
var mod_pan_frameName = "";
var mod_pan_MapObj = null;

var mod_pan_img_on = new Image(); mod_pan_img_on.src = "<?php  echo preg_replace("/_off/","_on",$e_src);  ?>";
var mod_pan_img_off = new Image(); mod_pan_img_off.src = "<?php  echo $e_src;  ?>";
var mod_pan_img_over = new Image(); mod_pan_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";


var mb_panActive = false;

function init_mod_pan(ind){
	mod_pan_MapObj = getMapObjByName(mod_pan_target);
	mb_button[ind] = document.getElementById(mod_pan_elName);
	mb_button[ind].img_over = mod_pan_img_over.src;
	mb_button[ind].img_on = mod_pan_img_on.src;
	mb_button[ind].img_off = mod_pan_img_off.src;
	mb_button[ind].status = 0;
	mb_button[ind].elName = mod_pan_elName;
	mb_button[ind].fName = mod_pan_frameName;
	mb_button[ind].go = new Function ("mod_pan_click()");
	mb_button[ind].stop = new Function ("mod_pan_disable()");
}
function mod_pan_click(){   
	var p = mod_pan_MapObj.getDomElement();
	p.style.cursor = "pointer";
	
	p.onmousedown = mod_pan_start;
	p.onmouseup = mod_pan_stop;
	p.onmousemove = mod_pan_run;
}
function mod_pan_disable(){
	var p = mod_pan_MapObj.getDomElement();
	p.style.cursor = "pointer";

	p.onmousedown = null;
	p.onmouseup = null;
	p.onmousemove = null;
}
function mod_pan_start(e){
	mb_panActive = true;
	var pos = mod_pan_MapObj.getMousePosition(e);
	var el = mod_pan_MapObj.getDomElement();
	mb_start_x=pos.x;
	mb_start_y=pos.y;
	mb_end_x = pos.x;
	mb_end_y = pos.y; 
	return false;
}
function mod_pan_run(e){
	if(mb_panActive){
		var pos = mod_pan_MapObj.getMousePosition(e);
		mb_end_x = pos.x;
		mb_end_y = pos.y;
		mod_pan_move_map();
		if(ie){
			return false;
		}
		else{
			return true;
		}
	}
}
function mod_pan_stop(e){
	if(mb_panActive){
		mb_panActive = false;
		var dif_x = mb_end_x - mb_start_x;
		var dif_y = mb_end_y - mb_start_y;
		var width = mod_pan_MapObj.width;
		var height = mod_pan_MapObj.height;      
	
		var el = mod_pan_MapObj.getDomElement();
		var center_x = (width / 2)  - dif_x;
		var center_y = (height / 2) - dif_y;
		var real_center = makeClickPos2RealWorldPos(mod_pan_target,center_x, center_y);   
	
		mb_arrangeElement(mod_pan_MapObj.frameName, mod_pan_target+"_maps", 0, 0);
		for(var i=0; i<mb_PanSubElements.length; i++){
			mb_arrangeElement(mod_pan_MapObj.frameName, mb_PanSubElements[i], 0, 0);
		} 
	   zoom(mod_pan_target,false, 1.0, real_center[0], real_center[1]);   
	}
}
function mod_pan_move_map(){
	var dif_x = mb_end_x - mb_start_x;
	var dif_y = mb_end_y - mb_start_y;
	
	mb_arrangeElement(mod_pan_MapObj.frameName, mod_pan_target+"_maps", dif_x, dif_y);
	for(var i=0; i<mb_PanSubElements.length; i++){
		mb_arrangeElement(mod_pan_MapObj.frameName, mb_PanSubElements[i], dif_x, dif_y);
	} 
	return false;  
}
