<?php
# $Id: mod_dependentIframe.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/mod_dependentIframe.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
echo "var mod_dependentIframe_target = '".$e_target[0]."';";
?>
mod_dependentIframe_offsetLeft = 10;
mod_dependentIframe_offsetTop = 10;

parent.mb_registerSubFunctions("mod_dependentIframe()");

function mod_dependentIframe(){
	var obj = document.getElementById(mod_dependentIframe_target).style;
	var thisObj = document.getElementById('dependentIframe').style; 
	thisObj.left = parseInt(obj.left) + parseInt(obj.width) + mod_dependentIframe_offsetLeft;
	thisObj.top = parseInt(obj.top) - mod_dependentIframe_offsetTop;
	thisObj.height = parseInt(obj.height) + (2*mod_dependentIframe_offsetTop);
}