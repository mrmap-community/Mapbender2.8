<?php
# $Id: mod_scalebar.php 4115 2009-06-24 10:54:06Z astrid_emde $
# http://www.mapbender.org/index.php/mod_scalebar.php
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
echo "var mod_scalebar_target = '".$e_target[0]."';";
?>

var mod_scalebar_left = 5;
var mod_scalebar_bottom = 17;

var mod_scalebar_color1 = "white";
var mod_scalebar_color2 = "black";
var mod_scalebar_font = "Arial, Helvetica, sans-serif";
var mod_scalebar_fontsize = "9px";

eventAfterMapRequest.register(function () {
	mod_scalebar();
});
function mod_scalebar(){
	var scale = mb_getScale(mod_scalebar_target);
	var ind = getMapObjIndexByName(mod_scalebar_target);
	if(scale < 10){
		var unit = '10&nbsp;cm';
		var factor = 10/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale >= 10 && scale < 100){
		var unit = '1&nbsp;m';
		var factor = 100/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale < 1000 && scale >= 100){
		var unit = '10&nbsp;m';
		var factor = 1000/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale < 10000 && scale >= 1000){
		var unit = '100&nbsp;m';
		var factor = 10000/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale < 100000 && scale >= 10000){
		var unit = '1&nbsp;km';
		var factor = 100000/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale < 1000000 && scale >= 100000){
		var unit = '10&nbsp;km';
		var factor = 1000000/scale;
	var img_width = Math.round(factor * mb_resolution);
	}
	if(scale < 10000000 && scale >= 1000000){
		var unit = '100&nbsp;km';
		var factor = 10000000/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale < 100000000 && scale >= 10000000){
		var unit = '1000&nbsp;km';
		var factor = 100000000/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	if(scale >= 100000000){
		var unit = '1000&nbsp;km';
		var factor = 100000000/scale;
		var img_width = Math.round(factor * mb_resolution);
	}
	var scalebarTag = "<img src='../img/scalebar_bw.gif' width='"+ img_width  +"' height='6'>&nbsp; ";
	scalebarTag += "<div style='position:absolute;left:"+(img_width + 4)+"px;top:5px;color:"+mod_scalebar_color1+";font-family:"+mod_scalebar_font+";font-size:"+mod_scalebar_fontsize+";'><nobr>"+ unit+"</nobr></div>";
	scalebarTag += "<div style='position:absolute;left:"+(img_width + 2)+"px;top:7px;color:"+mod_scalebar_color1+";font-family:"+mod_scalebar_font+";font-size:"+mod_scalebar_fontsize+";'><nobr>"+ unit+"</nobr></div>";
	scalebarTag += "<div style='position:absolute;left:"+(img_width + 2)+"px;top:5px;color:"+mod_scalebar_color1+";font-family:"+mod_scalebar_font+";font-size:"+mod_scalebar_fontsize+";'><nobr>"+ unit+"</nobr></div>";
	scalebarTag += "<div style='position:absolute;left:"+(img_width + 3)+"px;top:6px;color:"+mod_scalebar_color2+";font-family:"+mod_scalebar_font+";font-size:"+mod_scalebar_fontsize+";'>"+ unit+"</div>";

	var map_el = mb_mapObj[ind].getDomElement();
	if(!map_el.ownerDocument.getElementById(mb_mapObj[ind].elementName+"_scalebar")){
		//create Box Elements
		el_top = map_el.ownerDocument.createElement("div");
		el_top.style.position = "absolute";
		el_top.style.top = "0px";
		el_top.style.left = "0px";
		el_top.style.width = "300px";
		el_top.style.overflow = "hidden";
		el_top.style.zIndex = "10";
		el_top.id = mb_mapObj[ind].elementName+"_scalebar";
		map_el.appendChild(el_top);
	}
	mb_arrangeElement("", mod_scalebar_target+"_scalebar", mod_scalebar_left, (mb_mapObj[ind].height - mod_scalebar_bottom));
	writeTag(mb_mapObj[ind].frameName, mb_mapObj[ind].elementName+"_scalebar", scalebarTag);

}