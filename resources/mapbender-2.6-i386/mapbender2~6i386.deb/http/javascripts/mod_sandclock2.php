<?php
# $Id: mod_sandclock2.php 2488 2008-06-09 14:18:22Z christoph $
# http://www.mapbender.org/index.php/mod_sandclock2.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
echo "var mod_sandclock_target = '".$e_target[0]."';";
?>
var mod_sandclock_maxWait = 1000 * 60;
var mod_sandclock_minWait = 1000 * 0;

var mod_sandclock_count;
var mod_sandclock_img = new Image();
mod_sandclock_img.src = "../img/sandclock.gif";
mb_registerSubFunctions("mod_sandclock(true,myMapId)");


function mod_sandclock(start){
	var ind = getMapObjIndexByName(mod_sandclock_target);
	if(start){  
		mod_sandclock_count = mod_sandclock_maxWait; 
		var temp = "<img src='"+mod_sandclock_img.src+"'>";
		writeTag(mod_sandclock_target, "sandclock", temp);

		mb_arrangeElement(mod_sandclock_target, "sandclock", (mb_mapObj[ind].width/2 - 16), (mb_mapObj[ind].height/2 - 16));

		var dim = mod_sandclock_getWSize();
		document.getElementById("sandclock2").style.width = dim[0];
		document.getElementById("sandclock2").style.height = dim[1];
	}

	// check images:
	aktiv = setTimeout("mod_sandclock(false)",100);
	mod_sandclock_count -= 1000;

	var allMaps = window.frames[mod_sandclock_target].document.getElementsByName("mapimage");
	var cnt = 1;
	for(var i=0; i<allMaps.length; i++){
		if(allMaps[i].complete == true){
			cnt++;
		}         
	}   
	if((mod_sandclock_count <= 0 || cnt >= allMaps.length) && mod_sandclock_count < (mod_sandclock_maxWait - mod_sandclock_minWait)){
		clearTimeout(aktiv);
		writeTag(mod_sandclock_target, "sandclock", "");
		document.getElementById("sandclock2").style.width = 1;
		document.getElementById("sandclock2").style.height = 1;      
	}
}
function mod_sandclock_getWSize(){
	if(ie){
		var dim = new Array(window.document.body.offsetWidth,  window.document.body.offsetHeight);
	}
	else{
		var dim = new Array(window.innerWidth, window.innerHeight);
	}
	return dim;
}