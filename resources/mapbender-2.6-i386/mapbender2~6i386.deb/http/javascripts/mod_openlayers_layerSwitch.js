
ol_map.addControl(new OpenLayers.Control.LayerSwitcher());