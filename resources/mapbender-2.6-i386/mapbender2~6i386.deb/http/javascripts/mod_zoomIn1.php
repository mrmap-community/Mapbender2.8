<?php
# $Id: mod_zoomIn1.php 3377 2009-01-02 09:11:18Z christoph $
# http://www.mapbender.org/index.php/mod_zoomIn1.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>
var zoomin1Id = '<?php echo $e_id; ?>';
var mod_zoom1_img = new Image(); 
mod_zoom1_img.src = "<?php  echo $e_src;  ?>";
var mod_zoom1_img_over = new Image(); 
mod_zoom1_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

var $zoomin1Button = $("#"+zoomin1Id);

$zoomin1Button.click(function () {
	zoom("<?php  echo $e_target[0];  ?>", true, 2.0);
});

function mod_zoomIn1_init(obj){
	document.getElementById("zoomIn1").src = mod_zoom1_img_over.src;
	obj.onmouseover = new Function("mod_zoomIn1_over()");
	obj.onmouseout = new Function("mod_zoomIn1_out()");
}
function mod_zoomIn1_over(){
	document.getElementById("zoomIn1").src = mod_zoom1_img_over.src;
}
function mod_zoomIn1_out(){
	document.getElementById("zoomIn1").src = mod_zoom1_img.src;
}

