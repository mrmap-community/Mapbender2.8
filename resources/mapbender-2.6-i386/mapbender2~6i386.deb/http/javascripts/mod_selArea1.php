<?php
# $Id: mod_selArea1.php 3391 2009-01-02 14:09:15Z nimix $
# http://www.mapbender.org/index.php/mod_selArea1.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>
var mod_selArea_elName = "selArea1";
var mod_selArea_frameName = "";
var mod_selArea_target = "<?php echo $e_target[0]; ?>";

var mod_selArea_MapObj = null;
var mod_selArea_img_on = new Image(); 
mod_selArea_img_on.src = "<?php  echo preg_replace("/_off/","_on",$e_src);  ?>";
var mod_selArea_img_off = new Image(); 
mod_selArea_img_off.src = "<?php  echo $e_src;  ?>";
var mod_selArea_img_over = new Image(); 
mod_selArea_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

function init_selArea1(ind){
	mod_selArea_MapObj = getMapObjByName(mod_selArea_target);
	mb_button[ind] = document.getElementById(mod_selArea_elName);
	mb_button[ind].img_over = mod_selArea_img_over.src;
	mb_button[ind].img_on = mod_selArea_img_on.src;
	mb_button[ind].img_off = mod_selArea_img_off.src;
	mb_button[ind].status = 0;
	mb_button[ind].elName = mod_selArea_elName;
	mb_button[ind].fName = mod_selArea_frameName;
	mb_button[ind].go = new Function ("mod_selArea_click()");
	mb_button[ind].stop = new Function ("mod_selArea_disable()");
}
function mod_selArea_click(){
	var el = mod_selArea_MapObj.getDomElement();
	el.onmouseover = mod_selArea_init;
	el.onmousedown = mod_box_start;
	el.onmouseup = mod_selArea_get;
	el.onmousemove = mod_box_run;
}
function mod_selArea_disable(){
	var el = mod_selArea_MapObj.getDomElement();
	el.onmousedown = null;
	el.onmouseup = null;
	el.onmousemove = null;
}
function mod_selArea_init(e){
	mb_isBF = mod_selArea_target;
	mb_zF = mod_selArea_target;
}
function mod_selArea_get(e){
	mb_isBF = mod_selArea_target;
	mb_zF = mod_selArea_target;
	mod_box_setValidClipping(mod_box_stop(e));
}
