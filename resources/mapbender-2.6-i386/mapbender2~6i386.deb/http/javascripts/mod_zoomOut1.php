<?php
#$Id: mod_zoomOut1.php 3386 2009-01-02 12:31:38Z christoph $
#$Header: /cvsroot/mapbender/mapbender/http/javascripts/mod_zoomOut1.php,v 1.8 2005/09/13 18:16:42 bjoern_heuser Exp $

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>
var mod_zoomOut_img = new Image(); 
mod_zoomOut_img.src = "<?php  echo $e_src;  ?>";
var mod_zoomOut_img_over = new Image(); 
mod_zoomOut_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

var zoomOut1Id = '<?php echo $e_id; ?>';

var $zoomOut1Button = $("#"+zoomOut1Id);

$zoomOut1Button.click(function () {
	zoom("<?php  echo $e_target[0];  ?>", false, 2.0);
});

function mod_zoomOut1_init(obj){
   document.getElementById("zoomOut1").src = mod_zoomOut_img_over.src;
   obj.onmouseover = new Function("mod_zoomOut1_over()");
   obj.onmouseout = new Function("mod_zoomOut1_out()");
}
function mod_zoomOut1_over(){
   document.getElementById("zoomOut1").src = mod_zoomOut_img_over.src;
}
function mod_zoomOut1_out(){
   document.getElementById("zoomOut1").src = mod_zoomOut_img.src;
}

