
function mb_mapObjaddWMS(obj){var cnt_layers=0;var cnt_querylayers=0;var styles="";var layers="";var querylayers="";var ind=getMapObjIndexByName(obj);for(var i=0;i<(wms.length-1);i++){if(parseInt(wms[i].wms_id,10)>=parseInt(wms[wms.length-1].wms_id,10)){wms[wms.length-1].wms_id=parseInt(mb_mapObj[ind].wms[i].wms_id,10)+1;}}
mb_mapObj[ind].wms[mb_mapObj[ind].wms.length]=wms[wms.length-1];mb_mapObj[ind].layers[mb_mapObj[ind].layers.length]=layers;mb_mapObj[ind].styles[mb_mapObj[ind].styles.length]=styles;mb_mapObj[ind].querylayers[mb_mapObj[ind].querylayers.length]=querylayers;mb_execloadWmsSubFunctions();return true;}
function mod_addWMS_load(caps){var capUrl="../php/mod_createJSObjFromXML.php?"+mb_session_name+"="+mb_nr+"&caps="+encodeURIComponent(caps);window.frames['loadData'].document.location.href=capUrl;}
function mod_addLayer_load(caps,layer_name){var url="../php/mod_createJSLayerObjFromXML.php?caps="+encodeURIComponent(caps)+"&layer_name="+encodeURIComponent(layer_name);window.frames['loadData'].document.location.href=url;}
function mod_addWMSById_load(gui_id,wms_id){window.frames['loadData'].document.location.href="../php/mod_createJSObjFromDBByWMS.php?wms_id="+wms_id+"&gui_id="+gui_id;}
function mod_addWMS_refresh(){mb_mapObjaddWMS('mapframe1')
zoom('mapframe1',true,0.999);}