<?php
# $Id: mod_copyright.php 4338 2009-07-10 15:29:55Z christoph $
# http://www.mapbender.org/index.php/mod_copyright.php
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include '../include/dyn_js.php';

echo "var mod_copyright_target = '".$e_target[0]."';";
?>
try{
	if (mod_copyright_text){}
}
catch(e){
	mod_copyright_text = "mapbender.org"
}

var mod_copyright_left = 5;
var mod_copyright_bottom = 20;
var mod_copyright_color1 = "white";
var mod_copyright_color2 = "black";
var mod_copyright_font = "Arial, Helvetica, sans-serif";
var mod_copyright_fontsize = "9px";

eventAfterMapRequest.register(function () {
	mod_copyright();
});

function mod_copyright(){
	var ind = getMapObjIndexByName(mod_copyright_target);
	var myMapObj = mb_mapObj[ind];

	var str_c = "<div>";
	str_c += "<img src='../img/transparent.gif' width ='"+mb_mapObj[ind].width+"' height='"+mb_mapObj[ind].height+"'>";
	str_c += "<div style='font-family:"+mod_copyright_font+";font-size:"+mod_copyright_fontsize+";color:"+mod_copyright_color1+";position:absolute;top:"+(mb_mapObj[ind].height - (mod_copyright_bottom-1))+"px;left:"+mod_copyright_left+"px'>"+mod_copyright_text+"</div>";
	str_c += "<div style='font-family:"+mod_copyright_font+";font-size:"+mod_copyright_fontsize+";color:"+mod_copyright_color1+";position:absolute;top:"+(mb_mapObj[ind].height - mod_copyright_bottom)+"px;left:"+mod_copyright_left+"px'>"+mod_copyright_text+"</div>";
	str_c += "<div style='font-family:"+mod_copyright_font+";font-size:"+mod_copyright_fontsize+";color:"+mod_copyright_color2+";position:absolute;top:"+(mb_mapObj[ind].height - mod_copyright_bottom)+"px;left:"+(mod_copyright_left+1)+"px'>"+mod_copyright_text+"</div>";
	str_c += "</div>";

	var map_el = myMapObj.getDomElement();
	if(!map_el.ownerDocument.getElementById(myMapObj.elementName+"_copyright")){
		//create Box Elements
		var el_top = map_el.ownerDocument.createElement("div");
		el_top.style.position = "absolute";
		el_top.style.top = "0px";
		el_top.style.left = "0px";
		el_top.style.overflow = "hidden";
		el_top.style.zIndex = "60";
		el_top.id = myMapObj.elementName+"_copyright";
		map_el.appendChild(el_top);
	}
	writeTag(myMapObj.frameName, myMapObj.elementName+"_copyright", str_c);
}
