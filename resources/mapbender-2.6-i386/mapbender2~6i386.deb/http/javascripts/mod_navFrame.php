<?php
# $Id: mod_navFrame.php 3377 2009-01-02 09:11:18Z christoph $
# http://www.mapbender.org/index.php/mod_navFrame.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include '../include/dyn_js.php';
echo "var mod_navFrame_target = '".$e_target[0]."';";
echo "var mod_navFrame_src = '".$e_src."';";
?>

try{
	if (mod_navFrame_ext){}
}
catch(e){
	mod_navFrame_ext = 10;
}

eventAfterMapRequest.register(function () {
	mod_navFrame_arrange();
});

var directionArray = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
for (var i in directionArray) {
	(function () {
		var currentDirection = directionArray[i];
		$("#mb"+currentDirection).click(function () {
			mod_navFrame(currentDirection);
		});
	}());
}

function  mod_navFrame_arrange(){
	var el = document.getElementById(mod_navFrame_target).style;
	var ext = mod_navFrame_ext;
	var myLeft = parseInt(el.left);
	var myTop = parseInt(el.top);
	var myWidth = parseInt(el.width);
	var myHeight = parseInt(el.height);
	
	//left,top,width,height
	mod_navFrame_pos("mbN",(myLeft),(myTop - ext),(myWidth),(ext));
	document.getElementById("arrow_n").style.left = myWidth/2 - document.getElementById("arrow_n").width/2;   
	mod_navFrame_pos("mbNE",(myLeft + myWidth),(myTop - ext),(ext),(ext));
	mod_navFrame_pos("mbE",(myLeft + myWidth),(myTop),(ext),(myHeight));
	document.getElementById("arrow_e").style.top = myHeight/2 - document.getElementById("arrow_n").height/2;
	mod_navFrame_pos("mbSE",(myLeft + myWidth),(myTop + myHeight),(ext),(ext));
	mod_navFrame_pos("mbS",(myLeft),(myTop + myHeight),(myWidth),(ext));
	document.getElementById("arrow_s").style.left = myWidth/2 - document.getElementById("arrow_s").width/2;
	mod_navFrame_pos("mbSW",(myLeft - ext),(myTop + myHeight),(ext),(ext));
	mod_navFrame_pos("mbW",(myLeft - ext),(myTop),(ext),(myHeight));
	document.getElementById("arrow_w").style.top = myHeight/2 - document.getElementById("arrow_w").height/2;
	mod_navFrame_pos("mbNW",(myLeft - ext),(myTop -ext),(ext),(ext));   
}
function mod_navFrame(val){
	mb_panMap(mod_navFrame_target,val);  
}
function mod_navFrame_pos(el,left,top,width,height){
//alert(el + " , " +left + " , " +top + " , " +width + " , " +height)
	document.getElementById(el).style.left = left;
	document.getElementById(el).style.top = top;
	document.getElementById(el).style.width = width;
	document.getElementById(el).style.height = height;
}
