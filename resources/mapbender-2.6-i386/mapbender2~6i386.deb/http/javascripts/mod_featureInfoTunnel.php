<?php
# $Id: mod_featureInfoTunnel.php 3682 2009-03-12 16:33:34Z verenadiewald $
# http://www.mapbender.org/index.php/mod_featureInfoTunnel.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include '../include/dyn_js.php';
//defaults for element vars
?>
if(typeof(featureInfoLayerPopup)==='undefined')
	var featureInfoLayerPopup = 'false';
if(typeof(featureInfoPopupHeight)==='undefined')
	var featureInfoPopupHeight = '200';
if(typeof(featureInfoPopupWidth)==='undefined')
	var featureInfoPopupWidth = '270';

var mod_featureInfoTunnel_elName = "featureInfoTunnel";
var mod_featureInfoTunnel_frameName = "";
var mod_featureInfoTunnel_target = "<?php echo $e_target[0]; ?>";
var mod_featureInfoTunnel_map = null;

var mod_featureInfoTunnel_img_on = new Image(); mod_featureInfoTunnel_img_on.src =  "<?php  echo preg_replace("/_off/","_on",$e_src);  ?>";
var mod_featureInfoTunnel_img_off = new Image(); mod_featureInfoTunnel_img_off.src ="<?php  echo $e_src;  ?>";
var mod_featureInfoTunnel_img_over = new Image(); mod_featureInfoTunnel_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

function init_featureInfoTunnel(ind){
	mb_button[ind] = document.getElementById(mod_featureInfoTunnel_elName);
	mb_button[ind].img_over = mod_featureInfoTunnel_img_over.src;
	mb_button[ind].img_on = mod_featureInfoTunnel_img_on.src;
	mb_button[ind].img_off = mod_featureInfoTunnel_img_off.src;
	mb_button[ind].status = 0;
	mb_button[ind].elName = mod_featureInfoTunnel_elName;
	mb_button[ind].fName = mod_featureInfoTunnel_frameName;
	mb_button[ind].go = new Function ("mod_featureInfoTunnel_click()");
	mb_button[ind].stop = new Function ("mod_featureInfoTunnel_disable()");
	
	mod_featureInfoTunnel_map = getMapObjByName(mod_featureInfoTunnel_target);
}
function mod_featureInfoTunnel_click(){   
	mod_featureInfoTunnel_map.getDomElement().onclick = mod_featureInfoTunnel_event;
}
function mod_featureInfoTunnel_disable(){
	mod_featureInfoTunnel_map.getDomElement().onclick = null;
}
function mod_featureInfoTunnel_event(e){
	eventBeforeFeatureInfo.trigger({"fName":mod_featureInfoTunnel_target});

	var point = mod_featureInfoTunnel_map.getMousePos(e);
	var path = '../extensions/ext_featureInfoTunnel.php';
	
//TODO that code should go to featureInfo Redirect module
	var ind = getMapObjIndexByName(mod_featureInfoTunnel_target);
	if(document.getElementById("FeatureInfoRedirect")){
		//fill the frames
		for(var i=0; i<mod_featureInfoTunnel_map.wms.length; i++){
			var req = mod_featureInfoTunnel_map.wms[i].getFeatureInfoRequest(mb_mapObj[ind], point);
			if(req)
				window.frames.FeatureInfoRedirect.document.getElementById(mod_featureInfoTunnel_map.wms[i].wms_id).src = path+"?url="+escape(req);
		}
	}
	else{
		urls = mod_featureInfoTunnel_map.getFeatureInfoRequests(point);
		if(urls){
			for(var i=0;i<urls.length;i++){
				(function () {
					var currentRequest = escape(urls[i]);
					var cnt = i;
					mb_ajax_post(path, {'url':currentRequest},function(js_code,status){
						if(js_code){
							if(featureInfoLayerPopup == 'true'){
								var p = new mb_popup({
									title:"Information",
									url:path+"?url="+currentRequest,
									width:parseInt(featureInfoPopupWidth, 10),
									height:parseInt(featureInfoPopupHeight, 10),
									top:200 + cnt*25,
									left:600 + cnt*25
								});
								p.show();
							}
							else{
								window.open(path+"?url="+currentRequest, "" , "width="+featureInfoPopupWidth+",height="+featureInfoPopupHeight+",scrollbars=yes,resizable=yes");
							}
						}
						else{
                            var e = new Mb_exception("No featureInfo results.");
                         }
					});
				}());
			}
		}
		else
			alert(unescape("Please select a layer! \n Bitte waehlen Sie eine Ebene zur Abfrage aus!"));
	}	
}
