<?php
# $Id: mod_sandclock.php 4335 2009-07-10 15:28:32Z christoph $
# http://www.mapbender.org/index.php/mod_sandclock.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
echo "var mod_sandclock_target = '".$e_target[0]."';";
include '../include/dyn_js.php';
?>
try{
	if (mod_sandclock_image){}
}
catch(e){
	mod_sandclock_image = "../img/sandclock.gif";
}

var mod_sandclock_img = new Image();
mod_sandclock_img.src = mod_sandclock_image;

eventAfterMapRequest.register(function (obj) {
	mod_sandclock(true,obj.myMapId);
});

function mod_sandclock(start,myMapId){
	var ind = getMapObjIndexByName(mod_sandclock_target);
	if(start){
		var temp = "<img src='"+mod_sandclock_img.src+"'>";

		var map_el = mb_mapObj[ind].getDomElement();
		if(!map_el.ownerDocument.getElementById(mb_mapObj[ind].elementName+"_sandclock")){
			//create Box Elements
			el_top = map_el.ownerDocument.createElement("div");
			el_top.style.position = "absolute";
			el_top.style.top = "0px";
			el_top.style.left = "0px";
			el_top.style.overflow = "hidden";
			el_top.style.zIndex = "10";
			el_top.style.visibility = "visible";
			el_top.id = mb_mapObj[ind].elementName+"_sandclock";
			map_el.appendChild(el_top);
		}
		writeTag(mb_mapObj[ind].frameName, mb_mapObj[ind].elementName+"_sandclock", temp);
		mb_arrangeElement("", mod_sandclock_target+"_sandclock", (mb_mapObj[ind].width/2 - 16), (mb_mapObj[ind].height/2 - 16));
	}

	//
	// if myMapId is nopt given, the sandclock has to be turned off manually
	// by calling mod_sandclock_off. Usually this is done in a callback 
	// function.
	//
	if (typeof myMapId !== "undefined") {
		aktiv = setTimeout(function () {
			mod_sandclock('',myMapId);
			},10);
		var myMapIdArray = myMapId.split(",");
		var complete = true;
		var myMapId;
		for (var i = 0; i < myMapIdArray.length && complete; i++) {
			myMapId = myMapIdArray[i];
			var myDoc = mb_mapObj[ind].getDomElement().ownerDocument;
			if(myDoc.getElementById(myMapId) && 
				!myDoc.getElementById(myMapId).complete) {
				complete = false;
			}
		}
		if (complete) {
			clearTimeout(aktiv);
			mod_sandclock_off(mb_mapObj[ind]);
		} 
	}
}

function mod_sandclock_off() {
	var mapObj = getMapObjByName(mod_sandclock_target);
	writeTag(mapObj.frameName, mapObj.elementName+"_sandclock", "");
}
