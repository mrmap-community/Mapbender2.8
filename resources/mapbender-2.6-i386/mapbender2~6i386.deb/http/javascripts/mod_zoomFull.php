<?php
#$Id: mod_zoomFull.php 3383 2009-01-02 11:07:45Z christoph $
#$Header: /cvsroot/mapbender/mapbender/http/javascripts/mod_zoomFull.php,v 1.8 2005/09/13 18:16:42 bjoern_heuser Exp $
require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>
   var mod_zoomFull_img = new Image(); 
   mod_zoomFull_img.src = "<?php  echo $e_src;  ?>";
   var mod_zoomFull_img_over = new Image(); 
   mod_zoomFull_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

function mod_zoomFull(){
	var frameName = "<?php  echo $e_target[0];  ?>"
    var ind = this.getMapObjIndexByName(frameName);
	
	mb_mapObj[ind].zoomFull();
}

function mod_zoomFull_init(obj){
   document.getElementById("zoomFull").src = mod_zoomFull_img_over.src;
   obj.onmouseover = new Function("mod_zoomFull_over()");
   obj.onmouseout = new Function("mod_zoomFull_out()");
}
function mod_zoomFull_over(){
   document.getElementById("zoomFull").src = mod_zoomFull_img_over.src;
}
function mod_zoomFull_out(){
   document.getElementById("zoomFull").src = mod_zoomFull_img.src;
}



