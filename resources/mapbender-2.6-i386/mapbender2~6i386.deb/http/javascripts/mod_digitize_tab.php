<?php
# $Id: mod_digitize_tab.php 4672 2009-09-22 08:07:04Z christoph $
# http://www.mapbender.org/index.php/mod_digitize_tab.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__) . "/../php/mb_validateSession.php");

$e_target = $_GET["e_target"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
<title>Digitize</title>
<?php
$digitize_conf_filename = "digitize_default.conf";
include '../include/dyn_css.php';
?>
<script language='JavaScript'>
//
// Buttons
//
function addButtonDig(id, isOn, src, titleOff, titleOn, x, y) {
	buttonDig_id.push(id);
	buttonDig_on.push(isOn);
	buttonDig_src.push(src);
	buttonDig_title_off.push(titleOff);
	buttonDig_title_on.push(titleOn);
	buttonDig_x.push(x);
	buttonDig_y.push(y);
}

function htmlspecialchars(p_string) {
	p_string = p_string.replace(/&/g, '&amp;');
	p_string = p_string.replace(/</g, '&lt;');
	p_string = p_string.replace(/>/g, '&gt;');
	p_string = p_string.replace(/"/g, '&quot;');
	//	p_string = p_string.replace(/'/g, '&#039;');
	return p_string;
};
   
//default definition of image directory for digitize buttons, might
//be overwritten with digitize conf data
var buttonDig_imgdir = "../img/button_digitize/";
var buttonDig_id = [];
var buttonDig_on = [];
var buttonDig_src = [];
var buttonDig_title_off = [];
var buttonDig_title_on = [];
var buttonDig_x = [];
var buttonDig_y = [];	

var mapWindow;
var mapDomElement;
var mapType = "";

parent.eventInit.register(function () {
	var mapIndex = parent.getMapObjIndexByName(mod_digitize_target);
	mapDomElement = parent.mb_mapObj[mapIndex].getDomElement();
	mapType = mapDomElement.tagName.toUpperCase();
	if (mapType == "DIV") {
		mapWindow = parent.window;
	}
	else if (mapType == "IFRAME") {
		mapWindow = mapDomElement.window;
	}
	else {
		new parent.Mb_warning("Could not set CSS for map in digitizing module.");
	}
});


<?php
echo "var mod_digitize_target = '".$e_target."';";
$digitizeConfFilenameAndPath = dirname(__FILE__) . "/../../conf/" . $digitize_conf_filename;
if ($digitize_conf_filename && file_exists($digitizeConfFilenameAndPath)) {
	include($digitizeConfFilenameAndPath);
}
?>

var wfsWindow;	
var wfsConf = [];
var d;
var mod_digitize_width;
var mod_digitize_height;
var mod_digitizeEvent = false;
var nonTransactionalHighlight;

var button_point = "Point";
var button_line = "Line";
var button_polygon = "Polygon";
var button_move = "dragBasePoint";
var button_insert = "setBasePoint";
var button_delete = "delBasePoint";
var button_clear = "clear";
var button_split = "digitizeSplit";
var button_merge = "digitizeMerge";
var button_difference = "digitizeDifference";

var digitizeDivTag;

var GeometryArray;
var MultiGeometry = parent.MultiGeometry;
var Geometry;
var Point;
var geomType;

var msgObj;
var featureTypeElementFormId = "featureTypeElementForm";

try {if(mod_digitize_elName){}}catch(e) {mod_digitize_elName = "digitize";}
try {if(nonTransactionalEditable){}}catch(e) {nonTransactionalEditable = false;}
try {if(addCloneGeometryButton){}}catch(e) {addCloneGeometryButton = false;}

function getMousePosition(e) {
	var ind = parent.getMapObjIndexByName("<?php  echo $e_target;  ?>");
	currentPos = parent.mb_mapObj[ind].getMousePosition(e);
	
	return currentPos;
}


function initializeDigitize () {
	d = new parent.GeometryArray();
	GeometryArray = parent.GeometryArray;
	Geometry = parent.Geometry;
	Point = parent.Point;
	geomType = parent.geomType;
}

/**
 * Append geometries from KML when KML has been loaded
 */
function appendGeometryArrayFromKML () {
	try {
		parent.kmlHasLoaded.register(function(properties){
			d = new parent.GeometryArray();
			d.importGeoJSON(properties);		
//			d = parent.geoJsonToGeometryArray(properties);
			executeDigitizeSubFunctions();
		});
	}
	catch (e) {
		var exc = new parent.Mb_warning(e);
	}
}


// ------------------------------------------------------------------------------------------------------------------------
// --- polygon, line, point insertion (begin) ----------------------------------------------------------------------------------------------

function appendGeometryArray(obj) {
	executeDigitizePreFunctions();
	d.union(obj);
	executeDigitizeSubFunctions();
}

function mod_digitize_go(e){
	// ie workaround
	if (e == undefined) {
		e = mapWindow.event;
	}
	if (e) {
		// track mouse position
		var currentPos = getMousePosition(e);
		
		s.check(currentPos);
	}
	else {
//		s.clean();
	}

	var el = mapDomElement;
	el.onmousedown = mod_digitize_start;
}

function mod_digitize_timeout(){
	var el = mapDomElement;
	el.onmousedown = null;
	el.onmouseup = null;
	el.onmousemove = null;
}

function mod_digitize_start(e){
	// check if a proper geometry is selected	
	if (d.getGeometry(-1,-1).isComplete() || d.count() == 0){
		
		if (mod_digitizeEvent != false) {
			alert(msgObj.errorMessageNoGeometrySelected);
		}
		return false;
	}
	
	var realWorldPos;
	if (s.isSnapped()) {
		realWorldPos = s.getSnappedPoint(); 
		s.clean();
	}
	else {
		var currentPos = getMousePosition(e);
		realWorldPos = parent.mapToReal(mod_digitize_target,currentPos);
	}
	
	if (d.get(-1).geomType == parent.geomType.polygon && d.getGeometry(-1,-1).count() > 1 && d.getGeometry(-1,-1).get(0).equals(realWorldPos)) {
				
		// close the polygon
		d.close();
		parent.mb_disableThisButton(button_polygon);
		return true;
	}
	else if (d.get(-1).geomType == parent.geomType.line && d.getGeometry(-1,-1).count() > 1 && d.getGeometry(-1,-1).get(-1).equals(realWorldPos)) {
		// close the line
		d.close();
		parent.mb_disableThisButton(button_line);
		return true;
	}
	else {
		// set the calculated real world position as point of the geometry
		d.getGeometry(-1,-1).addPoint(realWorldPos);
		var mapIndex = parent.getMapObjIndexByName(mod_digitize_target);

		d.getGeometry(-1,-1).setEpsg(parent.mb_mapObj[mapIndex].epsg);
		
		if(d.get(-1).geomType == parent.geomType.point){
			d.close();
			parent.mb_disableThisButton(button_point);
			return true;
		}
		
		// add first point of polygon to snapping list (if three points have been inserted).
		else if (d.get(-1).geomType == parent.geomType.polygon && d.getGeometry(-1,-1).count() == 3) {
			s.add(d.getPoint(-1, -1, 0));
		}

		// add last point of line to snapping list (if at least two points have been inserted).
		else if (d.get(-1).geomType == parent.geomType.line && d.getGeometry(-1,-1).count() >= 2) {
			if (mod_digitizeEvent != button_move) {
				s.store(d);
			}
			s.add(d.getPoint(-1, -1, -1));
		}
	}
	executeDigitizeSubFunctions();
	return true;
}
// --- polygon, line, point insertion (begin) ----------------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------------------------------

// ------------------------------------------------------------------------------------------------------------------------
// --- basepoint handling (begin) -----------------------------------------------------------------------------------------

var basepointObject = false;
var basepointMemberIndex = null;
var basepointGeometryIndex = null;
var basepointRingIndex = null;
var basepointPointIndex = null;
var basepointDragActive = false;

function handleBasepoint(obj,memberIndex, geometryIndex, ringIndex, pointIndex){
	if (!(
		mod_digitizeEvent == button_move || 
		mod_digitizeEvent == button_insert || 
		mod_digitizeEvent == button_delete)
	) { 
		return false; 
	}
	
	basepointObject = obj;
	basepointMemberIndex = memberIndex;
	basepointGeometryIndex = geometryIndex;

	if (pointIndex == undefined) {
		pointIndex = ringIndex;
		basepointRingIndex = undefined;
	}
	else {
		basepointRingIndex = ringIndex;
	}
	basepointPointIndex = pointIndex;
	
	if(mod_digitizeEvent == button_move){
		mod_digitize_timeout();
		basepointObject.style.cursor = 'move';
		basepointObject.onmousedown = parent.frames[mod_digitize_elName].selectBasepoint;
	}

	if(mod_digitizeEvent == button_delete){
		mod_digitize_timeout();
		basepointObject.style.cursor = 'crosshair';
		basepointObject.onmousedown = parent.frames[mod_digitize_elName].deleteBasepoint;
	}
}

function convertLinepointToBasepoint(obj, memberIndex, geomIndex, ringIndex, pointIndex){
	if(!(mod_digitizeEvent == button_insert)){ return false; }
	
	if(mod_digitizeEvent == button_insert){
		mod_digitize_timeout();
		obj.style.cursor = 'crosshair';
		obj.onclick = insertBasepoint;

		basepointObject = obj;
		basepointMemberIndex = memberIndex;
		basepointGeometryIndex = geomIndex;
		basepointRingIndex = ringIndex;
		basepointPointIndex = pointIndex;
	}
}

function insertBasepoint(e){
	var i = basepointMemberIndex;
	var j = basepointGeometryIndex;
	var k = basepointRingIndex;
	var l = basepointPointIndex;
	
	var currentPos = getMousePosition(e);

	var ind = parent.getMapObjIndexByName(mod_digitize_target);
	var p = parent.mb_mapObj[ind].convertPixelToReal(new Point(currentPos.x, currentPos.y));

	if (k == undefined) {
		d.getGeometry(i,j).addPointAtIndex(p, l);
	}
	else {
		d.getGeometry(i,j).innerRings.get(k).addPointAtIndex(p, l);
	}

	executeDigitizeSubFunctions();
}

function deleteBasepoint(){
	var i = basepointMemberIndex;
	var j = basepointGeometryIndex;
	var k = basepointRingIndex;
	var l = basepointPointIndex;

	if (k != undefined) {
		d.delAllPointsLike(d.getPoint(i, j, k, l));
	}
	else {
		d.delAllPointsLike(d.getPoint(i, j, l));
	}

	executeDigitizeSubFunctions();
}

function selectBasepoint(e){
	if(!basepointDragActive && mod_digitizeEvent == button_move){
		basepointDragActive = true;
		s.store(d, d.getPoint(basepointMemberIndex, basepointGeometryIndex, basepointPointIndex));
		// replace basepoint by transparent blob
		basepointObject.style.width = mod_digitize_width;
		basepointObject.style.height = mod_digitize_height;
		basepointObject.style.left = 0;
		basepointObject.style.top = 0;
			
		if (parent.ie) {
			// ie cannot handle backgroundColor = 'transparent'
			basepointObject.style.background = "url(../img/transparent.gif)";
		}
		else{
			basepointObject.style.backgroundColor = 'transparent';
		}

		basepointObject.onmouseup = releaseBasepoint;
		basepointObject.onmousemove = dragBasepoint;
	}
}

function dragBasepoint(e){
	if(basepointDragActive){
		var currentPos = getMousePosition(e);
		var res = s.check(currentPos);

	}
}
	
function updateAllPointsOfNonTransactionalLike(oldP, newP){ 
	for (var i = 0; i < d.count(); i++) {
		if (isTransactional(d.get(i))) {
			d.get(i).updateAllPointsLike(oldP, newP);
		}
	}
}

	
function releaseBasepoint(e){
	
	var i = basepointMemberIndex;
	var j = basepointGeometryIndex;
	var k = basepointRingIndex;
	var l = basepointPointIndex;
	basepointDragActive = false;
	
	var currentPos = getMousePosition(e);
	var basepointDragEnd = currentPos;
	basepointObject.onmousedown = null;
	var ind = parent.getMapObjIndexByName(mod_digitize_target);
	var p = parent.mb_mapObj[ind].convertPixelToReal(new Point(basepointDragEnd.x, basepointDragEnd.y));

	var oldPoint;
	if (k == undefined) {
		oldPoint = parent.cloneObject(d.getPoint(i,j,l));
	} 
	else {
		oldPoint = parent.cloneObject(d.getPoint(i,j,k,l));
	}
	if (s.isSnapped()) {
		var snappedPoint = parent.cloneObject(s.getSnappedPoint());
		if (!nonTransactionalEditable) {
			updateAllPointsOfNonTransactionalLike(oldPoint, snappedPoint);
		}
		else {
			d.updateAllPointsLike(oldPoint, snappedPoint);
		}
		s.clean();
	}
	else {
		if (!nonTransactionalEditable) {
			updateAllPointsOfNonTransactionalLike(oldPoint, p);
		}
		else {
			d.updateAllPointsLike(oldPoint, p);
		}
	}
	basepointMemberIndex = null;
	basepointGeometryIndex = null;
	basepointPointIndex = null;	
		
	executeDigitizeSubFunctions();
}
// --- basepoint handling (end) -----------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------------------------------
	
// ------------------------------------------------------------------------------------------------------------------------
// --- registered functions (begin) ---------------------------------------------------------------------------------------

function registerDigitizePreFunctions(stringFunction){
	mod_digitizePreFunctions[mod_digitizePreFunctions.length] = stringFunction;
}

function registerDigitizeSubFunctions(stringFunction){
	mod_digitizeSubFunctions[mod_digitizeSubFunctions.length] = stringFunction;
}

function executeDigitizeSubFunctions(){
	for(var i=0; i<mod_digitizeSubFunctions.length; i++){
		eval(mod_digitizeSubFunctions[i]);
	}
}

function executeDigitizePreFunctions(){
	for(var i=0; i<mod_digitizePreFunctions.length; i++){
		eval(mod_digitizePreFunctions[i]);
	}
}

function registerFunctions(){
	mod_digitizePreFunctions = [];
	mod_digitizeSubFunctions = [];
	registerDigitizePreFunctions("updateExtent()");
	registerDigitizePreFunctions("drawDashedLine()");
	registerDigitizeSubFunctions("updateListOfGeometries()");
	registerDigitizeSubFunctions("drawDashedLine()");
	parent.eventInit.register(function () {
		initializeDigitize();
		setStyleForTargetFrame();
		checkDigitizeTag();
		initialiseSnapping();
//		appendGeometryArrayFromKML();
		if (!nonTransactionalEditable) {
			initialiseHighlight();
		}
		initialiseMeasure();
		getMessages();
	});
	parent.eventLocalize.register(function() {
		getMessages();
	});

	parent.eventAfterMapRequest.register(function () {
		updateExtent();
	});
	parent.mb_registerWfsWriteSubFunctions(function(){parent.zoom(mod_digitize_target, true, 0.999);});
}

function checkDigitizeTag(){
	var digitizeTagName = "digitizeDiv";
	var digitizeTagStyle;
	

	if (mapType == "DIV") {
		
		digitizeTagStyle = {"z-index":digitizeTransactionalZIndex, "font-size":"10px"};
		digitizeDivTag = new parent.DivTag(digitizeTagName, "", digitizeTagStyle, mapDomElement);
	}	 
	else {
		digitizeTagStyle = {"position":"absolute", "top":"0px", "left":"0px", "z-index":digitizeTransactionalZIndex, "font-size":"10px"};
		digitizeDivTag = new parent.DivTag(digitizeTagName, mod_digitize_target, digitizeTagStyle);
	}
	parent.mb_registerPanSubElement(digitizeTagName);
	parent.mb_registerSubFunctions("window.frames['"+ mod_digitize_elName + "'].drawDashedLine()");
}


function setStyleForTargetFrame(){
	var cssLink = mapWindow.document.createElement("link");
	var cssHead = mapWindow.document.getElementsByTagName("head")[0]; 
	cssLink.setAttribute("href", cssUrl); 
	cssLink.setAttribute("type", "text/css"); 
	cssLink.setAttribute("rel", "stylesheet"); 
	cssHead.appendChild(cssLink);
}

function initialiseSnapping(){
	s = new parent.Snapping(mod_digitize_target, snappingTolerance, snappingColor, snappingHighlightZIndex);
}
function initialiseHighlight(){
	nonTransactionalHighlight = new parent.Highlight([mod_digitize_target], "nonTransactional", {"position":"absolute", "top":"0px", "left":"0px", "z-index":digitizeNonTransactionalZIndex}, nonTransactionalLineWidth);
}
function initialiseMeasure(){
	if (mapType == "DIV") {
		measureDivTag = new parent.DivTag(measureTagName, "", measureTagStyle);
	}
	else {
		measureDivTag = new parent.DivTag(measureTagName, measureTagTarget, measureTagStyle);
	}
	parent.mb_registerSubFunctions("window.frames['"+ mod_digitize_elName + "'].updateMeasureTag()");
}
// --- registered functions (end) -----------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------------------------------


function updateMeasureTag () {
	if (d.count() > 0 ) {
		if (d.get(-1).count() > 0) {
			if (d.getGeometry(-1, -1).count() > 0) {
				if (mod_digitizeEvent == button_line || mod_digitizeEvent == button_polygon) {
					var measureString = "";
					measureString += msgObj.measureTagLabelCurrent + d.getGeometry(-1, -1).getCurrentDist(measureNumberOfDigits) + "<br>";
					measureString += msgObj.measureTagLabelTotal + d.getGeometry(-1, -1).getTotalDist(measureNumberOfDigits);
					measureDivTag.write(measureString);
					return true;
				}
			}
		}
	}
	measureDivTag.clean();
}



// ------------------------------------------------------------------------------------------------------------------------
// --- button handling (begin) --------------------------------------------------------------------------------------------

function displayButtons(){
	for (var i = 0 ; i < buttonDig_id.length ; i ++) {
		if (parseInt(buttonDig_on[i])==1) {
			var divTag = document.createElement("div");
			divTag.setAttribute("id", "div_" + buttonDig_id[i]);
// FIREFOX 
			document.getElementById("digButtons").appendChild(divTag);

//IE WORKAROUND, WORKS ALSO FOR FIREFOX
			var tagContent = "<div style='position:absolute; top:"+buttonDig_y[i]+"px; left:"+buttonDig_x[i]+"px;'><img name=\""+buttonDig_id[i]+"\" onmouseover=\"parent.mb_regButton_frame('initDigButton', mod_digitize_elName, "+i+");\" id=\""+buttonDig_id[i]+"\" title=\""+buttonDig_title_off[i]+"\" src=\""+buttonDig_imgdir+buttonDig_src[i]+"\"></div>";
			parent.writeTag(mod_digitize_elName,"div_" + buttonDig_id[i],tagContent);
		}
	}
}

function updateButtons() {
	for (var i = 0 ; i < buttonDig_id.length ; i ++) {
		if (parseInt(buttonDig_on[i])==1) {
			var currentButton = document.getElementById(buttonDig_id[i]);
			var currentStatus = buttonDig_id[i].status;
			var currentTitle = "";
			switch (buttonDig_id[i]) {
				case "Point":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelPointOn;
					}
					else {
						currentTitle = msgObj.buttonLabelPointOff;
					}
					break;
				case "Line":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelLineOn;
					}
					else {
						currentTitle = msgObj.buttonLabelLineOff;
					}
					break;
				case "Polygon":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelPolygonOn;
					}
					else {
						currentTitle = msgObj.buttonLabelPolygonOff;
					}
					break;
				case "dragBasePoint":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelMoveBasepointOn;
					}
					else {
						currentTitle = msgObj.buttonLabelMoveBasepointOff;
					}
					break;
				case "setBasePoint":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelInsertBasepointOn;
					}
					else {
						currentTitle = msgObj.buttonLabelInsertBasepointOff;
					}
					break;
				case "delBasePoint":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelDeleteBasepointOn;
					}
					else {
						currentTitle = msgObj.buttonLabelDeleteBasepointOff;
					}
					break;
				case "clear":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelClearListOn;
					}
					else {
						currentTitle = msgObj.buttonLabelClearListOff;
					}
					break;
				case "digitizeSplit":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelSplitOn;
					}
					else {
						currentTitle = msgObj.buttonLabelSplitOff;
					}
					break;
				case "digitizeMerge":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelMergeOn;
					}
					else {
						currentTitle = msgObj.buttonLabelMergeOff;
					}
					break;
				case "digitizeDifference":
					if (currentStatus == 1) {
						currentTitle = msgObj.buttonLabelDifferenceOn;
					}
					else {
						currentTitle = msgObj.buttonLabelDifferenceOff;
					}
					break;
			}
			currentButton.title = currentTitle;
		}
	}
}

function initDigButton(ind, pos){
	parent.mb_button[ind] = document.getElementById(buttonDig_id[pos]);
	parent.mb_button[ind].img_over = buttonDig_imgdir + buttonDig_src[pos].replace(/_off/,"_over");
	parent.mb_button[ind].img_on = buttonDig_imgdir + buttonDig_src[pos].replace(/_off/,"_on");
	parent.mb_button[ind].img_off = buttonDig_imgdir + buttonDig_src[pos];
	parent.mb_button[ind].title_on = buttonDig_title_on[pos];
	parent.mb_button[ind].title_off = buttonDig_title_off[pos];
	parent.mb_button[ind].status = 0;
	parent.mb_button[ind].elName = buttonDig_id[pos];
	parent.mb_button[ind].fName = "";
	parent.mb_button[ind].go = new Function ("digitizeEnable(parent.mb_button["+ind+"])");
	parent.mb_button[ind].stop = new Function ("digitizeDisable(parent.mb_button["+ind+"])");
}	

function digitizeEnable(obj) {
	if (obj.id == button_move || obj.id == button_insert || obj.id == button_delete) {
		mod_digitizeEvent = obj.id;
		executeDigitizePreFunctions();
	}
	else if (obj.id == button_point || obj.id == button_line || 
				obj.id == button_polygon || obj.id == button_clear || 
				obj.id == button_split || obj.id == button_merge ||
				obj.id == button_difference){
					
		var el = mapDomElement;
		el.onmousemove = mod_digitize_go;

		mod_digitizeEvent = obj.id;

		if (mod_digitizeEvent == button_point || mod_digitizeEvent == button_line || mod_digitizeEvent == button_polygon || mod_digitizeEvent == button_insert ) {
			s.store(d);
		}

		executeDigitizePreFunctions();
		obj.title = obj.title_on;
		if (obj.id == button_point) {
			if (d.count() > 0 && d.get(-1).count() > 0 && !d.get(-1).get(-1).isComplete()) {
				if (d.get(-1).geomType != parent.geomType.point) {
					d.close();
					executeDigitizeSubFunctions();
				}
				else {
					s.add(d.getPoint(-1, -1, 0));
				}
			}
			if (d.count() == 0 || (d.count() > 0 && d.get(-1).count() > 0 && d.get(-1).get(-1).isComplete())) {
				d.addMember(parent.geomType.point);
				d.get(-1).addGeometry();
			}
			else {
/*
//
// delete existing line or polygon
//	
				d.del(-1);
				d.addMember(parent.geomType.point);
				d.get(-1).addGeometry();
*/
			}
		}
		else if (obj.id == button_polygon) {
			if (d.count() > 0 && d.get(-1).count() > 0 && !d.get(-1).get(-1).isComplete()) {
				if (d.get(-1).geomType != parent.geomType.polygon) {
					d.close();
					executeDigitizeSubFunctions();
				}
				else {
					s.add(d.getPoint(-1, -1, 0));
				}
			}
			if (d.count() == 0 || (d.count() > 0 && d.get(-1).count() > 0 && d.get(-1).get(-1).isComplete())) {
				// new geometry
				d.addMember(parent.geomType.polygon);
				d.get(-1).addGeometry();
			}
			else {
/*
//
// continue a line as a polygon
//	
				if (d.get(-1).geomType != parent.geomType.polygon) {
					var geometryTemplate = parent.cloneObject(d.get(-1));
					d.del(-1);
					d.addMember(parent.geomType.polygon);
					for (var i = 0; i < geometryTemplate.count(); i++) {
						d.get(-1).addGeometry();
						for (var j = 0; j < geometryTemplate.get(i).count(); j++) {
							d.get(-1).get(-1).addPoint(geometryTemplate.get(i).get(j));
						}
					}
				}
				s.add(d.getPoint(-1, -1, 0));
*/
			}
		}
		else if (obj.id == button_line) {
			if (d.count() > 0 && d.get(-1).count() > 0 && !d.get(-1).get(-1).isComplete()) {
				if (d.get(-1).geomType != parent.geomType.line) {
					d.close();
					executeDigitizeSubFunctions();
				}
				else {
					s.add(d.getPoint(-1, -1, 0));
				}
			}
			if (d.count() == 0 || (d.count() > 0 && d.get(-1).count() > 0 && d.get(-1).get(-1).isComplete())) {
				d.addMember(parent.geomType.line);
				d.get(-1).addGeometry();
			}
			else {
/*
//
// continue a polygon as a line
//	
				if (d.get(-1).geomType != parent.geomType.line) {
					var geometryTemplate = parent.cloneObject(d.get(-1));
					d.del(-1);
					d.addMember(parent.geomType.line);
					for (var i = 0; i < geometryTemplate.count(); i++) {
						d.get(-1).addGeometry();
						for (var j = 0; j < geometryTemplate.get(i).count(); j++) {
							d.get(-1).get(-1).addPoint(geometryTemplate.get(i).get(j));
						}
					}
				}
*/
			}
		}
		else if (obj.id == button_clear) {
			var clear = confirm(msgObj.messageConfirmDeleteAllGeomFromList);
			if (clear) {
				d = new parent.GeometryArray();
				parent.mb_disableThisButton(button_clear);
			}
		}
		else if (obj.id == button_merge) {
			var applicable = (d.count() > 1);

			var polygonTextArray = [];
			for (var i = 0; i < d.count(); i++) {
				if (d.get(i).geomType != parent.geomType.polygon) {
					applicable = false;
					polygonTextArray = [];
					break;
				}
				polygonTextArray.push(d.get(i).toText());
			}

			if (!applicable) {
				alert(msgObj.messageErrorMergeNotApplicable);
				parent.mb_disableThisButton(button_merge);
				return false;
			}
			
			parent.mb_ajax_post("../php/mod_digitize_mergePolygon.php", {polygons: polygonTextArray.join(";")}, function(json, status) {
				var response = eval('(' + json + ')');
				var polygon = response.polygon;
				var mapIndex = parent.getMapObjIndexByName(mod_digitize_target);
				d.importGeometryFromText(polygon, parent.mb_mapObj[mapIndex].epsg);

				// remove the original polygons
				var len = d.count();
				for (var i = 0; i < len-1; i++) {
					d.del(0);
				}
				parent.mb_disableThisButton(button_merge);
			});
		}
		else if (obj.id == button_split) {
			var applicable = (d.count() == 2) && 
							(d.get(0).geomType == parent.geomType.polygon) &&
							(d.get(1).geomType == parent.geomType.line);
			if (!applicable) {
				alert(msgObj.messageErrorSplitNotApplicable);
				parent.mb_disableThisButton(button_split);
				return false;
			}
			
			var polygonText = d.get(0).toText();
			var lineText = d.get(1).toText();
			
			parent.mb_ajax_post("../php/mod_digitize_splitPolygon.php", {polygon: polygonText, line: lineText}, function(json, status) {
				var response = eval('(' + json + ')');
				var polygonArray = response.polygons;
				var wfsConfId = d.get(0).wfs_conf;
				var mapIndex = parent.getMapObjIndexByName(mod_digitize_target);
				for (var i in polygonArray) {
					d.importGeometryFromText(polygonArray[i], parent.mb_mapObj[mapIndex].epsg);
					d.get(-1).wfs_conf = wfsConfId;
				}
				// remove the original polygon and the temporary line
				d.del(0);
				d.del(0);
				parent.mb_disableThisButton(button_split);
			});
		}
		else if (obj.id == button_difference) {
			var applicable = (d.count() == 2) && 
							(d.get(0).geomType == parent.geomType.polygon) &&
							(d.get(1).geomType == parent.geomType.polygon);
			if (!applicable) {
				alert(msgObj.messageErrorDifferenceNotApplicable);
				parent.mb_disableThisButton(button_difference);
				return false;
			}
			
			var polygon1Text = d.get(0).toText();
			var polygon2Text = d.get(1).toText();
			
			parent.mb_ajax_post("../php/mod_digitize_differencePolygon.php", {polygon1: polygon1Text, polygon2: polygon2Text}, function(json, status) {
				var response = eval('(' + json + ')');
				var polygonArray = response.polygons;
				var wfsConfId = d.get(0).wfs_conf;
				var wfsProperties = d.get(0).e;
				var mapIndex = parent.getMapObjIndexByName(mod_digitize_target);
				for (var i in polygonArray) {
					d.importGeometryFromText(polygonArray[i], parent.mb_mapObj[mapIndex].epsg);
					d.get(-1).wfs_conf = wfsConfId;
					d.get(-1).e = wfsProperties;
				}
				// remove the original and the temporary polygon
				d.del(0);
				d.del(0);
				parent.mb_disableThisButton(button_difference);
			});
		}
	}
}

function digitizeDisable(obj) {
	if (obj.id == button_point || obj.id == button_line || obj.id == button_polygon){
		obj.title = obj.title_off;
		if (d.get(-1).get(-1).count() == 0) {
			d.delGeometry(-1,-1);
		}
		mod_digitize_timeout();
		executeDigitizeSubFunctions();
	}
	else if (obj.id == button_clear) {
		mod_digitize_timeout();
		executeDigitizeSubFunctions();
	}
	else if (obj.id == button_merge) {
		mod_digitize_timeout();
		executeDigitizeSubFunctions();
	}
	else if (obj.id == button_split) {
		mod_digitize_timeout();
		executeDigitizeSubFunctions();
	}
	else if (obj.id == button_difference) {
		mod_digitize_timeout();
		executeDigitizeSubFunctions();
	}
	mod_digitizeEvent = false;
}
// --- button handling (end) ----------------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------------
// --- display (begin) -----------------------------------------------------------------------------------------

function updateExtent() {
	var anInd = parent.getMapObjIndexByName(mod_digitize_target);
	var change = false;
	if (typeof(mod_digitize_width) == 'undefined' || mod_digitize_width != parent.mb_mapObj[anInd].width) {
		mod_digitize_width = parent.mb_mapObj[anInd].width;
		change = true;
	}
	if (typeof(mod_digitize_height) == 'undefined' || mod_digitize_height != parent.mb_mapObj[anInd].height) {
		mod_digitize_height = parent.mb_mapObj[anInd].height;
		change = true;
	}
	if (typeof(mod_digitize_epsg) == 'undefined' || mod_digitize_epsg != parent.mb_mapObj[anInd].epsg) {
		mod_digitize_epsg = parent.mb_mapObj[anInd].epsg;
		change = true;
	}
//	if (change) {
//		drawDashedLine();
//	}
}

function drawDashedLine(){
	if (!nonTransactionalEditable) {
		nonTransactionalHighlight.clean();
	}
	var smP = "";
	smP += "<div class='t_img'>";
	smP += "<img src='"+parent.mb_trans.src+"' width='"+mod_digitize_width+"' height='0'></div>";
	smP += "<div class='t_img'>";
	smP += "<img src='"+parent.mb_trans.src+"' width='0' height='"+mod_digitize_height+"'></div>";

	if (!nonTransactionalEditable) {
		nonTransactionalHighlight.clean();
	}
	var smPArray = [];
	smPArray[smPArray.length] = "<div class='t_img'>"
			+ "<img src='"+parent.mb_trans.src+"' width='"+mod_digitize_width+"' height='0'></div>"
			+ "<div class='t_img'>"
			+ "<img src='"+parent.mb_trans.src+"' width='0' height='"+mod_digitize_height+"'></div>";
	
	var mapObj = parent.mb_mapObj[parent.getMapObjIndexByName(mod_digitize_target)];
	var width = mapObj.width;
	var height = mapObj.height;
	var arrayBBox = mapObj.extent.split(",")
	var minX = parseFloat(arrayBBox[0]);
	var minY = parseFloat(arrayBBox[1]);
	var maxX = parseFloat(arrayBBox[2]);
	var maxY = parseFloat(arrayBBox[3]);
	var cx = width/(maxX - minX);
	var cy = height/(maxY - minY);
	var isMoveOrInsertOrDelete = mod_digitizeEvent == button_move || mod_digitizeEvent == button_insert || mod_digitizeEvent == button_delete;
	var minDist = 6;

	for(var i=0, lenGeomArray = d.count(); i < lenGeomArray; i++){
		var currentGeomArray = d.get(i);

		if (!nonTransactionalEditable && !isTransactional(currentGeomArray)) {
			nonTransactionalHighlight.add(currentGeomArray, nonTransactionalColor);
		}
		else {
			for(var j=0, lenGeom = currentGeomArray.count(); j < lenGeom ; j++){
				var currentGeometry = d.getGeometry(i,j);
				var isPolygon = currentGeomArray.geomType == parent.geomType.polygon;
				var isLine = currentGeomArray.geomType == parent.geomType.line;
				var isComplete = currentGeometry.isComplete();
				var lastPaintedPoint = false;

				for(var k = 0, lenPoint = currentGeometry.count(); k < lenPoint; k++){
					var currentPoint = currentGeometry.get(k);
					var currentPointMap = new Point(Math.round((currentPoint.x - minX)*cx), Math.round((maxY - currentPoint.y)*cy));
					
//					var isTooCloseToPrevious = lastPaintedPoint && (k > 0) && Math.abs(currentPointMap.x-lastPaintedPoint.x) <= minDist && Math.abs(currentPointMap.y-lastPaintedPoint.y) <= minDist;
//					if (!isTooCloseToPrevious) {
						var currentPointIsVisible = currentPointMap.x > 0 && currentPointMap.x < width && currentPointMap.y > 0 && currentPointMap.y < height;
						if (currentPointIsVisible) {
							if (!isComplete && ((k == 0 && isPolygon) || (k == lenPoint-1 && isLine))) {
								smPArray[smPArray.length] = "<div class='bp' style='top:"+
									(currentPointMap.y-2)+"px;left:"+(currentPointMap.x-2)+"px;z-index:"+
									digitizeTransactionalZIndex+";background-color:"+linepointColor+"'";
							}
							else {
								smPArray[smPArray.length] = "<div class='bp' style='top:"+(currentPointMap.y-2)+"px;left:"+(currentPointMap.x-2)+"px;z-index:"+digitizeTransactionalZIndex+";'";
							}
							if(k==0 && isPolygon && !isComplete){
								smPArray[smPArray.length] = " title='"+msgObj.closePolygon_title+"' ";
							}
							if(isMoveOrInsertOrDelete) {
								smPArray[smPArray.length] = " onmouseover='parent.window.frames[\""+mod_digitize_elName+"\"].handleBasepoint(this,"+i+","+j+","+k+")' ;";
							}
							smPArray[smPArray.length] = "></div>";
							lastPaintedPoint = currentPointMap;
						}
						if (k > 0) {
							points = parent.calculateVisibleDash(currentPointMap, previousPointMap, width, height);
							if (points != false) {
								smPArray[smPArray.length] = evaluateDashes(points[0], points[1], i, j, k);
							}
						}
//					}
					var previousPointMap = currentPointMap;
				}
				if (isPolygon && currentGeometry.innerRings.count() > 0) {
					// draw inner rings

					for (var l = 0, lenRings = currentGeometry.innerRings.count(); l < lenRings; l++) {
						var currentRing = currentGeometry.innerRings.get(l);
						var lastPaintedPoint = false;
						
						for (var m = 0, lenPoint = currentRing.count(); m < lenPoint; m++) {
							var currentPoint = currentRing.get(m);
							var currentPointMap = new Point(Math.round((currentPoint.x - minX) * cx), Math.round((maxY - currentPoint.y) * cy));
							
							//					var isTooCloseToPrevious = lastPaintedPoint && (k > 0) && Math.abs(currentPointMap.x-lastPaintedPoint.x) <= minDist && Math.abs(currentPointMap.y-lastPaintedPoint.y) <= minDist;
							//					if (!isTooCloseToPrevious) {
							var currentPointIsVisible = currentPointMap.x > 0 && currentPointMap.x < width && currentPointMap.y > 0 && currentPointMap.y < height;
							if (currentPointIsVisible) {
								if (!isComplete && ((k == 0 && isPolygon) || (k == lenPoint - 1 && isLine))) {
									smPArray[smPArray.length] = "<div class='bp' style='top:" +
									(currentPointMap.y - 2) +
									"px;left:" +
									(currentPointMap.x - 2) +
									"px;z-index:" +
									digitizeTransactionalZIndex +
									";background-color:" +
									linepointColor +
									"'";
								}
								else {
									smPArray[smPArray.length] = "<div class='bp' style='top:" + (currentPointMap.y - 2) + "px;left:" + (currentPointMap.x - 2) + "px;z-index:" + digitizeTransactionalZIndex + ";'";
								}
								if (m == 0 && isPolygon && !isComplete) {
									smPArray[smPArray.length] = " title='" + msgObj.closePolygon_title + "' ";
								}
								if (isMoveOrInsertOrDelete) {
									smPArray[smPArray.length] = " onmouseover='parent.window.frames[\"" + mod_digitize_elName + "\"].handleBasepoint(this," + i + "," + j + "," + l + "," + m + ")' ;";
								}
								smPArray[smPArray.length] = "></div>";
								lastPaintedPoint = currentPointMap;
							}
							if (m > 0) {
								points = parent.calculateVisibleDash(currentPointMap, previousPointMap, width, height);
								if (points != false) {
									smPArray[smPArray.length] = evaluateDashes(points[0], points[1], i, j, l, m);
								}
							}
							//					}
							var previousPointMap = currentPointMap;
						}
					}
				}
			}
		}
	}
	digitizeDivTag.write(smPArray.join(""));
}

function evaluateDashes(start, end, memberIndex, geomIndex, ringIndex, pointIndex){
	if (pointIndex == undefined) {
		pointIndex = ringIndex;
		ringIndex = undefined;
	}
	
	var strArray = [];
	var delta = new parent.Point(end.x - start.x, end.y - start.y);
	var lastGeomIsComplete = d.getGeometry(-1,-1).isComplete(); 
	 
	var vecLength = start.dist(end);
	var n = Math.round(vecLength/dotDistance);
	if (n > 0) {
		var step = delta.dividedBy(n);
	}
	for(var i=1; i < n; i++){
		var x = Math.round(start.x + i * step.x) - 2;
		var y = Math.round(start.y + i * step.y) - 2;
		if(x >= 0 && x <= mod_digitize_width && y >= 0 && y <= mod_digitize_height){
			if (memberIndex == d.count()-1 && !lastGeomIsComplete) {
				strArray[strArray.length] = "<div class='lp' style='top:"+y+"px;left:"+x+"px;z-index:"+digitizeTransactionalZIndex+";background-color:"+linepointColor+"' ";
			}
			else {
				strArray[strArray.length] = "<div class='lp' style='top:"+y+"px;left:"+x+"px;z-index:"+digitizeTransactionalZIndex+";' ";
			}
			if(mod_digitizeEvent == button_insert) {
				strArray[strArray.length] = "onmouseover='parent.window.frames[\""+mod_digitize_elName+"\"].convertLinepointToBasepoint(this,"+memberIndex+","+geomIndex+","+ringIndex+","+pointIndex+")'";
			}
			strArray[strArray.length] = "></div>";
		}
	}
	return strArray.join("");
}

function isTransactional(geom) {
//	alert(typeof(geom.wfs_conf) + " " + geom.wfs_conf + " " + wfsConf.length);
	if (typeof(geom.wfs_conf) == 'number') {
		if (geom.wfs_conf >= 0 && geom.wfs_conf < wfsConf.length) {			
			var isTransactionalGeom = (wfsConf[geom.wfs_conf]['wfs_transaction'] != "" && wfsConf[geom.wfs_conf]['fkey_featuretype_id'] != "");
			if (isTransactionalGeom) {
				return true;
			}
			else{
				return false;
			}
		}
	}
	else if (typeof(geom.wfs_conf) == 'undefined') {
		return true;
	}
}

function isValidWfsConfIndex (wfsConf, wfsConfIndex) {
	return (typeof(wfsConfIndex) == "number" && wfsConfIndex >=0 && wfsConfIndex < wfsConf.length);
}

function getName (geom) {
	wfsConfId = geom.wfs_conf;
	wfsConf = parent.get_complete_wfs_conf();
	if (isValidWfsConfIndex(wfsConf, wfsConfId)) {
		var resultName = "";
		for (var i = 0 ; i < wfsConf[wfsConfId]['element'].length ; i++) {
			if (wfsConf[wfsConfId]['element'][i]['f_show'] == 1) {
				resultName += geom.e.getElementValueByName(wfsConf[wfsConfId]['element'][i]['element_name']) + " ";
			}
		}
		if (resultName == "") {
			resultName = wfsConf[wfsConfId]['g_label'];
		}
		return resultName;
	}
	else if (geom.e.getElementValueByName("name")) {
		return geom.e.getElementValueByName("name");
	}
	else {
		return msgObj.digitizeDefaultGeometryName;
	}
}

function updateListOfGeometries(){
	var listOfGeom = "<ul>";
	if (d.count() > 0) {
		wfsConf = parent.get_complete_wfs_conf();
		for (var i = 0 ; i < d.count(); i ++) {

			if (d.get(i).get(-1).isComplete() && (nonTransactionalEditable || isTransactional(d.get(i)))) {
	
				// for the geometries from a kml, there is another save dialogue
				if (d.get(i).isFromKml()) {
					// if the kml is in the db (id = id in database)
					if (d.get(i).e.getElementValueByName("Mapbender:id")) {
						// button: geometry information, update kml
						listOfGeom += "<li>";
						listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_wfs_src+"' title='"+msgObj.buttonDig_wfs_title+"' onclick='showWfsKml("+i+")'>";
					}
				}
				else {
					// button: geometry information, save, update, delete
					listOfGeom += "<li>";
					if (wfsExistsForGeom(d.get(i), wfsConf)) {
						listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_wfs_src+"' title='"+msgObj.buttonDig_wfs_title+"' onclick='showWfs("+i+")'>";
					}

					// button: remove this geometry
					listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_remove_src+"' title='"+msgObj.buttonDig_remove_title+"' onclick='parent.mb_disableThisButton(mod_digitizeEvent);d.del("+i+");executeDigitizeSubFunctions();'>";

					// button clone this geometry
					if (addCloneGeometryButton === true) {
						listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_clone_src+"' title='"+msgObj.buttonDig_clone_title+"' onclick='d.addCopy(d.get("+i+"));d.get(-1).e.delElement(\"fid\");executeDigitizeSubFunctions();'>";
					}
				}
					
				// button: remove geometry from database
				if (d.get(i).e.getElementValueByName('fid')) {
					listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_removeDb_src+"' title='"+msgObj.buttonDig_removeDb_title+"' onclick=\"var deltrans = confirm('"+msgObj.messageConfirmDeleteGeomFromDb+"');if (deltrans) dbGeom('delete', "+i+")\">";
				}
				listOfGeom += "<div class='digitizeGeometryListItem' onmouseover='parent.mb_wfs_perform(\"over\",d.get("+i+"),\""+geomHighlightColour+"\");' ";
				listOfGeom += " onmouseout='parent.mb_wfs_perform(\"out\",d.get("+i+"),\""+geomHighlightColour+"\")' ";
				listOfGeom += " onclick='parent.mb_wfs_perform(\"click\",d.get("+i+"),\""+geomHighlightColour+"\");' ";
				var geomName = getName(d.get(i)); 
				var currentGeomType;
				if (d.get(i).geomType == parent.geomType.polygon) {
					currentGeomType = msgObj.messageDescriptionPolygon;
				}
				else if (d.get(i).geomType == parent.geomType.line) {
					currentGeomType = msgObj.messageDescriptionLine;
				}
				else if (d.get(i).geomType == parent.geomType.point) {
					currentGeomType = msgObj.messageDescriptionPoint;
				}
				var multi = "";
				if (d.get(i).count() > 1) {
					multi = "multi";
				}
				listOfGeom += ">" + htmlspecialchars(geomName) +" (" + multi + currentGeomType + ")</div>";
				
				// multigeometries
				listOfGeom += "<ul>";
				for (var j = 0; j < d.get(i).count(); j++) {
					var currentGeom = d.get(i).get(j);
					if (d.get(i).count() > 1 || (d.get(i).geomType == geomType.polygon && 
						d.get(i).get(j).innerRings && 
						d.get(i).get(j).innerRings.count() > 0)) {
						listOfGeom += "<li>";
						listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_remove_src+"' title='"+msgObj.buttonDig_remove_title+"' onclick='parent.mb_disableThisButton(mod_digitizeEvent);d.get("+i+").del(" + j + ");executeDigitizeSubFunctions();'>";
						listOfGeom += "<div class='digitizeGeometryListItem' onmouseover='parent.mb_wfs_perform(\"over\",d.get("+i+").get("+j+"),\""+geomHighlightColour+"\");' ";
						listOfGeom += " onmouseout='parent.mb_wfs_perform(\"out\",d.get("+i+").get("+j+"),\""+geomHighlightColour+"\")' ";
						listOfGeom += " onclick='parent.mb_wfs_perform(\"click\",d.get("+i+").get("+j+"),\""+geomHighlightColour+"\");' ";
						listOfGeom += ">" + currentGeomType + "#" + (j+1) +"</div></li>";
					}
					if (d.get(i).geomType == geomType.polygon && 
						d.get(i).get(j).innerRings && 
						d.get(i).get(j).innerRings.count() > 0) {
						listOfGeom += "<ul>";
						for (var k = 0; k < d.get(i).get(j).innerRings.count(); k++) {
							var currentRing = d.get(i).get(j).innerRings.get(k);
							listOfGeom += "<li>";
							listOfGeom += "<img src = '"+buttonDig_imgdir+buttonDig_remove_src+"' title='"+msgObj.buttonDig_remove_title+"' onclick='parent.mb_disableThisButton(mod_digitizeEvent);d.get("+i+").get(" + j + ").innerRings.del(" + k + ");executeDigitizeSubFunctions();'>";
							listOfGeom += "<div class='digitizeGeometryListItem' onmouseover='parent.mb_wfs_perform(\"over\",d.getGeometry("+i+","+j+").innerRings.get(" + k + "),\""+geomHighlightColour+"\");' ";
							listOfGeom += " onmouseout='parent.mb_wfs_perform(\"out\",d.getGeometry("+i+","+j+").innerRings.get(" + k + "),\""+geomHighlightColour+"\")' ";
							listOfGeom += " onclick='parent.mb_wfs_perform(\"click\",d.getGeometry("+i+","+j+").innerRings.get(" + k + "),\""+geomHighlightColour+"\");' ";
							listOfGeom += ">inner ring #" + (k+1) +"</div></li>";
							
						}
						listOfGeom += "</ul>";
					}
				}
				listOfGeom += "</ul>";
				listOfGeom += "</li>";
			}
		}
	}
	listOfGeom += "<ul>";
	parent.writeTag(mod_digitize_elName,"listOfGeometries",listOfGeom);
}
// --- display (end) -----------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------


// -----------------------------------------------------------------------------------------------------------
// --- wfs window (begin) -----------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------------
// --- wfs window form check (begin) -----------------------------------------------------------------------------------------

function formCorrect(doc, formId) {
	var isCorrect = true;
	var errorMessage = "";
	var result;
	var form = doc.getElementById(formId);
	
	result = mandatoryFieldsNotEmpty(doc, form);
	isCorrect = isCorrect && result.isCorrect;
	errorMessage += result.errorMessage;

	//select box is now checked within function mandatoryFieldsNotEmpty
	//result = validBoxEntrySelected(form);
	//isCorrect = isCorrect && result.isCorrect;
	//errorMessage += result.errorMessage;

	result = dataTypeIsCorrect(doc, form);
	isCorrect = isCorrect && result.isCorrect;
	errorMessage += result.errorMessage;

	return {"isCorrect":isCorrect, "errorMessage":errorMessage};
}

function validBoxEntrySelected(form){
	var isCorrect = true;
	var errorMessage = "";
	for (var i = 0; i < form.childNodes.length && isCorrect; i++) {
		if (form.childNodes[i].nodeName.toUpperCase() == "SELECT") {
			if (parseInt(form.childNodes[i].selectedIndex) == 0) {
				return {"isCorrect":false, "errorMessage":errorMessage};
			}
		}
		else if (form.childNodes[i].hasChildNodes()) {
			isCorrect = validBoxEntrySelected(form.childNodes[i]).isCorrect;
		}
	}
	if (!isCorrect) {
		errorMessage = msgObj.messageSelectAnOption + "\n";
	}
	return {"isCorrect":isCorrect, "errorMessage":errorMessage};
}

function mandatoryFieldsNotEmpty(doc, node){
	var isCorrect = true;
	var errorMessage = "";
	
	nodeArray = doc.getElementsByName("mandatory");
	for (var i = 0; i < nodeArray.length && isCorrect; i++) {
		if (nodeArray[i].nodeName.toUpperCase() == "INPUT" && nodeArray[i].type == "hidden" && nodeArray[i].id.substr(0,10) == "mandatory_") {
			var nodeId = nodeArray[i].id.substr(10);
			if (nodeArray[i].value == "true") {
				if (doc.getElementById(nodeId).value == "") {
					isCorrect = false;
					errorMessage += "'"+ doc.getElementById(nodeId).name +"': "+ msgObj.messageErrorFieldIsEmpty +"\n";
				}
			}
		}
		if (nodeArray[i].nodeName.toUpperCase() == "SELECT" && nodeArray[i].type == "hidden" && nodeArray[i].id.substr(0,10) == "mandatory_") {
			var nodeId = nodeArray[i].id.substr(10);
			if (nodeArray[i].value == "true") {
				if (parseInt(form.childNodes[i].selectedIndex) == 0) {
					isCorrect = false;
					errorMessage += "'"+ doc.getElementById(nodeId).name +"': "+ msgObj.messageErrorFieldIsEmpty +"\n";
				}
			}
		}
	}
	return {"isCorrect":isCorrect, "errorMessage":errorMessage};
}

function isInteger(str) {
	if (str.match(/^\d*$/)) {
		return true;
	}
	return false;
}

function isFloat(str) {
	if (isInteger(str)) {
		return true;
	}
	if (str.match(/^\d+\.\d+$/)) {
		return true;
	}
	return false;
}

function replaceCommaByDecimalPoint(str) {
	var patternString = ",";
	var pattern = new RegExp(patternString);
	while (str.match(pattern)) {
		str = str.replace(pattern, ".");
	}
	return str;
}

function dataTypeIsCorrect(doc, node){
	var isCorrect = true;
	var errorMessage = "";
	
	nodeArray = doc.getElementsByName("datatype");
	for (var i = 0; i < nodeArray.length ; i++) {
		if (nodeArray[i].nodeName.toUpperCase() == "INPUT" && nodeArray[i].type == "hidden" && nodeArray[i].id.substr(0,9) == "datatype_") {
			var nodeId = nodeArray[i].id.substr(9);
			var nodeValue = doc.getElementById(nodeId).value;
			
			if (nodeArray[i].value == "int") {
				if (!isInteger(nodeValue)) {
					isCorrect = false;
					errorMessage += "'"+doc.getElementById(nodeId).name+"': "+ msgObj.messageErrorNotAnInteger + "\n";
				}
			}
			else if (nodeArray[i].value == "double" || nodeArray[i].value == "float") {
				nodeValue = replaceCommaByDecimalPoint(nodeValue);
				if (!isFloat(nodeValue)) {
					isCorrect = false;
					errorMessage += "'"+doc.getElementById(nodeId).name+"': "+ msgObj.messageErrorNotAFloat + "\n";
				}
				else {
					doc.getElementById(nodeId).value = nodeValue;
				}
			}
		}
	}
	return {"isCorrect":isCorrect, "errorMessage":errorMessage};
}
// --- wfs window form check (end) -----------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------

function getAvailableWfsForGeom(geom, wfsConf) {
	var wfsConfIndices = [];
	for (var attr in wfsConf) {
		var isTrans = (wfsConf[attr]['wfs_transaction'] != "");
		if (!isTrans) {
			continue;
		}
		if (isValidWfsConfIndex(wfsConf, parseInt(geom.wfs_conf))) {
			
			if (parseInt(geom.wfs_conf) == parseInt(attr)) {
				wfsConfIndices.push(attr);
			}
		}
		else {
			for (var elementIndex = 0; elementIndex < wfsConf[attr]['element'].length ; elementIndex++) {
				var isGeomColumn = (parseInt(wfsConf[attr]['element'][elementIndex]['f_geom']) == 1); 
				if (isGeomColumn) {
					var isMultiPolygon = (
						geom.geomType == parent.geomType.polygon && 
						(
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'MultiPolygonPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'GeometryPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'MultiSurfacePropertyType'
						)
					);
					var isPolygon = (
						geom.geomType == parent.geomType.polygon && 
						geom.count() == 1 && 
						(
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'PolygonPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'GeometryPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'SurfacePropertyType'
						)
					);
					var isMultiLine = (
						geom.geomType == parent.geomType.line && 
						(
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'MultiLineStringPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'GeometryPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'MultiCurvePropertyType'
						)
					);
					var isLine = (
						geom.geomType == parent.geomType.line && 
						geom.count() == 1 && 
						(
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'LineStringPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'GeometryPropertyType' ||
						wfsConf[attr]['element'][elementIndex]['element_type'] == 'CurvePropertyType'
						)
					);
					var isPoint = (geom.geomType == parent.geomType.point && wfsConf[attr]['element'][elementIndex]['element_type'] == 'PointPropertyType');
					var isMultiPoint = (geom.geomType == parent.geomType.point && wfsConf[attr]['element'][elementIndex]['element_type'] == 'MultiPointPropertyType');
//					alert(isMultiPolygon + " " + isPolygon + " " + isMultiLine + " " + isLine + " " + isPoint);
					if (isMultiPolygon || isPolygon || isMultiLine || isLine || isMultiPoint || isPoint || wfsConf[attr]['element'][elementIndex]['element_type'] == 'GeometryPropertyType') {
						
						wfsConfIndices.push(attr);
					}
				}
			}
		}	
	}
	return wfsConfIndices;
}
function wfsExistsForGeom(geom, wfsConf) {
	wfsConfIndices = getAvailableWfsForGeom(geom, wfsConf);
//	alert(wfsConfIndices.join(","));
	if (wfsConfIndices.length > 0) {
		return true;
	}
	return false;
}


function showWfsKml (geometryIndex) {
	wfsKmlWindow = open("", "wfsattributes", "width="+wfsWindowWidth+", height="+wfsWindowHeight+", resizable, dependent=yes, scrollbars=yes");
	wfsKmlWindow.document.open("text/html");
	wfsKmlWindow.document.writeln("<html><head><meta http-equiv='Content-Type' content='text/html; charset=<?php echo CHARSET;?>'></head><body><div id='linkToKml'></div><div id='elementForm'></div></body></html>");
	wfsKmlWindow.document.close();
	
	str = "<form id = 'wmsKmlForm' onsubmit='return false;'><table>";

	var properties = d.get(geometryIndex).e;
	var propertyCount = properties.count();	
	for (var i = 0; i < propertyCount; i++) {
		var key = properties.getName(i);
		var value = properties.getValue(i);
		var expr = /Mapbender:/;
		if (!key.match(expr)) {
			str += "\t\t<tr>\n";
			str += "\t\t\t<td>\n\t\t\t\t<div>" + key + "</div>\n\t\t\t</td>\n";
			str += "\t\t\t<td>\n";
			str += "\t\t\t\t<input id = 'wmskml_" + i + "' name='" + key + "' type='text' size=20 value = '" + value + "'>\n";
			str += "\t\t\t</td>\n\t\t</tr>\n";
		}
	}	

	var updateOnClickText = "this.disabled=true;window.opener.updateKmlInDb("+geometryIndex+", 'update');";
	var deleteOnClickText = "var deltrans = confirm('This geometry will be removed from the KML.');";
	deleteOnClickText += "if (deltrans){";
	deleteOnClickText += "this.disabled=true;window.opener.updateKmlInDb("+geometryIndex+", 'delete')}";
	
	str += "\t\t\t<td><input type='button' name='updateButton' value='Update' onclick=\""+updateOnClickText+"\"/></td>\n";
// delete button not yet implemented
//	str += "\t\t\t<td><input type='button' name='deleteButton' value='Delete' onclick=\""+deleteOnClickText+"\"/></td>\n";
	str += "\t\t\t<td><input type='button' name='abortButton' value='Abort' onclick=\"window.close();\" /></td>\n";

	str += "\t\t</tr>\n";
	str += "\t</table>\n";
	str += "</form>\n";

	wfsKmlWindow.document.getElementById("elementForm").innerHTML = str;
}

//
// this method opens a new window and displays the attributes in wfs_conf
//
function showWfs(geometryIndex) {
	wfsConf = parent.get_complete_wfs_conf();

	wfsWindow = open("", "wfsattributes", "width="+wfsWindowWidth+", height="+wfsWindowHeight+", resizable, dependent=yes, scrollbars=yes");
	wfsWindow.document.open("text/html");
	wfsWindow.focus();
	
	var str = "";
	var strStyle = "";
	var defaultIndex = -1;

	str += "<form id='wfs'>\n";

	//
	// 1. add select box 
	//

	var onChangeText = "document.getElementById('elementForm').innerHTML = ";
	onChangeText += "window.opener.buildElementForm(this.value , " + geometryIndex + ");";
	onChangeText += "window.opener.setWfsWindowStyle(this.value);";
	
	str += "\t<select name='wfs' size='" + wfsConf.length + "'";
	str += " onChange=\""+ onChangeText +"\"";
	str += ">\n\t\t";

	var wfsConfIndices = getAvailableWfsForGeom(d.get(geometryIndex), wfsConf);
//	alert(wfsConfIndices.join(","));
	var selected = false;
	for (var i = 0; i < wfsConfIndices.length ; i++) {
		str += "<option value='" + wfsConfIndices[i] + "'";
		if (!selected) {
			str += " selected";
			selected = true;
			defaultIndex = parseInt(wfsConfIndices[i]);
		}
		str += ">" + wfsConf[wfsConfIndices[i]]['wfs_conf_abstract'];
		str += "</option>\n\t\t";
	}

	
	str += "</select>\n\t\t</form>\n\t";
	str += "<div id='elementForm'>\n</div>";
	
	if (defaultIndex != -1) {
		wfsWindow.document.writeln("<html><head><meta http-equiv='Content-Type' content='text/html; charset=<?php echo CHARSET;?>'><style type='text/css'>"+wfsConf[defaultIndex]['g_style']+"</style></head><body></body></html>");
		wfsWindow.document.write(str);
		wfsWindow.document.close();
		wfsWindow.document.getElementById("elementForm").innerHTML = buildElementForm(defaultIndex, geometryIndex);
	}
	else {
		wfsWindow.document.writeln("<html><head><meta http-equiv='Content-Type' content='text/html; charset=<?php echo CHARSET;?>'><style type='text/css'></style></head><body></body></html>");
		wfsWindow.document.write(str);
		wfsWindow.document.close();
	}
}

function setWfsWindowStyle(wfsConfIndex) {
	wfsWindow.document.getElementsByTagName("style")[0].innerHTML = wfsConf[wfsConfIndex]['g_style'];
}

// returns a form with the elements of a selected wfs
// (if the original wfs is the selected wfs, the values are set too)
function buildElementForm(wfsConfIndex, memberIndex){
	var featureTypeMismatch = false;
	if (parseInt(d.get(memberIndex).wfs_conf) != parseInt(wfsConfIndex)) {featureTypeMismatch = true;}
	var str = "";
	var hasGeometryColumn = false;
	var featureTypeArray = wfsConf[wfsConfIndex];
	var memberElements;
	var fid = false;

	if (!featureTypeMismatch) {
		memberElements = d.get(memberIndex).e;
		fid = memberElements.getElementValueByName('fid');
	}
	
	if (typeof(featureTypeArray["element"]) !== "undefined") {

		str += "<form id='"+featureTypeElementFormId+"'>\n\t<table>\n";
		featureTypeElementArray = featureTypeArray["element"];
		
		//
		// 2. add rows to form 
		//
		for (var i = 0 ; i < featureTypeElementArray.length ; i ++) {
			var featureTypeElement = featureTypeElementArray[i];

			var elementName = featureTypeElement['element_name'];
			var elementType = featureTypeElement['element_type'];
			var isEditable = (parseInt(featureTypeElement['f_edit']) == 1); 
			var isMandatory = (parseInt(featureTypeElement['f_mandatory']) == 1); 
			var isGeomColumn = (parseInt(featureTypeElement['f_geom']) == 1); 

			var elementLabelExists = (featureTypeElement['f_label'] != "");
			var elementLabel = ""; 
			if (elementLabelExists) {
				elementLabel = featureTypeElement['f_label'];
			}
			var elementLabelStyle = featureTypeElement['f_label_id'];

			if (!isGeomColumn) {
				if (isEditable) {
					str += "\t\t<tr>\n";
					str += "\t\t\t<td>\n\t\t\t\t<div class = '"+elementLabelStyle+"''>" + elementLabel + "</div>\n\t\t\t</td>\n";
					str += "\t\t\t<td>\n";

					var elementValue = "";
					if (!featureTypeMismatch) {
						for (var j = 0 ; j < memberElements.count() ; j ++) {
							if (memberElements.getName(j) == featureTypeElement['element_name']) {
								elementValue = memberElements.getValue(j);
							}
						}
					}
					var formElementHtml = featureTypeElement['f_form_element_html']; 
					if (!formElementHtml || !formElementHtml.match(/&lt;select/)) {
						str += "\t\t\t\t<input id = 'datatype_mb_digitize_form_" + elementName + "' name='datatype' type='hidden' value = '" + elementType + "'>\n";
						str += "\t\t\t\t<input id = 'mandatory_mb_digitize_form_" + elementName + "' name='mandatory' type='hidden' value = '" + isMandatory + "'>\n";
						str += "\t\t\t\t<input id = 'mb_digitize_form_" + elementName + "' name='" + elementLabel + "' type='text' class = '"+featureTypeElement['f_style_id']+"' size=20 value = '" + elementValue + "'>\n";
					}
					else {
							while (formElementHtml.match(/\\/)) {
								formElementHtml = formElementHtml.replace(/\\/, "");
							} 
							str += "\t\t\t\t<input id = 'datatype_" + elementName + "' name='datatype' type='hidden' value = '" + elementType + "'>\n";
							str += "\t\t\t\t<input id = 'mandatory_" + elementName + "' name='mandatory' type='hidden' value = '" + isMandatory + "'>\n";
							// preselect the correct entry of the box
							var patternString = "option value( )*=( )*'"+elementValue+"'";
							var pattern = new RegExp(patternString);
							var patternStringForReplace = "option value = '"+elementValue+"'";
							formElementHtml = formElementHtml.replace(pattern, patternStringForReplace+" selected");
							formElementHtml = formElementHtml.replace(/&lt;/g,'<');
							formElementHtml = formElementHtml.replace(/&gt;/g,'>');
							formElementHtml = formElementHtml.replace(/&#039;/g,'\'');
 
							str += formElementHtml;
					}
					str += "\t\t\t</td>\n\t\t</tr>\n";
				}
			}
			else {
				hasGeometryColumn = true;
			}
		}

		//
		// 3. add buttons "save", "update", "delete"
		//
		str += "</table><table>";
		var isTransactional = (featureTypeArray['wfs_transaction']); 
		if (isTransactional) {
			str += "\t\t<tr>\n";

			var options = ["insert", "update", "delete", "abort"];
			for (var i = 0 ; i < options.length ; i++) {
				var onClickText = "this.disabled=true;var result = window.opener.formCorrect(document, '"+featureTypeElementFormId+"');";
				onClickText += 	"if (result.isCorrect) {";
				onClickText += 		"window.opener.dbGeom('"+options[i]+"', "+memberIndex+"); ";
//				onClickText +=      "window.close();";
				onClickText += 	"}";
				onClickText += 	"else {";
				onClickText += 		"alert(result.errorMessage);this.disabled=false;"
				onClickText += 	"}";
				
				if (options[i] == "insert" && hasGeometryColumn && (!fid || showSaveButtonForExistingGeometries)) {
					str += "\t\t\t<td><input type='button' name='saveButton' value='"+msgObj.buttonLabelSaveGeometry+"' onclick=\""+onClickText+"\" /></td>\n";
				}
				
				if (!featureTypeMismatch && fid) {
					if (options[i] == "update" && hasGeometryColumn) {
						str += "\t\t\t<td><input type='button' name='updateButton' value='"+msgObj.buttonLabelUpdateGeometry+"' onclick=\""+onClickText+"\"/></td>\n";
					}
					if (options[i] == "delete"){ 
						var deleteOnClickText = "var deltrans = confirm('"+msgObj.messageConfirmDeleteGeomFromDb+"');";
						deleteOnClickText += "if (deltrans){";
						deleteOnClickText += onClickText + "}";
						str += "\t\t\t<td><input type='button' name='deleteButton' value='"+msgObj.buttonLabelDeleteGeometry+"' onclick=\""+deleteOnClickText+"\"/></td>\n";
					}
				}
				if (options[i] == "abort") {
					str += "\t\t\t<td><input type='button' name='abortButton' value='"+msgObj.buttonLabelAbort+"' onclick=\"window.close();\" /></td>\n";
				}
			}
			str += "\t\t</tr>\n";
		}
		str += "\t</table>\n";
		str += "<input type='hidden' id='fid' value='"+fid+"'>";
//			str += "<input type='text' name='mb_wfs_conf'>";
		str += "</form>\n";
	}
	return str;
}

function dbGeom(type,m) {
	if (typeof(wfsWindow) != 'undefined' && !wfsWindow.closed) {
		d.get(m).wfs_conf = parseInt(wfsWindow.document.forms[0].wfs.options[wfsWindow.document.forms[0].wfs.selectedIndex].value);
		d.get(m).e = new parent.Wfs_element();
	}
	else {
		wfsConf = parent.get_complete_wfs_conf();
	}
	var myconf = wfsConf[d.get(m).wfs_conf];
	
	var mapObjInd = parent.getMapObjIndexByName(mod_digitize_target);

	var proceed = true;
	var patternString = parent.mb_mapObj[mapObjInd].epsg.toUpperCase();
	var pattern = new RegExp(patternString);

	if(!myconf['featuretype_srs'].match(pattern)){
		proceed = confirm(msgObj.errorMessageEpsgMismatch + parent.mb_mapObj[mapObjInd].epsg + " / "+ myconf['featuretype_srs'] + ". Proceed?");
	}
	if (proceed) {
		var fid = false;
		var errorMessage = "";
		if (typeof(wfsWindow) != 'undefined' && !wfsWindow.closed) {
			myform = wfsWindow.document.getElementById(featureTypeElementFormId);
		
			for (var i=0; i<myform.length; i++){
				if (myform.elements[i].id == "fid") {
					fid = myform.elements[i].value;
					if (fid == "false") {
						fid = false;
					}
					else {
						d.get(m).e.setElement('fid', fid);
					}
				}
				else if (myform.elements[i].type == 'text' ){
					if (myform.elements[i].id) {
						var elementId = String(myform.elements[i].id).replace(/mb_digitize_form_/, "");
						d.get(m).e.setElement(elementId, myform.elements[i].value);
					}
					else {
						errorMessage = msgObj.messageErrorFormEvaluation;
					}
				}
				// selectbox
				else if (typeof(myform.elements[i].selectedIndex) == 'number') {
					if (myform.elements[i].id) {
						var elementId = String(myform.elements[i].id).replace(/mb_digitize_form_/, "");
						d.get(m).e.setElement(elementId, myform.elements[i].options[myform.elements[i].selectedIndex].value);
					}
					else {
						errorMessage = msgObj.messageErrorFormEvaluation;
					}
				}
			}
		}
		else {
			fid = d.get(m).e.getElementValueByName('fid');
		}
//		str = parent.get_wfs_str(myconf, d, m, type, fid);
		
		var geoJson = d.featureToString(m);
		
		parent.mb_ajax_post(
			"../extensions/geom2wfst.php", 
			{
				'geoJson' : geoJson,
				'method' : type,
				'wfs_conf_id' : wfsConf[d.get(m).wfs_conf]['wfs_conf_id']
			}, 
			function(json,status){
				var result = eval('('+json+')');
				var success = result.success;
				var fid = result.fid;
				wfsSubWrite(m, type, status, success, fid);
			}
		);
	}
}

function wfsSubWrite(m, type, status, success, fid) {
	if (status == "success" && success) {
		if (type == 'insert' && fid) {
			d.get(m).e.setElement("fid", fid);
		}
		if (type == 'delete') {
			parent.mb_disableThisButton(mod_digitizeEvent);
			d.del(m);
		}
		
		var wfsWriteMessage = msgObj.messageSuccessWfsWrite;
	}
	else {
		var wfsWriteMessage = msgObj.messageErrorWfsWrite;
	} 

	parent.mb_execWfsWriteSubFunctions();
	executeDigitizeSubFunctions();

	if (typeof(wfsWindow) != 'undefined' && !wfsWindow.closed) {
		wfsWindow.alert(wfsWriteMessage);
		window.setTimeout("wfsWindow.close()",0);
	}
	else {
		alert(wfsWriteMessage);
	}
}
function getMultiGeometryIdsByPlacemarkId (placemarkId) {
	var multiGeometryIdArray = [];
	for (var i = 0; i < d.count(); i++) {
		var currentPlacemarkId = d.get(i).e.getElementValueByName("Mapbender:placemarkId");
		if (currentPlacemarkId && currentPlacemarkId == placemarkId) {
			multiGeometryIdArray.push(i);	
		}
	}	
	return multiGeometryIdArray;
}

function updateKmlInDb (geometryIndex, command) {
	var properties = d.get(geometryIndex).e;
	var placemarkId = properties.getElementValueByName("Mapbender:placemarkId");
	
	var multiGeometryIdArray = getMultiGeometryIdsByPlacemarkId(placemarkId);

	if (typeof(wfsKmlWindow) != 'undefined' && !wfsKmlWindow.closed) {

		// update properties from form
		myform = wfsKmlWindow.document.getElementById("wmsKmlForm");
	
		for (var i=0; i < myform.length; i++){
			if (myform.elements[i].type == 'text' ){
				if (myform.elements[i].id) {
					var key = myform.elements[i].name;
					var value = myform.elements[i].value;
					
					// update all geometries with the same placemark id
					for (var j = 0; j < multiGeometryIdArray.length; j++) {
						var currentProperties = d.get(j).e; 
						currentProperties.setElement(key, value);
					}
				}
			}
		}
		var kmlId = properties.getElementValueByName("Mapbender:id");
	
		parent.mb_ajax_post("../php/mod_updateKmlInDb.php", {command:command, kmlId:kmlId, placemarkId:placemarkId, geoJSON:d.placemarkToString(placemarkId)}, function(obj, status) {
			if (obj === "1") {
				wfsKmlWindow.alert("KML updated.");
				var link = wfsKmlWindow.document.createElement("a");
				link.href = "../php/mod_displayKML.php?kmlId=" + kmlId;
				link.target = "_blank";
				link.innerHTML = "KML";
				wfsKmlWindow.document.getElementById('elementForm').innerHTML = "";
				wfsKmlWindow.document.getElementById('linkToKml').appendChild(link);
			}
			else {
				wfsKmlWindow.alert("Error, KML could not be updated. Check your error log.");
			}
		});
	}
}


// --- wfs window (begin) -----------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------

function getMessages() {
	parent.mb_ajax_json("../php/mod_digitize_messages.php", function(obj, status) {
		msgObj = obj;
		applyMessages();
	});
}

function applyMessages() {
	updateMeasureTag();
	updateListOfGeometries();
	updateButtons();
}

	</script>
	</head>
	<body onload="registerFunctions();displayButtons();">
		<div id='digButtons'></div>
		<div id='listOfGeometries' class='digitizeGeometryList'></div>
	</body>
</html>
