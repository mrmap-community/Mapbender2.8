<?php
# $Id: mod_reload.php 2413 2008-04-23 16:21:04Z christoph $
# http://www.mapbender.org/index.php/reload
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
?>
var mod_reload_img = new Image(); 
mod_reload_img.src = "<?php  echo $e_src;  ?>";
var mod_reload_img_over = new Image(); 
mod_reload_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

function mod_reload(){
    location.reload();
}
function mod_reload_init(obj){
	document.getElementById("reload").src = mod_reload_img_over.src;
	obj.onmouseover = new Function("mod_reload_over()");
	obj.onmouseout = new Function("mod_reload_out()");
}
function mod_reload_over(){
	document.getElementById("reload").src = mod_reload_img_over.src;
}
function mod_reload_out(){
	document.getElementById("reload").src = mod_reload_img.src;
}
