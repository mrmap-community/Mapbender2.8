<?php
# $Id: mod_wfs_gazetteer_client.php 4412 2009-07-22 08:09:06Z christoph $
# maintained by http://www.mapbender.org/index.php/User:Verena Diewald
# http://www.mapbender.org/index.php/WFS_gazetteer
# Copyright (C) 2002 CCGIS
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");

$target = $_REQUEST["e_target"];
$isLoaded = $_REQUEST["isLoaded"];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET;?>">
<title>mod_wfs_gazetteer</title>

<?php
include '../include/dyn_css.php';
?>
<script type="text/javascript">
<?php
	include '../include/dyn_js.php';
	include '../include/dyn_php.php';
	include(dirname(__FILE__) . "/../../conf/" . $wfs_spatial_request_conf_filename);

	echo "var targetString = '" . $target . "';";
	echo "var wfsConfIdString = '" . $wfsConfIdString . "';";
	echo "var e_id_css = '" . $e_id_css . "';";
?>

// Element var maxHighlightedPoints
try{
	if (maxHighlightedPoints){
		maxHighlightedPoints = Number(maxHighlightedPoints);

		if (isNaN(maxHighlightedPoints)) {
//			var e = new parent.Mb_warning("mod_wfs_gazetteer_client.php: Element var maxHighlightedPoints must be a number.");
		}
	}
}
catch(e){
	maxHighlightedPoints = 0;
//	var e = new parent.Mb_warning("mod_wfs_gazetteer_client.php: Element var maxHighlightedPoints is not set, see 'edit element vars'.");
}
// Element var showResultInPopup
try {if(showResultInPopup){}}catch(e) {showResultInPopup = 1;}

//element var openLinkFromSearch for opening attribute link directly onclick of searchResult entry
try{
	if (openLinkFromSearch){}
}
catch(e){
	openLinkFromSearch =0;
}

var targetArray = targetString.split(",");
var global_wfsConfObj;
var global_selectedWfsConfId;
var point_px = 10;
var resultGeom = null;
var frameName = e_id_css;
var inputNotEnough = [];

//start button management spatialRequest ////////
var button_point = "point";
var button_polygon = "polygon";
var button_rectangle = "rectangle";
var button_extent = "extent";

var activeButton = null;
var mod_wfs_spatialRequest_geometry = null;
var mod_wfs_spatialRequest_frameName = "";
var mod_wfs_spatialRequest_epsg;
var mod_wfs_spatialRequest_width;
var mod_wfs_spatialRequest_height;

/**
 * This Geometry contains the geometry of the optinal spatial constraint
 */
var spatialRequestGeom = null;

/**
 * Something like box, polygon, point, extent
 */
var spatialRequestType = null;

/**
 * This Geometry contains the result from the WFS request
 */
var geomArray;

var buttonWfs_id = [];
var buttonWfs_on = [];
var buttonWfs_src = [];
var buttonWfs_title_off = [];
var buttonWfs_title_on = [];
var buttonWfs_x = [];
var buttonWfs_y = [];

function addButtonWfs(id, isOn, src, title, x, y) {
	buttonWfs_id.push(id);
	buttonWfs_on.push(isOn);
	buttonWfs_src.push(src);
	buttonWfs_title_off.push(title);
	buttonWfs_title_on.push(title);
	buttonWfs_x.push(x);
	buttonWfs_y.push(y);
}
// end of button management spatialRequest ///////////

parent.mb_registerInitFunctions("window.frames['"+this.name+"'].initModWfsGazetteer()");
parent.mb_registerInitFunctions("window.frames['"+this.name+"'].init_wfsSpatialRequest()");

function init_wfsSpatialRequest() {
		buttonWfs_id = [];
		buttonWfs_on = [];
		buttonWfs_src = [];
		buttonWfs_title_off = [];
		buttonWfs_title_on = [];
		buttonWfs_x = [];
		buttonWfs_y = [];
		addButtonWfs("rectangle", buttonRectangle.status, buttonRectangle.img, buttonRectangle.title, buttonRectangle.x, buttonRectangle.y);
		addButtonWfs("polygon", buttonPolygon.status, buttonPolygon.img, buttonPolygon.title, buttonPolygon.x, buttonPolygon.y);
		addButtonWfs("point", buttonPoint.status, buttonPoint.img, buttonPoint.title, buttonPoint.x, buttonPoint.y);
		addButtonWfs("extent", buttonExtent.status, buttonExtent.img, buttonExtent.title, buttonExtent.x, buttonExtent.y);
		displayButtons();
}

function wfsInitFunction (j) {
	var functionCall = "parent.mb_regButton_frame('initWfsButton', '"+frameName+"', "+j+")";
	var x = new Function ("", functionCall);
	x();
}

function initWfsButton(ind, pos) {
	parent.mb_button[ind] = document.getElementById(buttonWfs_id[pos]);
	parent.mb_button[ind].img_over = buttonWfs_imgdir + buttonWfs_src[pos].replace(/_off/,"_over");
	parent.mb_button[ind].img_on = buttonWfs_imgdir + buttonWfs_src[pos].replace(/_off/,"_on");
	parent.mb_button[ind].img_off = buttonWfs_imgdir + buttonWfs_src[pos];
	parent.mb_button[ind].img_out = buttonWfs_imgdir + buttonWfs_src[pos];
	parent.mb_button[ind].status = 0;
	parent.mb_button[ind].elName = buttonWfs_id[pos];
	parent.mb_button[ind].frameName = frameName;
	parent.mb_button[ind].go = new Function ("requestGeometryHighlight.clean(); wfsEnable(parent.mb_button["+ind+"], " + pos + ")");
	parent.mb_button[ind].stop = new Function ("wfsDisable(parent.mb_button["+ind+"], " + pos + ")");
	var ind = parent.getMapObjIndexByName("mapframe1");
	mod_wfs_spatialRequest_width = parent.mb_mapObj[ind].width;
	mod_wfs_spatialRequest_height = parent.mb_mapObj[ind].height;
	mod_wfs_spatialRequest_epsg = parent.mb_mapObj[ind].epsg;
	parent.mb_registerPanSubElement("measuring");
}

function displayButtons() {
	for (var i = 0 ; i < buttonWfs_id.length ; i ++) {
		if (parseInt(buttonWfs_on[i])==1) {
			var currentImg = document.createElement("img");
			currentImg.id = buttonWfs_id[i];
			currentImg.name = buttonWfs_id[i];
			currentImg.title = buttonWfs_title_off[i];
			currentImg.src = buttonWfs_imgdir+buttonWfs_src[i];
			currentImg.style.margin = "5px";
			currentImg.onmouseover = new Function("wfsInitFunction("+i+")");
			document.getElementById("displaySpatialButtons").appendChild(currentImg);
		}
	}
}

function disableButtons() {
	removeChildNodes(document.getElementById("displaySpatialButtons"));
}

function wfsEnable(obj) {
	var ind = parent.getMapObjIndexByName("mapframe1");
	var el = parent.mb_mapObj[ind].getDomElement();
   	el.onmouseover = null;
   	el.onmousedown = null;
   	el.onmouseup = null;
   	el.onmousemove = null;

	if (obj.id == button_point) {
		if (activeButton == null) {
			activeButton = obj;
		}
	}
	if (obj.id == button_polygon) {
		if (activeButton == null) {
			activeButton = obj;
		}
	}
	else if (obj.id == button_rectangle){
		if (activeButton == null) {
			activeButton = obj;
		}
	}
	else if (obj.id == button_extent){
		if (activeButton == null) {
			activeButton = obj;
		}
	}
	callRequestGeometryConstructor(obj.id,"mapframe1");
}

function callRequestGeometryConstructor(selectedType,target){
		if(document.getElementById("res")){
			document.getElementById("res").innerHTML ="";
			spatialRequestGeom = null;
		}
		if(document.getElementById("spatialResHint")){
			document.getElementById("spatialResHint").innerHTML = "";
		}
		spatialRequestType = selectedType;
		var geometryConstructor = new parent.RequestGeometryConstructor(target);
		geometryConstructor.getGeometry(selectedType,function(target,queryGeom){
			if(queryGeom !=''){
				var spatialRes = document.createElement("span");
				spatialRes.id = "spatialResHint";
				spatialRes.name = "spatialResHint";
				spatialRes.className = "spatialResHint";
				document.getElementById("displaySpatialButtons").appendChild(spatialRes);
				document.getElementById("spatialResHint").innerHTML = "<br><img src='"+spatialRequestIsSetImg+"'></img>"+spatialRequestIsSetMessage;
				spatialRequestGeom = queryGeom;
			}
			parent.mb_disableThisButton(selectedType);

			// spatialRequestGeom is a Geometry, but for the highlight
			// a MultiGeometry is needed.
			var multiGeom;
			// a line represents a bbox...but highlight must be a polyon
			// (extent or box selection)
			if (spatialRequestGeom.geomType == parent.geomType.line) {
				multiGeom = new parent.MultiGeometry(parent.geomType.polygon);
				newGeom = new parent.Geometry(parent.geomType.polygon);
				var p1 = spatialRequestGeom.get(0);
				var p2 = spatialRequestGeom.get(1);
				newGeom.addPoint(p1);
				newGeom.addPointByCoordinates(p1.x, p2.y);
				newGeom.addPoint(p2);
				newGeom.addPointByCoordinates(p2.x, p1.y);
				newGeom.close();
				multiGeom.add(newGeom);
			}
			// standard case
			// (polygon and point selection)
			else {
				multiGeom = new parent.MultiGeometry(spatialRequestGeom.geomType);
				multiGeom.add(spatialRequestGeom);
			}

			// add highlight of geometry
			requestGeometryHighlight.add(multiGeom);
			requestGeometryHighlight.paint();

		});
}

function wfsDisable(obj) {
	var ind = parent.getMapObjIndexByName("mapframe1");
	var el = parent.mb_mapObj[ind].getDomElement();
	el.onmousedown = null;
	el.ondblclick = null;
	el.onmousemove = null;
	parent.writeTag("","measure_display","");
	parent.writeTag("","measure_sub","");
	activeButton = null;
}

function openwindow(url) {
	window1 = window.open(url, "Information", "width=500,height=500,left=100,top=100,scrollbars=yes,resizable=no");
	window1.focus();
}
//----------------------------------------------------------------------------------

function appendWfsConf(newWfsConfIdString) {
	// merge with existing wfs conf ids
	if (wfsConfIdString !== "") {
		if (newWfsConfIdString !== "") {
			wfsConfIdString += "," + newWfsConfIdString;

			// rebuild form
			initModWfsGazetteer();
		}
	}
	else {
		wfsConfIdString = newWfsConfIdString;

		// rebuild form
		initModWfsGazetteer();
	}

}

function removeChildNodes(node) {
	while (node.childNodes.length > 0) {
	  var childNode = node.firstChild;
		node.removeChild(childNode);
	}
}

/**
 * removes whitespaces and endlines before and after a string
 *
 */
function trimString (str) {
	return str.replace(/^\s+|\s+|\n+$/g, '');
}

function appendStyles() {
	var styleObj;
	var rule = global_wfsConfObj[global_selectedWfsConfId].g_style + global_wfsConfObj[global_selectedWfsConfId].g_res_style;
	if (parent.ie) {
		var styleSheetObj=document.createStyleSheet();
		styleObj=styleSheetObj.owningElement || styleSheetObj.ownerNode;
		styleObj.setAttribute("type","text/css");
		ruleArray = rule.split("}");
		for (var i=0; i < ruleArray.length - 1; i++) {
			var currentRule = trimString(ruleArray[i]);
			var nameValueArray = currentRule.split("{");
			var name = nameValueArray[0];
			var value = nameValueArray[1];
			styleSheetObj.addRule(name,value);
		}
	}
	else {
		styleObj=document.createElement("style");
		styleObj.setAttribute("type","text/css");
		document.getElementsByTagName("head")[0].appendChild(styleObj);
		styleObj.appendChild(document.createTextNode(rule+"\n"));
	}
}

//----------------------------------------------------------------------------------


function initModWfsGazetteer() {
	// empty nodes
	var nodesToEmpty = ["selectWfsConfForm", "wfsForm", "res", "wfsIcons"];
	while (nodesToEmpty.length > 0) {
		var currentId = nodesToEmpty.pop();
		var currentNode = document.getElementById(currentId);
		removeChildNodes(currentNode);
	}

	geomArray = new parent.GeometryArray();

	parent.mb_ajax_json("../php/mod_wfs_gazetteer_server.php", {command:"getWfsConf",wfsConfIdString:wfsConfIdString}, function(json, status) {
		global_wfsConfObj = json;
		var wfsCount = 0;
		for (var wfsConfId in global_wfsConfObj) {
			global_selectedWfsConfId = wfsConfId;
			if (typeof(global_wfsConfObj[wfsConfId] != 'function')) {
				wfsCount++;
			}
		}
		if (wfsCount === 0) {
			var e = new parent.Mb_exception("no wfs conf id available.");
		}
		else if (wfsCount === 1) {
			appendStyles();
			appendWfsForm();
		}
		else {
			appendWfsConfSelectBox();

		}
		parent.mb_setWmcExtensionData({"wfsConfIdString":wfsConfIdString});
	});

	// creates a Highlight object for the request geometry
	var styleProperties = {"position":"absolute", "top":"0px", "left":"0px", "z-index":100};
	requestGeometryHighlight = new parent.Highlight(targetArray, "requestGeometryHighlight", styleProperties, 2);
	parent.mb_registerSubFunctions("window.frames['" + frameName +"'].requestGeometryHighlight.paint()");

}

function setWfsInfo() {

	var bodyNode = document.getElementById("wfsIcons");
	removeChildNodes(bodyNode);
	var bulbNode = document.createElement("a");
	bulbNode.name = "wfsInfo";
	bulbNode.id = "wfsInfo";
	bodyNode.appendChild(bulbNode);

	// append bulb image
	removeChildNodes(bulbNode);
	var imgNode = document.createElement("img");
	imgNode.id = "wfsInfoImg";
	//imgNode.src = "../img/button_digitize/geomInfo.png";
	imgNode.src = "../img/tree_new/info.png";
	imgNode.border = 0;
	imgNode.title = "show metadata";
	bulbNode.appendChild(imgNode);
	bulbNode.href = "javascript:openwindow('../php/mod_featuretypeMetadata.php?wfs_conf_id=" + global_selectedWfsConfId.toString() + "');";
	bulbNode.style.visibility = "visible";

	// set image: remove this WFS
	var wfsRemoveNode = document.createElement("img");
	wfsRemoveNode.name = "wfsRemove";
	wfsRemoveNode.id = "wfsRemove";
	wfsRemoveNode.title = "remove WFS Conf";
	bodyNode.appendChild(wfsRemoveNode);
	//wfsRemoveNode.src = "../img/button_digitize/geomRemove.png";
	wfsRemoveNode.src = "../img/tree_new/delete_wms.png";
	wfsRemoveNode.style.visibility = 'visible';
	// Internet explorer
	if (parent.ie) {
		wfsRemoveNode.onclick = function() {
			var x = new Function ("", "delete global_wfsConfObj[global_selectedWfsConfId];setWfsConfIdString();initModWfsGazetteer();parent.mb_setWmcExtensionData({'wfsConfIdString':wfsConfIdString});");
			x();
		};
	}
	// Firefox
	else {
		wfsRemoveNode.onclick = function () {
			delete global_wfsConfObj[global_selectedWfsConfId];
			setWfsConfIdString();
			initModWfsGazetteer();
			parent.mb_setWmcExtensionData({"wfsConfIdString":wfsConfIdString});
		}
	}
	// set wfsGeomType image
	var wfsGeomTypeNode = document.createElement("img");
	wfsGeomTypeNode.name = "wfsGeomType";
	wfsGeomTypeNode.id = "wfsGeomType";
	bodyNode.appendChild(wfsGeomTypeNode);
	var wfsGeomType = "";
	for (var i=0; i < global_wfsConfObj[global_selectedWfsConfId].element.length; i++) {
		if (parseInt(global_wfsConfObj[global_selectedWfsConfId].element[i].f_geom)) {
			wfsGeomType = global_wfsConfObj[global_selectedWfsConfId].element[i].element_type;
		}
	}
	if (wfsGeomType.match(/Point/)) {
		wfsGeomTypeNode.src = "../img/button_digitize/point.png";
		wfsGeomTypeNode.style.visibility = 'visible';
		wfsGeomTypeNode.title = 'Point';
	}
	else if (wfsGeomType.match(/Line/)) {
		wfsGeomTypeNode.src = "../img/button_digitize/line.png";
		wfsGeomTypeNode.title = 'Line';
	}
	else if (wfsGeomType.match(/Polygon/)) {
		wfsGeomTypeNode.src = "../img/button_digitize/polygon.png";
		wfsGeomTypeNode.title = 'Polygon';
	}
	else {
		var e = new parent.Mb_exception("WFS gazetteer: geometry type unknown.");
	}
}

function setWfsConfIdString() {
	var str = [];
	for (var wfsConfId in global_wfsConfObj) {
		global_selectedWfsConfId = wfsConfId;
		if (typeof(global_wfsConfObj[wfsConfId] != 'function')) {
			str.push(wfsConfId);
		}
	}
	wfsConfIdString = str.join(",");
}

function appendWfsConfSelectBox() {
	var selectNode = document.createElement("select");
	selectNode.name = "wfs_conf_sel";
	var wfsFormNode = document.getElementById("selectWfsConfForm");
	if (parent.ie) {
		selectNode.onchange = function() {
		global_selectedWfsConfId = this.value;
     	if(typeof(resultGeometryPopup)!="undefined"){
	 		resultGeometryPopup.destroy();
	 	}
	 	if(typeof(wfsPopup)!="undefined"){
	 		wfsPopup.destroy();
	 	}
    	appendStyles();
		appendWfsForm();
		};
	}
	else{
	   selectNode.setAttribute("onchange", "if(typeof(resultGeometryPopup)!='undefined'){resultGeometryPopup.destroy();}if(typeof(wfsPopup)!='undefined'){wfsPopup.destroy();};global_selectedWfsConfId = this.value;appendStyles();appendWfsForm();");
	}
	var isSelected = false;
	for (var wfsConfId in global_wfsConfObj) {
		var optionNode = document.createElement("option");

		optionNode.value = wfsConfId;
		optionNode.innerHTML = global_wfsConfObj[wfsConfId].wfs_conf_abstract;

		if (!isSelected) {
			optionNode.selected = true;
			isSelected = true;
			global_selectedWfsConfId = wfsConfId;
		}
		selectNode.appendChild(optionNode);
	}

	var form = document.getElementById('selectWfsConfForm');
	form.appendChild(selectNode);

	appendStyles();
	appendWfsForm();
}

function appendWfsForm() {
	if(showWfsIcons) {
		setWfsInfo();
	}
	var form = document.getElementById("wfsForm");
	removeChildNodes(form);
	var resultDiv = document.getElementById("res");
	removeChildNodes(resultDiv);

	var divContainer = document.createElement("div");
	divContainer.className = global_wfsConfObj[global_selectedWfsConfId].g_label_id;

	divContainer.innerHTML = global_wfsConfObj[global_selectedWfsConfId].g_label;

	form.appendChild(divContainer);

	var wfsConfElementArray = global_wfsConfObj[global_selectedWfsConfId].element;

	for (var i = 0; i < wfsConfElementArray.length; i++){
		if (parseInt(wfsConfElementArray[i].f_search)) {
			var spanNode = document.createElement("span");
			spanNode.setAttribute("id", wfsConfElementArray[i].element_name+"Span");
			spanNode.className = wfsConfElementArray[i].f_label_id;
			spanNode.innerHTML = wfsConfElementArray[i].f_label;
			if(wfsConfElementArray[i].f_form_element_html.match(/\<select/)){
				var inputNode = document.createElement("span");
				inputNode.id = wfsConfElementArray[i].element_name+"Select";
				inputNode.innerHTML = wfsConfElementArray[i].f_form_element_html;
			}
			else if(wfsConfElementArray[i].f_form_element_html.match(/checkbox/)){
				var inputNode = document.createElement("span");
				inputNode.id = wfsConfElementArray[i].element_name+"Checkbox";
				inputNode.innerHTML = wfsConfElementArray[i].f_form_element_html;
			}
			else{
				var inputNode = document.createElement("input");
				inputNode.type = "text";
				inputNode.className = wfsConfElementArray[i].f_style_id;
				inputNode.id = wfsConfElementArray[i].element_name;
				if(wfsConfElementArray[i].f_form_element_html.match(/datepicker/)){
					inputNode.readOnly=true;
					inputNode.style.backgroundColor = "#D3D3D3";
					inputNode.title = "Use datepicker for selection of date";
				}
			}
			form.appendChild(spanNode);
			form.appendChild(inputNode);

			//build imgNode for datepicker image
			if(wfsConfElementArray[i].f_form_element_html.match(/datepicker/)){
				var imgNode = document.createElement("span");
				imgNode.id = wfsConfElementArray[i].element_name+"Img";
				imgNode.title = "Click here to open datepicker";
				imgNode.innerHTML = wfsConfElementArray[i].f_form_element_html;
				form.appendChild(imgNode);
			}
			form.appendChild(document.createElement("br"));
		}
	}
	var submitButton = document.createElement("input");
	submitButton.type = "submit";
	submitButton.id = "submitButton";
	submitButton.className = global_wfsConfObj[global_selectedWfsConfId].g_button_id;
	submitButton.value = global_wfsConfObj[global_selectedWfsConfId].g_button;

	form.appendChild(submitButton);

	var delFilterButton = document.createElement("input");
	delFilterButton.type = "button";
	delFilterButton.style.marginLeft = "5px";
	delFilterButton.className = "buttonDelFilter";
	delFilterButton.value = clearFilterButtonLabel;
	// Internet explorer
	if (parent.ie) {
		delFilterButton.onclick = function() {
			var x = new Function ("", "clearFilter();");
			x();
		};
	}
	// Firefox
	else {
		delFilterButton.onclick = function () {
			clearFilter();
		}
	}
 	form.appendChild(delFilterButton);

	checkSrs();
}

function checkSrs(){
	//check SRS
	var ind = parent.getMapObjIndexByName("mapframe1");
	var submit = document.getElementById("submitButton");
	var patternString = parent.mb_mapObj[ind].getSRS().toUpperCase();
	var pattern = new RegExp(patternString);

if(global_wfsConfObj[global_selectedWfsConfId].featuretype_srs.match(pattern) == -1){
		var msg = '<?php echo _mb("Different EPSG of map and wfs featuretype, no spatial request possible!");?>';
		msg += parent.mb_mapObj[ind].getSRS()+"  -  "+global_wfsConfObj[global_selectedWfsConfId].featuretype_srs;
		alert(msg);

		//disable Submit Button
		if(submit)submit.disabled = true;
	}
	else{
		if(submit)submit.disabled = false;
	}
}

function clearFilter(){
	var wfsConfElementArray = global_wfsConfObj[global_selectedWfsConfId].element;
	for (var i = 0; i < wfsConfElementArray.length; i++){
		if (parseInt(wfsConfElementArray[i].f_search)) {
			if(wfsConfElementArray[i].f_form_element_html.match(/checkbox/)){
				var elementArray = document.getElementsByName(wfsConfElementArray[i].element_name);
				for (var j = 0; j < elementArray.length; j++){
					elementArray[j].checked = "";
				}
				document.getElementById('checkAll').checked = "";
			}
			else{
				document.getElementById(wfsConfElementArray[i].element_name).value = "";
			}
		}
	}

	//remove geometry from spatialrequest, remove drawn rectangle or polygon and hint
	spatialRequestGeom = null;
	requestGeometryHighlight.clean();
	requestGeometryHighlight.paint();
	if(document.getElementById('spatialResHint')){
 		document.getElementById("spatialResHint").innerHTML = "";
 	}

	//remove result popup
	if(typeof(resultGeometryPopup)!="undefined"){
 		resultGeometryPopup.destroy();
 	}
 	//remove detail popup
 	if(typeof(wfsPopup)!="undefined"){
 		wfsPopup.destroy();
 	}

 	if(document.getElementById('spatialResHint')){
 		document.getElementById("spatialResHint").innerHTML = "";
 	}
 	document.getElementById("res").innerHTML = "";
}

function getNumberOfFilterParameters(){
	var cnt = 0;
	var el = global_wfsConfObj[global_selectedWfsConfId].element;
	inputNotEnough = [];
	for (var i = 0; i < el.length; i++){

		if( el[i]['f_search'] == 1){
			if(el[i]['f_form_element_html'].match(/\<select/)){
				var elementValue = document.getElementById(el[i]['element_name']).options[document.getElementById(el[i]['element_name']).selectedIndex].value;
    		}
    		else if(el[i]['f_form_element_html'].match(/checkbox/)){
				var elementArray = document.getElementsByName(el[i]['element_name']);
				var selectedVal = [];
				for (var j = 0; j < elementArray.length; j++){
					if (elementArray[j].checked == true){
						selectedVal.push(elementArray[j].value);
					}
				}
				var elementValue = selectedVal.join(",");
			}
			else{
				var elementValue = document.getElementById(el[i]['element_name']).value;
			}

			if (elementValue != '') {
				cnt++;
			}
			if(elementValue.length < el[i]['f_min_input']){
				inputNotEnough.push(el[i]['element_name']+"("+el[i]['f_min_input']+")");
			}
		}
	}

	if(inputNotEnough.length>0){
		alert("Mandatory fields: "+inputNotEnough.join(', '));
		return false;
	}

//	if(spatialRequestGeom == null){
//		alert("Bitte räumliche Eingrenzung vornehmen.");
//		return false;
//	}

	return cnt;
}
function validate(){
	if(geomArray.count()>0){
 		geomArray.empty();
 	}
 	if(typeof(resultGeometryPopup)!="undefined"){
 		resultGeometryPopup.destroy();
 	}
 	if(typeof(wfsPopup)!="undefined"){
 		wfsPopup.destroy();
 	}
	global_resultHighlight = new parent.Highlight(targetArray, "wfs_gazetteer_highlight", {"position":"absolute", "top":"0px", "left":"0px", "z-index":generalHighlightZIndex}, generalHighlightLineWidth);

	var filterParameterCount = getNumberOfFilterParameters();

	if(filterParameterCount == 0 && spatialRequestGeom == null){
	//if(filterParameterCount == 0){
		//alert("Please specify at least one filter attribute.");
		return false;
	}
	else{
		if(inputNotEnough.length==0){
			var andConditions = "";

			var el = global_wfsConfObj[global_selectedWfsConfId].element;
			var srs = global_wfsConfObj[global_selectedWfsConfId].featuretype_srs;
			var ftName = global_wfsConfObj[global_selectedWfsConfId].featuretype_name;

			var pattern = /:[a-zA-Z_]+/;
			var ftns = "";
			if (ftName.match(pattern)) {
				ftns = ftName.replace(pattern, ":");
			}

			for (var i = 0; i < el.length; i++) {
				if (el[i]['f_search'] == 1){
					if(el[i]['f_form_element_html'].match(/\<select/)){
						var elementValue = document.getElementById(el[i]['element_name']).options[document.getElementById(el[i]['element_name']).selectedIndex].value;
	    			}
	    			else if(el[i]['f_form_element_html'].match(/checkbox/)){
						var elementArray = document.getElementsByName(el[i]['element_name']);
						var selectedVal = [];
						for (var j = 0; j < elementArray.length; j++){
							if (elementArray[j].checked == true){
								selectedVal.push(elementArray[j].value);
							}
						}
						var elementValue = selectedVal.join(",");
					}
					else{
						var elementValue = document.getElementById(el[i]['element_name']).value;
					}
				}

				if (el[i]['f_search'] == 1 && elementValue != '') {
					var a = new Array();
					a = elementValue.split(",");
					var orConditions = "";
					for (var j=0; j < a.length; j++) {
						if(el[i]['f_operator']=='bothside'){
							orConditions += "<ogc:PropertyIsLike wildCard='*' singleChar='.' escape='!'>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>*";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "*</ogc:Literal>";
							orConditions += "</ogc:PropertyIsLike>";
					}
						else if(el[i]['f_operator']=='rightside'){
							orConditions += "<ogc:PropertyIsLike wildCard='*' singleChar='.' escape='!'>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "*</ogc:Literal>";
							orConditions += "</ogc:PropertyIsLike>";
						}
						else if(el[i]['f_operator']=='greater_than'){
							orConditions += "<ogc:PropertyIsGreaterThan>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "</ogc:Literal>";
							orConditions += "</ogc:PropertyIsGreaterThan>";
						}
						else if(el[i]['f_operator']=='less_than'){
							orConditions += "<ogc:PropertyIsLessThan>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "</ogc:Literal>";
							orConditions += "</ogc:PropertyIsLessThan>";
						}
						else if(el[i]['f_operator']=='less_equal_than'){
							orConditions += "<ogc:PropertyIsLessThanOrEqualTo>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "</ogc:Literal>";
							orConditions += "</ogc:PropertyIsLessThanOrEqualTo>";
						}
						else if(el[i]['f_operator']=='greater_equal_than'){
							orConditions += "<ogc:PropertyIsGreaterThanOrEqualTo>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "</ogc:Literal>";
							orConditions += "</ogc:PropertyIsGreaterThanOrEqualTo>";
						}
						else if(el[i]['f_operator']=='equal'){
							orConditions += "<ogc:PropertyIsEqualTo>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "</ogc:Literal>";
							orConditions += "</ogc:PropertyIsEqualTo>";
						}
						else{
							orConditions += "<ogc:PropertyIsLike wildCard='*' singleChar='.' escape='!'>";
							orConditions += "<ogc:PropertyName>" + ftns + el[i]['element_name'] + "</ogc:PropertyName>";
							orConditions += "<ogc:Literal>*";
							if(el[i]['f_toupper'] == 1){
								orConditions += a[j].toUpperCase();
							}
							else{
								orConditions += a[j];
							}
							orConditions += "*</ogc:Literal>";
							orConditions += "</ogc:PropertyIsLike>";
						}
					}
					if(a.length > 1){
						andConditions += "<Or>" + orConditions + "</Or>";
					}
					else {
						andConditions += orConditions;
					}
				}
			}

			if(spatialRequestGeom!=null){
				if(spatialRequestGeom.geomType == "polygon"){
					if(buttonPolygon.filteroption=='within'){
						andConditions += "<Within><ogc:PropertyName>";
						for (var j=0; j < el.length; j++) {
							if(el[j]['f_geom']==1){
								andConditions += ftns + el[j]['element_name'];
							}
						}
						andConditions += "</ogc:PropertyName><gml:Polygon srsName=\""+srs+"\">";
						andConditions += "<gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>";
						for(var k=0; k<spatialRequestGeom.count(); k++){
							if(k>0)	andConditions += " ";
							andConditions += spatialRequestGeom.get(k).x+","+spatialRequestGeom.get(k).y;
						}
						andConditions += "</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs>";
						andConditions += "</gml:Polygon></Within>";
					}
					else if(buttonPolygon.filteroption=='intersects'){
						andConditions += "<Intersects><ogc:PropertyName>";
						for (var j=0; j < el.length; j++) {
							if(el[j]['f_geom']==1){
								andConditions += ftns + el[j]['element_name'];
							}
						}
						andConditions += "</ogc:PropertyName><gml:Polygon srsName=\""+srs+"\">";
						andConditions += "<gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>";
						for(var k=0; k<spatialRequestGeom.count(); k++){
							if(k>0)	andConditions += " ";
							andConditions += spatialRequestGeom.get(k).x+","+spatialRequestGeom.get(k).y;
						}
						andConditions += "</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs>";
						andConditions += "</gml:Polygon></Intersects>";
					}
				}
				else if(spatialRequestGeom.geomType == "line"){
					var rectangle = [];
					rectangle = spatialRequestGeom.getBBox();

					if(buttonRectangle.filteroption=='within'){
						andConditions += "<Within><ogc:PropertyName>";
						for (var j=0; j < el.length; j++) {
							if(el[j]['f_geom']==1){
								andConditions += ftns + el[j]['element_name'];
							}
						}
						andConditions += "</ogc:PropertyName><gml:Polygon srsName=\""+srs+"\">";
						andConditions += "<gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>";
						andConditions += rectangle[0].x+","+rectangle[0].y;
						andConditions += " ";
						andConditions += rectangle[0].x+","+rectangle[1].y;
						andConditions += " ";
						andConditions += rectangle[1].x+","+rectangle[1].y;
						andConditions += " ";
						andConditions += rectangle[1].x+","+rectangle[0].y;
						andConditions += " ";
						andConditions += rectangle[0].x+","+rectangle[0].y;
						andConditions += "</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs>";
						andConditions += "</gml:Polygon></Within>";
					}
					else if(buttonRectangle.filteroption=='intersects'){
						andConditions += "<Intersects><ogc:PropertyName>";
						for (var j=0; j < el.length; j++) {
							if(el[j]['f_geom']==1){
								andConditions += ftns + el[j]['element_name'];
							}
						}
						andConditions += "</ogc:PropertyName><gml:Polygon srsName=\""+srs+"\">";
						andConditions += "<gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>";
						andConditions += rectangle[0].x+","+rectangle[0].y;
						andConditions += " ";
						andConditions += rectangle[0].x+","+rectangle[1].y;
						andConditions += " ";
						andConditions += rectangle[1].x+","+rectangle[1].y;
						andConditions += " ";
						andConditions += rectangle[1].x+","+rectangle[0].y;
						andConditions += " ";
						andConditions += rectangle[0].x+","+rectangle[0].y;
						andConditions += "</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs>";
						andConditions += "</gml:Polygon></Intersects>";
					}
				}
				else if(spatialRequestGeom.geomType == "point"){
					var tmp = spatialRequestGeom.get(0);
					var mapPos = parent.makeRealWorld2mapPos("mapframe1",tmp.x, tmp.y);
					var buffer = mb_wfs_tolerance/2;
					var mapPosXAddPix = mapPos[0] + buffer;
					var mapPosYAddPix = mapPos[1] +buffer;
					var mapPosXRemovePix = mapPos[0] - buffer;
					var mapPosYRemovePix = mapPos[1] - buffer;
					var realWorld1 = parent.makeClickPos2RealWorldPos("mapframe1",mapPosXRemovePix,mapPosYRemovePix);
					var realWorld2 = parent.makeClickPos2RealWorldPos("mapframe1",mapPosXAddPix,mapPosYRemovePix);
					var realWorld3 = parent.makeClickPos2RealWorldPos("mapframe1",mapPosXAddPix,mapPosYAddPix);
					var realWorld4 = parent.makeClickPos2RealWorldPos("mapframe1",mapPosXRemovePix,mapPosYAddPix);
					andConditions += "<Intersects><ogc:PropertyName>";
					for (var j=0; j < el.length; j++) {
						if(el[j]['f_geom']==1){
							andConditions += ftns + el[j]['element_name'];
						}
					}
					andConditions += "</ogc:PropertyName><gml:Polygon srsName=\""+srs+"\"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>";
					andConditions += realWorld1[0] + "," + realWorld1[1] + " " + realWorld2[0] + "," + realWorld2[1] +  " ";
					andConditions += realWorld3[0] + "," + realWorld3[1] + " " + realWorld4[0] + "," + realWorld4[1] + " " + realWorld1[0] + "," + realWorld1[1];
					andConditions += "</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></Intersects>";
				}
			}

			if (filterParameterCount > 1 || spatialRequestGeom != null) {
				andConditions = "<And>" + andConditions + "</And>";
			}

			var filter = "<ogc:Filter>"+andConditions+"</ogc:Filter>";

			document.getElementById("res").innerHTML = "<table><tr><td><img src='"+progressIndicatorImg+"'></td><td>"+progressIndicatorText+"</td></tr></table>";
			var parameters = {
				"command" : "getSearchResults",
				"wfs_conf_id" : global_selectedWfsConfId,
				"typename" : global_wfsConfObj[global_selectedWfsConfId].featuretype_name,
				"frame" : this.name,
				"filter" : filter,
				"backlink" : ""
			};
			parent.mb_ajax_get("../php/mod_wfs_gazetteer_server.php", parameters, function (jsCode, status) {
				document.getElementById("res").innerHTML = "<table><tr><td>"+arrangeResultsText+"</td></tr></table>";

				if(status=='success'){
					for (var i=0; i < parent.wms.length; i++) {
						for (var j=0; j < parent.wms[i].objLayer.length; j++) {
							var currentLayer = parent.wms[i].objLayer[j];
							var wms_id = parent.wms[i].wms_id;
							if (currentLayer.gui_layer_wfs_featuretype == global_selectedWfsConfId) {
								var layer_name = currentLayer.layer_name;
								parent.handleSelectedLayer_array(targetArray[0],[wms_id],[layer_name],'querylayer',1);
								parent.handleSelectedLayer_array(targetArray[0],[wms_id],[layer_name],'visible',1);
							}
						}
					}
					var geoObj = eval('(' + jsCode + ')');
		       		if (jsCode) {
			        	if (typeof(geoObj) == 'object') {
			        		geomArray.importGeoJSON(geoObj);
			        		document.getElementById("res").innerHTML = '';
							displayResult(geomArray);
						}
						else {
							document.getElementById("res").innerHTML = '';
							displayResult();
						}
					}
		       		else {
						document.getElementById("res").innerHTML = '';
						alert("No results.");
					}
		       	}
			});
		}
		else{
			return false;
		}
	}
	//spatialRequestGeom = null;
	return false;
}

function displayResult(geom){
	geomArray = geom;
	if(geomArray!=null && geomArray.count()>0){
		var contentHtml = createListOfGeometries();
	}
	else{
		var contentHtml = "No results.";
	}

	if(showResultInPopup==1){
		if (typeof(resultGeometryPopup) == "undefined") {
			resultGeometryPopup = new parent.mb_popup(searchPopupTitle,contentHtml,searchPopupWidth,searchPopupHeight,searchPopupX,searchPopupY);
		}
		else {
			resultGeometryPopup.destroy();
			resultGeometryPopup = new parent.mb_popup(searchPopupTitle,contentHtml,searchPopupWidth,searchPopupHeight,searchPopupX,searchPopupY);
		}
		resultGeometryPopup.show();
		parent.$("#resultTable").tablesorter({
     		sortList: [[0,0]],
     		widgets: ['zebra']
        });
	}
	else{
		document.getElementById("res").innerHTML = contentHtml;
	}
}

function createListOfGeometries(){
	if(showResultInPopup==1){
		var domPath = "window.frames['"+frameName+"'].";
	}
	else{
		var domPath = "";
	}
	var listOfGeom = "<form name='resultListForm'><table class='tablesorter' id='resultTable'>\n";
	var wfsConf = global_wfsConfObj[global_selectedWfsConfId];
	var labelArray = [];
	if (geomArray.count() > 0) {

		if(showResultInPopup==1){
			listOfGeom += "<thead><tr>";
			var labelObj = getListTitle();
			for (var k = 1 ; k < labelObj.length; k ++) {
				listOfGeom += "<th>";
				listOfGeom += labelObj[k];
				listOfGeom += "</th>";
			}
			listOfGeom += "</tr></thead>";
		}
		listOfGeom += "<tbody>";
		for (var i = 0 ; i < geomArray.count(); i ++) {
			if (geomArray.get(i).get(-1).isComplete()) {
				listOfGeom += "<tr>\n";
				var resultElObj = getListValues(geomArray.get(i));
				for (var l = 1 ; l < resultElObj.length; l ++) {
					if(resultElObj[l]!=''){
						listOfGeom += "<td style='cursor:pointer;\n";
						if(showResultInPopup==1){
							if ((i % 2) === 0) {
								listOfGeom += "' class='even'";
							}
							else {
								listOfGeom += "' class='odd'";
							}
						}
						else{
							if ((i % 2) === 0) {
								listOfGeom += "' class='even'";
							}
							else {
								listOfGeom += "' class='uneven'";
							}
						}
						listOfGeom += " onmouseover=\""+domPath+"setResult('over',"+i+")\" ";
						listOfGeom += " onmouseout=\""+domPath+"setResult('out',"+i+")\" ";
						listOfGeom += " onclick=\""+domPath+"setResult('click',"+i+"); "+domPath+"showWfs("+i+");\" ";
						listOfGeom += ">"+ resultElObj[l] +"</td>";
					}
				}
				listOfGeom += "\t</tr>\n";
			}
		}
	}
	listOfGeom += "</tbody></table></form>\n";
	return listOfGeom;
}

function getListTitle(){
	var wfsConf = global_wfsConfObj[global_selectedWfsConfId];
	var labelArray = [];
	for (var j = 0 ; j < wfsConf.element.length ; j++) {
		if(wfsConf.element[j].f_show == 1 && wfsConf.element[j].f_label!=''){
			var labelPos = wfsConf.element[j].f_respos;
			labelArray[labelPos] = wfsConf.element[j].f_label;
		}
	}
	return labelArray;
}

function getListValues(geom){
	var wfsConf = global_wfsConfObj[global_selectedWfsConfId];
	var resultArray = [];
	for (var i = 0 ; i < wfsConf.element.length ; i++) {
		if (wfsConf.element[i].f_show == 1 && geom.e.getElementValueByName(wfsConf.element[i].element_name) !=false) {
			var pos = wfsConf.element[i].f_respos;
			if(pos>0){
				resultArray[pos] = geom.e.getElementValueByName(wfsConf.element[i].element_name);
			}
		}
	}
	return resultArray;
}

function showWfs(geometryIndex) {
	var wfsConf = global_wfsConfObj[global_selectedWfsConfId];
	var wfsElement = geomArray.get(geometryIndex).e;
	var showDetailsObj = [];
	var details = 0;
	for (var i = 0 ; i <wfsConf.element.length; i ++) {
		if(wfsConf.element[i].f_show_detail == 1 && wfsElement.getElementValueByName(wfsConf.element[i].element_name)!=''){
			var elPos = wfsConf.element[i].f_detailpos;
			if(elPos>0){
				var currentObj = {};
//				showDetailsObj[elPos] = {};
				currentObj.elPos = elPos;
				currentObj.data = {};
				//var elementVal = wfsElement.getElementValueByName(wfsConf.element[i].element_name);
				//showDetailsObj[elPos][wfsConf.element[i].f_label] = elementVal;
				if(wfsConf.element[i].f_form_element_html.indexOf("href")!=-1){
					var newPath = wfsElement.getElementValueByName(wfsConf.element[i].element_name);
					var setUrl = wfsConf.element[i].f_form_element_html.replace(/href\s*=\s*['|"]\s*['|"]/, "href='"+newPath+"' target='_blank'");
					if(setUrl.match(/><\/a>/)){
						var newLink	=	setUrl.replace(/><\/a>/, ">"+wfsElement.getElementValueByName(wfsConf.element[i].element_name)+"</a>");
					}
					else{
						var newLink = setUrl;
					}
					if(openLinkFromSearch=='1'){
						window.open(elementVal, elementVal,"width=500, height=400,left=100,top=100,scrollbars=yes");
					}
//					showDetailsObj[elPos][wfsConf.element[i].f_label] =  newLink;
					currentObj.data[wfsConf.element[i].f_label] = newLink;
				}
				else{
//					showDetailsObj[elPos][wfsConf.element[i].f_label] = wfsElement.getElementValueByName(wfsConf.element[i].element_name);
					currentObj.data[wfsConf.element[i].f_label] = wfsElement.getElementValueByName(wfsConf.element[i].element_name);
				}
				showDetailsObj.push(currentObj);
			}
		}
	}
	var resultHtml = "";
	resultHtml += "<table style='background-color:#EEEEEE;'>\n";

	showDetailsObj.sort(showDetailObjSort);
	for (var i=0; i < showDetailsObj.length; i++) {
//		var currentDetail = showDetailsObj[elPos];
		var currentDetail = showDetailsObj[i].data;
		for(var key in currentDetail){
			var currentDetailName = key;
			var currentDetailValue = currentDetail[key];
			resultHtml +="<tr><td>\n";
			resultHtml += currentDetailName;
			resultHtml +="</td>\n";
			resultHtml += "<td>\n";
			resultHtml += currentDetailValue;
			resultHtml += "</td></tr>\n";
		}
	}
	resultHtml += "</table>\n";
	if(showResultInPopup==1 && showDetailsObj.length > 0){
		if (typeof(wfsPopup) == "undefined") {
			wfsPopup = new parent.mb_popup(detailPopupTitle,resultHtml,detailPopupWidth,detailPopupHeight,detailPopupX,detailPopupY);
		}
		else {
			wfsPopup.destroy();
			wfsPopup = new parent.mb_popup(detailPopupTitle,resultHtml,detailPopupWidth,detailPopupHeight,detailPopupX,detailPopupY);
		}
		wfsPopup.show();
	}
}

function showDetailObjSort (a, b) {
	return (parseInt(a.elPos) - parseInt(b.elPos));
}

/*
* event -> {over || out || click}
* geom -> commaseparated coordinates x1,y1,x2,y2 ...
*/
function setResult(event, index){
	var currentGeom = geomArray.get(index);
	if (maxHighlightedPoints > 0 && currentGeom.getTotalPointCount() > maxHighlightedPoints) {
		currentGeom = currentGeom.getBBox4();
	}
	if (event == "over") {
		global_resultHighlight.add(currentGeom, generalHighlightColor);
		global_resultHighlight.paint();
	}
	else if (event == "out"){
		global_resultHighlight.del(currentGeom, generalHighlightColor);
		global_resultHighlight.paint();
	}
	else if (event == "click"){
		global_resultHighlight.del(currentGeom, generalHighlightColor);
		var bbox = currentGeom.getBBox();
		var bufferFloat = parseFloat(global_wfsConfObj[global_selectedWfsConfId].g_buffer);
		var buffer = new parent.Point(bufferFloat,bufferFloat);
		bbox[0] = bbox[0].minus(buffer);
		bbox[1] = bbox[1].plus(buffer);
		parent.mb_calculateExtent(targetArray[0], bbox[0].x, bbox[0].y, bbox[1].x, bbox[1].y);
		parent.zoom(targetArray[0], 'true', 1.0);
		global_resultHighlight.add(currentGeom, generalHighlightColor);
		global_resultHighlight.paint();
	}
	return true;
}
function callPick(obj){
	dTarget = obj;
	var dp = window.open('../tools/datepicker/datepicker.php?m=Jan_Feb_Mar_Apr_May_June_July_Aug_Sept_Oct_Nov_Dec&d=Mon_Tue_Wed_Thu_Fri_Sat_Sun&t=today','dp','left=200,top=200,width=230,height=210,toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0');
	dp.focus();
	return false;
}

</script>
</head>
<body>
<form name='selectWfsConfForm' id='selectWfsConfForm'></form>
<div class='wfsIcons' name='wfsIcons' id='wfsIcons'></div>
<div class='spatialButtons' name='displaySpatialButtons' id='displaySpatialButtons'></div>
<form name='wfsForm' id='wfsForm' onsubmit='return validate()'>
</form>
<div class='resultDiv' name='res' id='res'></div>
</body>
</html>
