<?php
# $Id: mod_loadwmc.php 3669 2009-03-11 14:46:07Z christoph $
# http://www.mapbender.org/index.php/mod_loadwmc.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
require_once(dirname(__FILE__)."/../classes/class_wmc.php");

include(dirname(__FILE__) . "/../include/dyn_js.php");

function createJs ($mergeWms) {
	$jsString = "";
	$wmc = new wmc();
	if (!isset($_SESSION['mb_wmc'])) {
		$e = new mb_notice("wmc not set, generating from app: " . $_SESSION["mb_user_gui"]);
		$wmc->createFromApplication($_SESSION["mb_user_gui"]);		
		$_SESSION["mb_wmc"] = $wmc->toXml();
		$e = new mb_notice("creating initial WMC.");
	}

	if (isset($_SESSION['mb_wmc'])) {

		if ($wmc->createFromXml($_SESSION['mb_wmc'])) {
	
			if ($mergeWms) {
				$e = new mb_notice("merging with WMS.");
				$wmsArray = array();
				for ($i = 0; $i < count($_SESSION["wms"]); $i++) {
					$currentWms = new wms();
					$currentWms->createObjFromXML($_SESSION["wms"][$i]);
					array_push($wmsArray, $currentWms);
				}
				$wmc->mergeWmsArray($wmsArray);
				$_SESSION["command"] = "";
				$_SESSION["wms"] = array();
			}
	
			$javaScriptArray = array();
			$javaScriptArray = $wmc->toJavaScript();

			$jsString .= implode("", $javaScriptArray);
		}
		else {
			$jsString .= "var e = new Mb_notice('mod_loadwmc: load_wmc_session: error parsing wmc');";
		}
	}
	else {
		$jsString .= "var e = new Mb_warning('mod_loadwmc: load_wmc_session: no wmc set!');";
	}
	return $jsString;
}

//
// Creates the function load_wmc_session.
// This function loads a WMC from the session, if the element var
// "loadFromSession" is set to true.
//
?>
function load_wmc_session() {
<?php
if ($_SESSION["command"] && $_SESSION["command"] == "ADDWMS") {
	$e = new mb_notice("merging with WMS in Session...");
	$output = createJs(true);
}
else {
	$e = new mb_notice("NOT merging with WMS in Session...");
	$output = createJs(false);
}

$output = administration::convertOutgoingString($output);
echo $output;

?>
}

<?php 
if ($e_src) {
	sprintf("var mod_loadwmc_img = new Image(); 
			mod_loadwmc_img.src = '%s'", $e_src);
	
}

//
// Creates a pop up with a dialogue to load, view or delete WMC documents
//
include("mod_loadwmc.js");
?>