<?php
require(dirname(__FILE__)."/../php/mb_validatePermission.php");
?>
mb_registerInitFunctions("mb_log_init()");
function mb_log_init(){
	mb_log = "mb_log_set";
}
try{if(logtype){}}catch(e){logtype="";}
function mb_log_set(req, time_client){
	var url = "../php/mod_log.php?<?php echo $urlParameters;?>&req=" + escape(req) + "&time_client=" + time_client;
	mb_ajax_post(url, {req:req, time:time_client});
	return true;
}