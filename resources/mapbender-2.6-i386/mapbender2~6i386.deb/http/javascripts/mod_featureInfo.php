<?php
# $Id: mod_featureInfo.php 3224 2008-11-12 08:50:12Z christoph $
# http://www.mapbender.org/index.php/mod_featureInfo.php
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
include '../include/dyn_js.php';
//defaults for element vars
?>
if(typeof(featureInfoLayerPopup)==='undefined')
	var featureInfoLayerPopup = 'false';
if(typeof(featureInfoPopupHeight)==='undefined')
	var featureInfoPopupHeight = '200';
if(typeof(featureInfoPopupWidth)==='undefined')
	var featureInfoPopupWidth = '270';

var mod_featureInfo_elName = "featureInfo1";
var mod_featureInfo_frameName = "";
var mod_featureInfo_target = "<?php echo $e_target[0]; ?>";
var mod_featureInfo_mapObj = null;

var mod_featureInfo_img_on = new Image(); mod_featureInfo_img_on.src =  "<?php  echo preg_replace("/_off/","_on",$e_src);  ?>";
var mod_featureInfo_img_off = new Image(); mod_featureInfo_img_off.src ="<?php  echo $e_src;  ?>";
var mod_featureInfo_img_over = new Image(); mod_featureInfo_img_over.src = "<?php  echo preg_replace("/_off/","_over",$e_src);  ?>";

function init_featureInfo1(ind){
	mod_featureInfo_mapObj = getMapObjByName(mod_featureInfo_target);
	
	mb_button[ind] = document.getElementById(mod_featureInfo_elName);
	mb_button[ind].img_over = mod_featureInfo_img_over.src;
	mb_button[ind].img_on = mod_featureInfo_img_on.src;
	mb_button[ind].img_off = mod_featureInfo_img_off.src;
	mb_button[ind].status = 0;
	mb_button[ind].elName = mod_featureInfo_elName;
	mb_button[ind].fName = mod_featureInfo_frameName;
	mb_button[ind].go = new Function ("mod_featureInfo_click()");
	mb_button[ind].stop = new Function ("mod_featureInfo_disable()");
}
function mod_featureInfo_click(){   
	mod_featureInfo_mapObj.getDomElement().onclick = mod_featureInfo_event;
}
function mod_featureInfo_disable(){
	mod_featureInfo_mapObj.getDomElement().onclick = null;
}
function mod_featureInfo_event(e){
	var point = mod_featureInfo_mapObj.getMousePos(e);
	
	eventBeforeFeatureInfo.trigger({"fName":mod_featureInfo_target});
	
//TODO that code should go to featureInfo Redirect module
	if(document.getElementById("FeatureInfoRedirect")){
		//fill the frames
		for(var i=0; i<mod_featureInfo_mapObj.wms.length; i++){
			var req = mod_featureInfo_mapObj.wms[i].getFeatureInfoRequest(mod_featureInfo_mapObj, point);
			if(req)
				window.frames.FeatureInfoRedirect.document.getElementById(mod_featureInfo_mapObj.wms[i].wms_id).src = req;
		}
	}
	else{
		urls = mod_featureInfo_mapObj.getFeatureInfoRequests(point);
		if(urls){
			for(var i=0;i<urls.length;i++){
				if(featureInfoLayerPopup == 'true'){
					var p = new mb_popup({
						title:<?php echo _mb("Informations");?>,
						url:urls[i],
						width:parseInt(featureInfoPopupWidth, 10),
						height:parseInt(featureInfoPopupHeight, 10),
						top:200,
						left:600
					});
				}
				else
					window.open(urls[i], "" , "width="+featureInfoPopupWidth+",height="+featureInfoPopupHeight+",scrollbars=yes,resizable=yes");
			}
		}
		else
			alert(unescape("Please select a layer! \n Bitte waehlen Sie eine Ebene zur Abfrage aus!"));
	}
	setFeatureInfoRequest(mod_featureInfo_target,clickX,clickY);
}
