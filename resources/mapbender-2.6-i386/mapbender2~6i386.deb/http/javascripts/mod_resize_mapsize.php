<?php
# $Id:mod_resize_mapsize.php 1964 2008-01-15 08:11:29Z christoph $
# http://www.mapbender.org/index.php/ResizeMapsize
# Created on 12.07.2006/07:32:08
# Copyright (C) 2002 CCGIS 
# Projekt: mapbender
# File: mod_resize_mapsize.php
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

require_once(dirname(__FILE__)."/../php/mb_validatePermission.php");
include(dirname(__FILE__) . "/../include/dyn_js.php");

$sqltarget = "SELECT e_target FROM gui_element WHERE e_id = 'resizeMapsize' AND fkey_gui_id = $1";
$v = array($gui_id);
$t = array('s');
$res = db_prep_query($sqltarget, $v, $t);
while($row = db_fetch_array($res)){
	$e_target = $row["e_target"];
}

$sql = "SELECT e_left, e_top FROM gui_element WHERE e_id = '".$e_target."' AND fkey_gui_id = $1";
$v = array($gui_id);
$t = array('s');
$res = db_prep_query($sql, $v, $t);
while($row = db_fetch_array($res)){
	$e_left = $row["e_left"];
	$e_top = $row["e_top"];
}

$sqllegend = "SELECT e_width FROM gui_element WHERE e_id = 'legend' AND fkey_gui_id = $1";
$v = array($gui_id);
$t = array('s');
$res = db_prep_query($sqllegend, $v, $t);
while($row = db_fetch_array($res)){
	$leg_e_width = $row["e_width"];
}

?>
try{
	if (resize_option){}
}
catch(e){
	resize_option = "auto";
}

try{
	if (adjust_width){}
}
catch(e){
	adjust_width = "-45";
}

try{
	if (adjust_height){}
}
catch(e){
	adjust_height = "-35";
}
var map_frame = "<?php echo $e_target ?>";
var map_frame_left = "<?php echo $e_left ?>";
var map_frame_top = "<?php echo $e_top ?>";
var legend_width = "<?php echo $leg_e_width ?>";

function frameWidth(){
  	if (window.innerWidth) return window.innerWidth;
  	else if (document.body && document.body.offsetWidth)  return document.body.offsetWidth;
  	else return 0;
}

function frameHeight(){
  	if (window.innerHeight)return window.innerHeight;
	else if (document.body && document.body.offsetHeight) return document.body.offsetHeight;
    else return 0;
}

function adjustDimension(skipMapRequest){
	var ind = getMapObjIndexByName("<?php  echo $e_target;  ?>");
	var mapheight = frameHeight() - <?php echo $e_top ?> + parseInt(adjust_height);
	var mapwidth = frameWidth() - map_frame_left - legend_width + parseInt(adjust_width) ;
	var coords = mb_mapObj[ind].extent.split(",");
	midcoordx=parseFloat((parseFloat(coords[2])-parseFloat(coords[0]))/2)+parseFloat(coords[0]);
	midcoordy=parseFloat((parseFloat(coords[3])-parseFloat(coords[1]))/2)+parseFloat(coords[1]);
	mb_mapObj[ind].setWidth(mapwidth);
	mb_mapObj[ind].setHeight(mapheight);
	if (!skipMapRequest) {
		mb_mapObj[ind].repaintScale(midcoordx,midcoordy,mb_mapObj[ind].getScale("skipEpsg4326"));
	}
}

function rebuild() {
  	if (width_temp != frameWidth() || height_temp != frameHeight()) window.setTimeout('adjustDimension()', 500);
}

function control(skipMapRequest){
  	adjustDimension(skipMapRequest);
	if (!window.width_temp && window.innerWidth) {
  	    window.onresize = rebuild;
  	    width_temp = frameWidth();
  	    height_temp = frameHeight();
    }

    if (!window.width_temp && document.body && document.body.offsetWidth) {
  	    window.onresize = rebuild;
  	    width_temp = frameWidth();
  	    height_temp = frameHeight();
    }
}
if (resize_option == 'auto'){
	eventInit.register(function() {
		control(true);
	});
}
