<?php
# $Id: index.php 3577 2009-02-18 17:41:07Z christoph $
# maintained by http://www.mapbender.org/index.php/User:Astrid_Emde
# http://www.mapbender.org/index.php/Mapbender_Portal
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

include_once(dirname(__FILE__)."/../core/system.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//Dtd HTML 4.01 Transitional//EN">
<html>
<head>
<!-- 
Licensing: See the GNU General Public License for more details.
http://www.gnu.org/copyleft/gpl.html
or:
mapbender/licence/ 
-->
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Welcome to the Mapbender Portal</title>
<link rel="stylesheet" type="text/css" href="css/mapbender.css" />
<script type="text/javascript">
<!--
function changeTarget()
{
	if (window.frames[0].document.forms['loginForm'].target){  
		window.frames['login'].document.forms['loginForm'].setAttribute("target","_blank");
	}
	else{
		window.frames[0].document.forms['loginForm'].setAttribute("target","_blank");
	}
}
// -->
</script>
<body onload='changeTarget()'>

<table  BGCOLOR="#ffffff" width="70%" height="70%" ALIGN="top" CELLSPACING="0" CELLPADDING="10" STYLE="-moz-border-radius:8px; border:2px #000000 solid;">
<tr><td COLSPAN="2" VALIGN="center" STYLE="margin-bottom:0px; padding-bottom:0px;">
<div class="mapbender_headline" >
	<font align="left" color="#000000">&nbsp;Ma</font><font color="#0000CE">p</font><font color="#C00000">b</font><font color="#000000">ender</font>
</div>

<hr STYLE="color:#629093; height:2px; margin:0px; padding:0px;" WIDTH="100%" NOSHADE COLOR="#808080">
</td></tr>
<tr><td WIDTH="210" VALIGN="TOP">
<table width="92%" height="99%" cellspacing="1" cellpadding="3" STYLE="-moz-border-radius:8px; border:2px #808080 solid;">
<tr>
	<td bgcolor="#F0F0F0" valign="top">
		<br>
		<a href="http://www.mapbender.org" target="_blank"><b>Homepage</b></a><br>
		<br>
		<a href="http://www.mapbender.org/index.php/Tutorials" target="_blank"><b>Documentation</b></a><br>
		<br>
		<a href="http://www.mapbender.org/Mapbender_Gallery" target="_blank"><b>Application Gallery</b></a><br>
		<br>
		<a href="http://wms.wheregroup.com/mapbender/frames/login.php?name=mb&password=mb&mb_user_myGui=mapbender_user" target="_blank"><b>Mapbender User Map</b></a><br>
		<br>
		<a href="http://mapbender.osgeo.org" target="_blank"><b>Mapbender on OSGeo</b></a><br>		
		<br>
		<br>
		<br>
		<a href="http://www.mapbender.org/download/" target="_blank"><b>Download</b></a><br>
		<br>
		<a href="http://www.mapbender.org/index.php/SVN" target="_blank"><b>Source Code Repository</b></a><br>
		<br>
		<a href="http://lists.osgeo.org/mailman/listinfo/mapbender_users" target="_blank"><b>User Mailing List</b></a><br>
		<br>
		<a href="http://lists.osgeo.org/mailman/listinfo/mapbender_dev" target="_blank"><b>Devel Mailing List</b></a><br>
		<br>
		<a href="http://www.mapbender.org/index.php/Bugs" target="_blank"><b>Bug &amp; Issue Tracker</b></a><br>
		<br>
		<br>
		<br>
		<a href="http://mapbender.telascience.org/" target="_blank"><b>Mapbender Development Server</b></a><br>
		<br>
		<br>
		<a href="http://www.osgeo.org" title="Open Source Geospatial Foundation" alt="Link to the OSGeo Portal" target="_blank">
		<br>
		<img  title="OSGeo logo" src = "./img/OSGeo_150pix.png">
		</a>
		<br><br>
		Mapbender is an official OSGeo Project licensed under the <a href="http://www.gnu.org/licenses/licenses.html#GPL" title="GNU GPL license" alt="Link to the GNU license">GNU GPL</a>
		<br>
	</td>
</tr>
</table>
<br>
<br>
</td>

<td WIDTH="480" VALIGN="TOP" STYLE="line-height:133%">
<div>
	<table width="93%" cellspacing="1" cellpadding="5" STYLE="-moz-border-radius:8px; border:2px #808080 solid;">
		<tr><td bgcolor="#F0F0F0">
		
			<div class="mapbender_welcome">Welcome to <font align="left" color="#000000">Ma</font><font color="#0000CE">p</font><font color="#C00000">b</font><font color="#000000">ender</font></div>
		
		<font color="#ff0000">Mapbender Version <?php echo MB_VERSION_NUMBER." ".MB_VERSION_APPENDIX?> (<?php echo date("F jS, Y",MB_RELEASE_DATE);?>)</font>
		</td></tr>
	</table>
<br>

<table width="93%" cellspacing="1" cellpadding="5" STYLE="-moz-border-radius:8px; border:1px #808080 solid;">
<tr><td bgcolor="#ffffff">
<p>
	<font align="left" color="#000000">Ma</font><font color="#0000CE">p</font><font color="#C00000">b</font><font color="#000000">ender</font> is the geospatial portal site management software for OGC OWS architectures. Mapbender comes with a data model to manage interfaces for displaying, navigating and querying OGC compliant web map and feature services (WMS and transactional WFS). Authentication and authorization are used by the <a href="http://www.mapbender.org/index.php/Mapbender_Security_Proxy" title="Mapbender OWS Security Proxy">OWS Security Proxy</a> and management interfaces for multi client capable user, group and service administration. The embedded metadata component follows ISO 19119 specification.
</p>
</td></tr>
</table>
<br>
<table width="93%" cellspacing="1" cellpadding="4" STYLE="-moz-border-radius:6px; border:1px #808080 solid;">
	<tr><td bgcolor="#ffffff">
	<font align="left" color="#000000">Ma</font><font color="#0000CE">p</font><font color="#C00000">b</font><font color="#000000">ender</font> Login
	<br>
	<iframe  id='login' name='login' scrolling="no" frameborder='0' src ='frames/login.php' style ='width:400;height:100;' >
	</iframe>
	</td></tr>
</table>
<br>
<table width="93%" cellspacing="1" cellpadding="4" STYLE="-moz-border-radius:6px; border:1px #808080 solid;">
<tr><td bgcolor="#ffffff">

	Create new user (neuen Benutzer anlegen)

	<iframe  id='createUser' name='createUser' scrolling="auto" frameborder='0' src ='php/mod_createUser.php' style ='width:400;height:242;' >
	</iframe>
</table>
<br>
<table width="93%" cellspacing="1" cellpadding="4" STYLE="-moz-border-radius:6px; border:1px #808080 solid;">
<tr><td bgcolor="#ffffff">
Have a lot of fun with 
<font align="left" color="#000000">Ma</font><font color="#0000CE">p</font><font color="#C00000">b</font><font color="#000000">ender</font> !
</td></tr>
</table>
</body>
</html>