<?php
# $Id: system.php 4672 2009-09-22 08:07:04Z christoph $
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

#
# mapbender version
#
define("MB_VERSION_NUMBER", "2.6");
define("MB_VERSION_APPENDIX", "");
define("MB_RELEASE_DATE", mktime(0,0,0,9,22,2009));//h, min,sec,month,day,year

#
# constants from map.js
#
define("MB_RESOLUTION", "28.35");
define("MB_FEATURE_COUNT", "100");
define("MB_SECURITY_PROXY", "http://wms1.ccgis.de/mapbender/tools/security_proxy.php?mb_ows_security_proxy=");
#
# available log levels 
#
define("LOG_LEVEL_LIST", "off,error,warning,notice,all");

define("ZOOM_MOUSEWHEEL", "1.1");

define("MODULES_NOT_RELYING_ON_GLOBALS", "back,forward,zoomIn1,copyright,dependentDiv,dragMapSize,dynamicOverview,FeatureInfoRedirect,highlightPOI,navFrame,sandclock,scaleBar,scaleSel,setBBOX,setPOI2Scale");
