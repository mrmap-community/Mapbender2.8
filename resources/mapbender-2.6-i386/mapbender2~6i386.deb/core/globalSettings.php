<?php
# $Id: globalSettings.php 3658 2009-03-09 16:18:51Z christoph $
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

//
// start the session
//
session_start();

//
// define LC_MESSAGES if unknown
// 
if (!defined('LC_MESSAGES')) define('LC_MESSAGES', LC_CTYPE);

//
// All data Mapbender handles internally are UTF-8
//
mb_internal_encoding("UTF-8");

//
// constants
//
require_once(dirname(__FILE__)."/../core/system.php");

//
// configuration file
//
require_once(dirname(__FILE__)."/../conf/mapbender.conf");

//
// database wrapper
//
if(SYS_DBTYPE=="mysql") {
	require_once(dirname(__FILE__) . "/../lib/database-mysql.php"); 
}
else {
	require_once(dirname(__FILE__) . "/../lib/database-pgsql.php"); 
}

//
// class for error handling
//
require_once(dirname(__FILE__)."/../http/classes/class_mb_exception.php");

//
// I18n wrapper function, gettext
//
require_once(dirname(__FILE__) . "/../core/i18n.php");
require_once(dirname(__FILE__) . "/../http/classes/class_locale.php");
$localeObj = new Mb_locale($_SESSION["mb_lang"]);

//
// establish database connection
//
$con = db_connect($DBSERVER, $OWNER, $PW);
db_select_db(DB, $con);

//
// Do not display PHP errors
//
ini_set("display_errors", "0");

//
// AJAX wrapper
//
require_once(dirname(__FILE__)."/../lib/ajax.php");

?>
