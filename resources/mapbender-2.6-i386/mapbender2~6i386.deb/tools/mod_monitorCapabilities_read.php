<?php
# $Id: mod_monitorCapabilities_read.php 3354 2008-12-17 10:31:57Z mschulz $
# http://www.mapbender.org/index.php/Monitor_Capabilities
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#require_once(dirname(__FILE__)."/../php/mb_validateSession.php");
require_once(dirname(__FILE__)."/../../conf/mapbender.conf");
require_once(dirname(__FILE__)."/../classes/class_administration.php");
session_start();
import_request_variables("PG");
$con = db_connect($DBSERVER,$OWNER,$PW);
db_select_db(DB,$con);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<?php
echo '<meta http-equiv="Content-Type" content="text/html; charset='.CHARSET.'">';	
?>
</head>
<body>
<?php
$admin = new administration();

// update selected wms
for ($i=0; $i < $_POST['cbs']; $i++) {
	$upd_wmsid = intval($_POST['cb'.$i]); 
	if ($upd_wmsid) {
		
		$now = time();
		$sql = "UPDATE mb_monitor SET status = '-2', status_comment = 'Monitoring is still in progress...', timestamp_begin = $1, timestamp_end = $2 WHERE upload_id = $3 AND fkey_wms_id = $4";
		$v = array($now, $now, $_POST['upl_id'.$i], $upd_wmsid);
		$t = array('s', 's', 's', 'i');
		$res = db_prep_query($sql,$v,$t);
		
		$exec = PHP_PATH . "php mod_monitorCapabilities_write.php ".$upd_wmsid." ".$_POST['upl_id'.$i]." 1 > output.txt &";
		exec($exec);
	}
}

$sql = "SELECT DISTINCT fkey_wms_id FROM mb_monitor";
$res = db_prep_query($sql, array(), array());
$cnt = 0;
$wms = array();
while(db_fetch_row($res)){
	$wms[$cnt] = db_result($res,$cnt,"fkey_wms_id");
	$cnt++;
}

$status = array();
$upload_id = array();
for ($i=0; $i<count($wms); $i++) {
	$wms_id[$wms[$i]] = $wms[$i];
	// get upload id
	$sql = "SELECT MAX(upload_id) FROM mb_monitor WHERE fkey_wms_id = $1";
	$v = array($wms[$i]);
	$t = array('i');
	$res = db_prep_query($sql,$v,$t);
	$upload_id[$wms[$i]] = db_result($res,0,0);

	$sql = "SELECT AVG(timestamp_begin), AVG(timestamp_end) FROM mb_monitor WHERE fkey_wms_id = $1 AND NOT status = '-1' AND NOT status = '-2'";
	$v = array($wms[$i]);
	$t = array('i');
	$res = db_prep_query($sql,$v,$t);
	if (db_result($res,0,1) == 0 && db_result($res,0,0) == 0) {
		$avg_response_time[$wms[$i]] = NULL;	
	}
	else {
		$avg_response_time[$wms[$i]] = round(db_result($res,0,1)-db_result($res,0,0), 1);
	}
	
	$sql = "SELECT status, status_comment, timestamp_begin, timestamp_end, upload_url, updated, image, map_url, caps_diff FROM mb_monitor ";
	$sql .= "WHERE upload_id = $1 AND fkey_wms_id = $2 ORDER BY status, status_comment, timestamp_end, fkey_wms_id";
	$v = array($upload_id[$wms[$i]], $wms_id[$wms[$i]]);
	$t = array('s', 'i');
	$res = db_prep_query($sql,$v,$t);

	$status[$wms[$i]] = intval(db_result($res,0,"status"));
	$comment[$wms[$i]] = db_result($res,0,"status_comment");
	$timestamp_begin[$wms[$i]] = db_result($res,0,"timestamp_begin");
	$timestamp_end[$wms[$i]] = db_result($res,0,"timestamp_end");
	$upload_url[$wms[$i]] = db_result($res,0,"upload_url");
	$updated[$wms[$i]] = db_result($res,0,"updated");
	$mapurl[$wms[$i]] = db_result($res,0,"map_url");
	$image[$wms[$i]] = db_result($res,0,"image");
	$caps_diff[$wms[$i]] = db_result($res,0,"caps_diff");
	
 	if ($status[$wms[$i]] == -2 && intval(time())-intval($timestamp_begin[$wms[$i]]) > intval(TIME_LIMIT)) {
		$comment[$wms[$i]] = "Monitoring process timed out.";	
		
		$new_sql = "UPDATE mb_monitor SET status = '-1', status_comment = 'Monitoring process timed out.', timestamp_end = $1 WHERE fkey_wms_id = $2 AND upload_id = $3";
		$new_v = array((intval($upload_id[$wms[$i]])+intval(TIME_LIMIT)), $wms_id[$wms[$i]], $upload_id[$wms[$i]]);
		$new_t = array('s', 'i', 's');
		$new_res = db_prep_query($new_sql,$new_v,$new_t);
	}

	$sql = "SELECT COUNT(upload_id) FROM mb_monitor WHERE fkey_wms_id = $1 AND NOT status = '-2'";
	$v = array($wms[$i]);
	$t = array('i');
	$res = db_prep_query($sql, $v, $t);
	$total[$wms[$i]] = db_result($res, 0, 0);

	$sql = "SELECT COUNT(upload_id) FROM mb_monitor WHERE fkey_wms_id = $1 AND status = '-1'";
	$v = array($wms[$i]);
	$t = array('i');
	$res = db_prep_query($sql, $v, $t);
	$fail = db_result($res, 0, 0);
	
	$percentage[$wms[$i]] = 100 - round(100*floatval($fail)/floatval($total[$wms[$i]]), 1);
}


$newArray = $status;
if ($_GET['sortby']) {
	if ($_GET['sortby'] == "wms") {
		$newArray = $wms_id;
		asort($newArray);
	}
	elseif ($_GET['sortby'] == "status") {
		$newArray = $status;
		asort($newArray);
	}
	elseif ($_GET['sortby'] == "avgresp") {
		$newArray = $avg_response_time;
		asort($newArray);
	}
	elseif ($_GET['sortby'] == "avail") {
		$newArray = $percentage;
		arsort($newArray);
	}
	elseif ($_GET['sortby'] == "last") {
		$newArray = $upload_id;
		arsort($newArray);
	}
	elseif ($_GET['image'] == "last") {
		$newArray = $image;
		arsort($newArray);
	}
}



$str = "<span style='font-size:30'>monitoring results</span><hr><br>\n";
$str .= "<form name = 'form1' method='post' action='".$PHP_SELF."?sortby=".$_GET['sortby']."'>\n\t";
$str .= "\n\t<input type=submit value='update selected WMS'>\n";
$str .= "\n\t<input type=button onclick=\"self.location.href='".$PHP_SELF."?sortby=".$_GET['sortby']."'\" value='refresh'>\n<br/><br/>\n	";
$str .= "<table cellpadding=10 cellspacing=0 border=0>";
$str .= "<tr bgcolor='#dddddd'><th></th><th align='left'><a href='".$PHP_SELF."?sortby=wms'>wms</a></th>";
$str .= "<th align='left' colspan = 2><a href='".$PHP_SELF."?sortby=status'>current status</a></th>";
$str .= "<th align='left'><a href='".$PHP_SELF."?sortby=image'>image</a></th>";
$str .= "<th align='left'><a href='".$PHP_SELF."?sortby=avgresp'>avg. response time</a></th>";
$str .= "<th align='left'><a href='".$PHP_SELF."?sortby=avail'>overall availability</a></th><th></th><th>Diff</th></tr>";

$cnt = 0;
foreach ($newArray as $k => $value) {
	$img = "stop.bmp";
	if ($status[$k]==0) $img = "wait.bmp";
	elseif ($status[$k]==1) $img = "go.bmp";

	if ($updated[$k] == "0" && $status[$k] == 0) $fill = "checked"; else $fill = "disabled";

	if (fmod($cnt, 2) == 1) {
		$str .= "\n\t\t<tr bgcolor='#e6e6e6'>";
	}
	else {
		$str .= "\n\t\t<tr bgcolor='#f0f0f0'>";
	}
	$str .= "\n\t\t\t<td><input name='cb".$cnt."' value='" . $wms_id[$k] . "' type=checkbox ".$fill." /><input type=hidden name='upl_id".$cnt."' value='".$upload_id[$k]."'></td>";
	$str .= "\n\t\t\t<td valign='top'><b>" . $wms_id[$k] . "</b><br>" . $admin->getWmsTitleByWmsId($wms_id[$k]) . "</td>";
	$str .= "\n\t\t\t<td valign='top'><a href='".$upload_url[$k]."' target=_blank><img title='Connect to service' border=0 src = '../img/trafficlights/". $img. "'></a></td>";
	$str .= "\n\t\t\t<td valign='top'>" . $comment[$k] . "<br><div style='font-size:12'>".date("F j, Y, G:i:s", $upload_id[$k])."</div></td>";
	$str .= "\n\t\t\t<td valign='top'>";

	$str .= "<table bgcolor='black' border=1 cellspacing=1 cellpadding=0><tr><td height=20 width=20 align=center valign=middle bgcolor='";

	if ($image[$k] == -1) {
		$str .= "red";
	}
	elseif ($image[$k] == 0) {
		$str .= "yellow";
	}
	elseif ($image[$k] == 1) {
		$str .= "green";
	}

	if ($image[$k] != -1) {
		$str .= "'><a href='".$mapurl[$k]."'>o</a></td></tr></table></td>";
	}
	else {
		$str .= "'><a href='".$mapurl[$k]."'>x</a></td></tr></table></td>";
	}

	$str .= "\n\t\t\t<td valign='top' align = 'left'>";
	if ($avg_response_time[$k] == NULL) {
		$str .= "n/a";
	}
	else {
		$str .= $avg_response_time[$k] . " s";
	}
	$str .= "</td>";
	$str .= "\n\t\t\t<td valign='top'><b>" . $percentage[$k] . " %</b>&nbsp;&nbsp;<span style='font-size:12'>(" . $total[$k] . " cycles)</span><br>";
	$str .= "<table bgcolor='black' border=1 cellspacing=1 cellpadding=0><tr>";
	$val = $percentage[$k];
	for ($i=0; $i<10; $i++) {
		if ($val>=10) {
			$str .= "<td height=10 width='10' bgcolor='red'></td>";
			$val-=10;
		}
		elseif($val>0){
			$str .= "<td height=10 width='" . round($val) . "' bgcolor='red'></td>";
			if (round($val) < 10) {
				$str .= "<td height=10 width='" . (9-round($val)) . "' bgcolor='white'></td>";
			}
			$val=-1;
		}
		else {
			$str .= "<td height=10 width='10' bgcolor='white'></td>";
		}
	}
	$str .= "</tr></table></td>";
	
#	$str .= "\n\t\t\t<td><a href='output_".$wms_id[$k]."_".$max.".txt' target=_blank>log</a></td>";
	$str .= "\n\t\t<td><input type=button value='details' onclick=\"var newWindow = window.open('../tools/mod_monitorCapabilities_read_single.php?wmsid=".$wms_id[$k]."','wms','width=500,height=700,scrollbars');newWindow.href.location='test.php'\"></td>";
	$str .= "\n\t\t\t<td>";	
	if ($caps_diff[$k] != "")
		$str .= "<a href='mod_monitorCapabilities_read_single_diff.php?wmsid=".$wms_id[$k]."&upload_id=".$upload_id[$k]."' target=_blank>view</a>";
	$str .= "</td></tr>";
	$cnt++;
}
$str .= "\n\t</table>\n\t<br/><input type=hidden name=cbs value='".$cnt."'>\n</form>";
echo $str;

?>
</body></html>
