<?php
# $Id: mod_monitorCapabilities_main.php 1240 2007-10-24 09:27:00Z baudson $
# http://www.mapbender.org/index.php/Monitor_Capabilities
# Copyright (C) 2002 CCGIS 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//require_once(dirname(__FILE__) . "/../php/mb_validateSession.php");
require_once(dirname(__FILE__)."/../../conf/mapbender.conf");
//session_start();
//import_request_variables("PG");
require_once(dirname(__FILE__)."/../classes/class_administration.php");
$con = db_connect($DBSERVER,$OWNER,$PW);
db_select_db(DB,$con);
$admin = new administration();

//$user = "root";
$user = "";
$gui = "";
$cl = 0;


function getConjunctionCharacter($onlineresource){
	if(strstr($onlineresource, "?")) {
		$lastChar = substr($onlineresource,strlen($onlineresource)-1, 1);  
		if ($lastChar == "?" || $lastChar == "&") {return "";}
		else{return "&";}
	}
	else {return "?";} 
}

// retrieve username and gui_id
if ($_REQUEST['user']) {
	$cl = 0;
	//browser
	echo "browser";
	$user = $_REQUEST['user'];
	$gui = $_REQUEST['gui'];
}
elseif ($_SERVER["argv"][1]) {
	$cl = 1;
	//command line
	$p1 = $_SERVER["argv"][1];
	$p2 = $_SERVER["argv"][2];
	if (substr($p1, 0,5) == "user:") {
		$user = substr($p1, 5);
		if (substr($p2, 0,4) == "gui:") {
			$gui = substr($p2, 4);
		}
	}
}
else {
	echo "Please specify a username!\n";die();
}

$userid = $admin->getUserIdByUserName($user);

/*
 * if the current user is a valid user...
 */
if ($userid) {
	$ownguis = $admin->getGuisByOwner($userid,true);
	/*
	 * if monitoring is restricted to a single GUI...
	 */
	if ($gui) {
		// ... abort if the GUI doesn't exist
		if (!$admin->guiExists($gui)) {
			echo "GUI " . $gui . " doesn't exist.\n"; die();
		}
		// ... add the GUI to the array of GUIs that will be monitored
		elseif (in_array($gui, $ownguis)) {
			$ownguis = array($gui);
		} 
		// ... abort if the GUI is not owned by the current user
		else {
			echo "User " . $user . " is not owner of GUI " . $gui . ".\n"; die();
		}
	}
}
/*
 * if current user is not a valid user, abort
 */
else {
	echo $user . " is not a valid username.\n";	die();
}

/**
 * Array of WMS IDs. These are the WMS that the user owns.
 */
$wms_id_own = $admin->getWmsByOwnGuis($ownguis);

// initialise monitoring processes
echo "Starting monitoring cycle...\n\n";
if ($cl == 0) echo "<br/><br/>";
echo "WMS services are requested for availability.\n"; 
if ($cl == 0) echo "<br/>";
echo "Capabilities documents are requested and all changes synchronized with the database cache.\n\n";
if ($cl == 0) echo "<br/><br/>";

$time = strval(time()-2);

for ($k=0; $k<count($wms_id_own); $k++) {
	$sql = "SELECT wms_upload_url FROM wms WHERE wms_id = $1";
	$v = array($wms_id_own[$k]);
	$t = array('i');
	$res = db_prep_query($sql,$v,$t);
	$someArray = db_fetch_row($res);
	$url = $someArray[0];
	
	if (!$upload_url || $upload_url == "") {
		$sql = "SELECT wms_version, wms_getcapabilities FROM wms WHERE wms_id = $1";
		$v = array($wms_id_own[$k]);
		$t = array('i');
		$res = db_prep_query($sql,$v,$t);
		$someArray = db_fetch_row($res);

		$version = $someArray[0];
		$capabilities = $someArray[1]; 	
		if ($version == "1.0.0" ) {
			$url = $capabilities . getConjunctionCharacter($capabilities) . "REQUEST=capabilities&WMTVER=1.0.0";
		}
		else {
			$url = $capabilities . getConjunctionCharacter($capabilities) . "REQUEST=GetCapabilities&SERVICE=WMS&VERSION=" . $version;	
		}
	}
	
	$sql = "INSERT INTO mb_monitor (upload_id, fkey_wms_id, status, status_comment, timestamp_begin, timestamp_end, upload_url, updated) ";
	$sql .= "VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";
	$v = array($time,$wms_id_own[$k],"-2","Monitoring is still in progress...", time(),time(),$url,"0");
	$t = array('s', 'i', 's', 's', 's', 's', 's', 's');
	$res = db_prep_query($sql,$v,$t);
}

for ($k=0; $k<count($wms_id_own); $k++) {

	if (intval(AUTO_UPDATE)) {
		$exec = PHP_PATH . "php5 mod_monitorCapabilities_write.php ".$wms_id_own[$k]." ".$time." 1 > ../tmp/output_".$time."_".$wms_id_own[$k].".txt &";
	}
	else {
		$exec = PHP_PATH . "php5 mod_monitorCapabilities_write.php ".$wms_id_own[$k]." ".$time." 0 > ../tmp/output_".$time."_".$wms_id_own[$k].".txt &";
	}
	exec($exec);
}
echo "Monitoring Cycle completed (total: " . count($wms_id_own) . " wms).\n\n";
if ($cl == 0) echo "<br/><br/>";
set_time_limit(2*TIME_LIMIT);

// wait until all monitoring processes are finished
echo "please wait " . TIME_LIMIT . " seconds for the monitoring to finish...\n\n";
if ($cl == 0) echo "<br/><br/>";
sleep(TIME_LIMIT);

$sql = "SELECT fkey_wms_id, status, status_comment, timestamp_begin, timestamp_end, upload_url FROM mb_monitor WHERE upload_id = $1";
$v = array($time);
$t = array('i');
$res = db_prep_query($sql,$v,$t);

$cnt=0;
while ($row = db_fetch_array($res)) {
	$status[$cnt] = intval(db_result($res,$cnt,"status"));
	$wms_id[$cnt] = db_result($res,$cnt,"fkey_wms_id");
	$comment[$cnt] = db_result($res,$cnt,"status_comment");
	$upload_url[$cnt] = db_result($res,$cnt,"upload_url");
	$timestamp_begin[$cnt] = db_result($res,0,"timestamp_begin");
	$timestamp_end[$cnt] = db_result($res,0,"timestamp_end");
	$cnt++;
}

$body = "";
for ($i=0; $i<$cnt; $i++) {
	// if monitoring is still in progress and time limit has expired, update database
	if ($status[$i] == -2 && intval(time())-intval($timestamp_begin[$i]) > intval(TIME_LIMIT)) {
		$comment[$i] = "Monitoring process timed out.";
		$status[$i] = -1;	
		$new_sql = "UPDATE mb_monitor SET status = '-1', image = '-1', status_comment = 'Monitoring process timed out.', timestamp_end = $1 WHERE fkey_wms_id = $2 AND upload_id = $3";
		$new_v = array((intval($upload_id[$i])+intval(TIME_LIMIT)), $wms_id[$i], $time);
		$new_t = array('s', 'i', 's');
		$new_res = db_prep_query($new_sql,$new_v,$new_t);
	}
	// compose mail message
	echo $wms_id[$i] . ": status " . $status[$i] . "\n";
	if ($cl == 0) echo "<br/><br/>";
	if ($status[$i] == -1) {
		$body .= $admin->getWmsTitleByWmsId($wms_id[$i]) . " (" . $wms_id[$i] . "): " . $comment[$i] . "\n\n";
	}
}

// Send an email to the user
if ($body) {
	$error_msg = "";
	if ($admin->getEmailByUserId($userid)) {
//		$admin->sendEmail(MAILADMIN, MAILADMINNAME, $admin->getEmailByUserId($userid), $user, "WMS monitor report " . date("F j, Y, G:i:s", $time), utf8_decode($body), &$error_msg);
	}
	else {
		$error_msg = "Email address of user '" . $admin->getUserNameByUserId($userid) . "' unknown!\n";
	}
	if ($error_msg) {
		echo "\n ERROR: " . $error_msg;
	}
}
?>
